# frozen_string_literal: true

IS_BOOT_FILE_LOADED = true

require_relative './version_workflow'
require_relative './my_task'
