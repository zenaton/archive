# frozen_string_literal: true

require_relative './my_event'

class Workflow1 < Zenaton::Interfaces::Workflow
  include Zenaton::Traits::Zenatonable

  def handle
    'result1'
  end

  def on_event(event)
    'My event triggered' if event.is_a? MyEvent
  end

  def on_start(task)
    "#{task.handle} on start"
  end

  def on_timeout(task)
    "#{task.handle} on timeout"
  end

  def on_success(task, output)
    "#{task.handle} on success, with output: #{output}"
  end

  def on_failure(task, error)
    "#{task.handle} on failure, with error: #{error}"
  end
end
