# frozen_string_literal: true

require 'zenaton/worker/v1/workflow'
require 'app_dir/my_task'
require 'app_dir/version_workflow'

RSpec.describe Zenaton::Worker::V1::Workflow do
  let(:blank_json) { { 'a' => {}, 's' => [] }.to_json }
  let(:flow) { described_class.instance }
  let(:position) do
    instance_double(
      Zenaton::Worker::V1::Position,
      get: nil, next: nil, next_async: nil, next_parallel: nil, init: nil
    )
  end

  before do
    setup_flow
  end

  describe 'workflow name' do
    before { flow.name = 'MyWorkflow' }

    it 'sets the name' do
      expect(flow.name).to eq('MyWorkflow')
    end
  end

  describe '#init' do
    context 'when workflow is a version' do
      before do
        flow.name = 'VersionWorkflow'
        flow.init('my-branch', blank_json)
      end

      it 'instantiates a the initial workflow version' do
        expect(flow.instance_variable_get(:@flow)).to be_a(Workflow1)
      end

      it 'sets the name to the workflow implementation' do
        expect(flow.name).to eq('Workflow1')
      end
    end

    context 'when workflow is not a version' do
      before do
        flow.name = 'Workflow1'
        flow.init('my-branch', blank_json)
      end

      it 'instantiates a new workflow object' do
        expect(flow.instance_variable_get(:@flow)).to be_a(Workflow1)
      end
    end
  end

  describe '#run_branch' do
    context 'when branch has no type' do
      let(:branch) { {} }

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns nothing' do
        expect(flow.run_branch).to be_nil
      end
    end

    context 'when branch type is on handle' do
      let(:branch) { { 'type' => 'handle' } }

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow handle method' do
        expect(flow.run_branch).to eq('result1')
      end
    end

    context 'when branch type is on event' do
      let(:branch) do
        {
          'type' => 'onEvent',
          'data' => { 'event_name' => 'MyEvent', 'event_input' => blank_json }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow on event method' do
        expect(flow.run_branch).to eq('My event triggered')
      end
    end

    context 'when branch type is on start' do
      let(:branch) do
        {
          'type' => 'onStart',
          'data' => {
            'task_name' => 'MyTask',
            'task_input' => blank_json
          }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow on task method' do
        expect(flow.run_branch).to eq('Task handled on start')
      end
    end

    context 'when branch type is on success' do
      let(:branch) do
        {
          'type' => 'onSuccess',
          'data' => {
            'task_name' => 'MyTask',
            'task_input' => blank_json,
            'task_output' => { 'd' => 'some output', 's' => [] }.to_json
          }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow on success method' do
        expect(flow.run_branch).to \
          eq('Task handled on success, with output: some output')
      end
    end

    context 'when branch type is on success but task is wait' do
      let(:branch) do
        {
          'type' => 'onSuccess',
          'data' => {
            'task_name' => 'Zenaton::Tasks::Wait',
            'task_input' => blank_json,
            'task_output' => 'some output'
          }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns no output' do
        expect(flow.run_branch).to \
          eq(' on success, with output: ')
      end
    end

    context 'when branch type is on failure' do
      let(:branch) do
        {
          'type' => 'onFailure',
          'data' => {
            'task_name' => 'MyTask',
            'task_input' => blank_json,
            'error_name' => 'StandardError',
            'error_input' => blank_json
          }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow on failure method' do
        expect(flow.run_branch).to \
          eq('Task handled on failure, with error: StandardError')
      end
    end

    context 'when branch type is on timeout' do
      let(:branch) do
        {
          'type' => 'onTimeout',
          'data' => { 'task_name' => 'MyTask', 'task_input' => blank_json }
        }
      end

      before do
        flow.name = 'Workflow1'
        flow.init(branch, blank_json)
      end

      it 'returns the result of the workflow on timeout method' do
        expect(flow.run_branch).to eq('Task handled on timeout')
      end
    end
  end

  describe '#get_position' do
    before { flow.get_position }

    it 'delegates to the position' do
      expect(position).to have_received(:get)
    end
  end

  describe '#next' do
    before { flow.next }

    it 'delegates to the position' do
      expect(position).to have_received(:next)
    end
  end

  describe '#next_async' do
    before { flow.next_async }

    it 'delegates to the position' do
      expect(position).to have_received(:next_async)
    end
  end

  describe '#next_parallel' do
    before { flow.next_parallel }

    it 'delegates to the position' do
      expect(position).to have_received(:next_parallel)
    end
  end

  def setup_flow
    Singleton.__init__(described_class)
    allow(Zenaton::Worker::V1::Position).to receive(:new).and_return(position)
  end
end
