# frozen_string_literal: true

require 'zenaton/services/log'

RSpec.describe Zenaton::Services::Log do
  let(:log) { described_class.new }
  let(:log_file) { IO.read('./spec/app_dir/zenaton.log') }
  let(:title) { 'My title' }
  let(:message) { 'This is a message' }
  let(:expected_log) do
    <<~LOG
      ==== #{title} ====
      #{message}
    LOG
  end

  context 'when no log level nor type is specified' do
    it '::always appends to the log' do
      log.always(title, message)
      expect(log_file).to eq(expected_log)
    end

    it '::info does not append to the log' do
      log.info(title, message)
      expect(log_file).to be_empty
    end

    it '::warning does not append to the log' do
      log.warning(title, message)
      expect(log_file).to be_empty
    end

    it '::error does not append to the log' do
      log.error(title, message)
      expect(log_file).to be_empty
    end
  end

  context 'when a log level is specified but no log type' do
    before { ENV['ZENATON_LOG_LEVEL'] = '2' }

    after { ENV.delete('ZENATON_LOG_LEVEL') }

    it '::always appends to the log' do
      log.always(title, message)
      expect(log_file).to eq(expected_log)
    end

    it '::info appends to the log' do
      log.info(title, message)
      expect(log_file).to eq(expected_log)
    end

    it '::warning appends to the log' do
      log.warning(title, message)
      expect(log_file).to eq(expected_log)
    end

    it '::error does not append to the log' do
      log.error(title, message)
      expect(log_file).to be_empty
    end
  end

  context 'when a log type is specified but no log level' do
    before { ENV['ZENATON_LOG_TYPE'] = 'decision' }

    after { ENV.delete('ZENATON_LOG_TYPE') }

    it '::always does not append to the log' do
      log.always(title, message)
      expect(log_file).to be_empty
    end

    it '::always with matching type appends to the log' do
      log.always(title, message, 'decision')
      expect(log_file).to eq(expected_log)
    end

    it '::info does not append to the log' do
      log.info(title, message)
      expect(log_file).to be_empty
    end

    it '::info with matching type does not append to the log' do
      log.info(title, message, 'decision')
      expect(log_file).to be_empty
    end
  end

  context 'when both log level and type are specified' do
    before do
      ENV['ZENATON_LOG_LEVEL'] = '2'
      ENV['ZENATON_LOG_TYPE'] = 'decision'
    end

    after do
      ENV.delete('ZENATON_LOG_TYPE')
      ENV.delete('ZENATON_LOG_LEVEL')
    end

    it '::always does not append to the log' do
      log.always(title, message)
      expect(log_file).to be_empty
    end

    it '::always with matching type appends to the log' do
      log.always(title, message, 'decision')
      expect(log_file).to eq(expected_log)
    end

    it '::info does not append to the log' do
      log.info(title, message)
      expect(log_file).to be_empty
    end

    it '::info with matching type appends to the log' do
      log.info(title, message, 'decision')
      expect(log_file).to eq(expected_log)
    end

    it '::error does not append to the log' do
      log.error(title, message)
      expect(log_file).to be_empty
    end

    it '::error with matching type does not append to the log' do
      log.error(title, message, 'decision')
      expect(log_file).to be_empty
    end
  end
end
