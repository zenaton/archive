<?php

use Symfony\Component\Debug\Debug;
use Symfony\Component\Dotenv\Dotenv;

// If APP_ENV is not defined, maybe the user is using the Dotenv component to load its environment variables in production.
// If he does not, we will assume he wants to run using the 'prod' environment.
if (!isset($_SERVER['APP_ENV'])) {
    if (class_exists(Dotenv::class) && file_exists($file = getenv('ZENATON_APP_DIR').'/.env')) {
        (new Dotenv())->load($file);
    }
}

$env = $_SERVER['APP_ENV'] ? $_SERVER['APP_ENV'] : 'prod';
$debug = $_SERVER['APP_DEBUG'] ? $_SERVER['APP_DEBUG'] : ('prod' !== $env);

if ($debug) {
    umask(0000);

    // Some old Symfony versions do not have the Debug component.
    if (class_exists(Debug::class)) {
        Debug::enable();
    }
}

$kernel = new $kernelClass($env, $debug);
$kernel->boot();

// helper : add global container function
$GLOBALS['zenatonSymfonyKernel'] = $kernel;

function container()
{
    global $zenatonSymfonyKernel;

    return $zenatonSymfonyKernel->getContainer();
}

return $kernel;
