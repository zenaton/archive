/* global process */

const Loader = require('../Loader/Loader')

let args = process.argv
// remove first 2 elements
args.splice(0,2)
let loader = new Loader(args)

// load boot file
loader.boot()

// create Slave instance
const Slave = require('../Loader/Slave')
let job = loader.getJobUrl()
let slave = new Slave(job)

// we have all what we need
loader.success()

// Use uncaughtError to catch all errors
process.on('uncaughtError', function (e) {
	const Microserver = require('../Worker/v1/Microserver')
	let ms = new Microserver()
	if (ms.isWorking()) {
		ms.failWorker(e)
	}
	if (ms.isDeciding()) {
		ms.failDecider(e)
	}
	// let die
	throw e
})

// we arrive here only if everything went well, including the success() call to url
slave.process()
