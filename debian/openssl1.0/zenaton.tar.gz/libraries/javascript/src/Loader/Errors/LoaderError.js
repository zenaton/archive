const ZenatonError = require('./ZenatonError')

module.exports = class extends ZenatonError {}
