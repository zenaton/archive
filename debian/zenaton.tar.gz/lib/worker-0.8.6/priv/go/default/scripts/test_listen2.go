package main

import (
	"os"

	"../loader"
)

func main() {
	args := os.Args

	l, err := loader.NewLoader(args)
	if err != nil {
		panic(err)
	}

	err = l.CheckClasses()
	if err != nil {
		panic(err)
	}
}
