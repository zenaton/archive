package zenaton

import (

	// if in project that is outside gopath and has vendoring
	b "github.com/zenaton/examples-go/boot"
)

var Client = b.Service.Client

type Workflow = b.Workflow
type Task = b.Task
type Wait = b.Wait
type Job = b.Job
type Processor = b.Processor

var Engine = b.Service.Engine
var Serializer = b.Service.Serializer
var WorkflowManager = b.Service.WorkflowManager
var TaskManager = b.Service.TaskManager
var Errors = b.Service.Errors
