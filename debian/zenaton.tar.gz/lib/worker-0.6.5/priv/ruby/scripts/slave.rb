# frozen_string_literal: true

require_relative '../lib/zenaton/loader/loader'
# load class
loader = Zenaton::Loader::Loader.new(*ARGV)

# load boot file
loader.boot

# create Slave instance
require_relative '../lib/zenaton/loader/slave'
job = loader.job_url
slave = Zenaton::Loader::Slave.new(job)

# we have all we need
loader.success

# rescue from any error
begin
  # we arrive here only if everything went well, including the success call to url
  slave.process
rescue StandardError => error
  require_relative '../lib/zenaton/worker/v1/microserver'
  microserver = Zenaton::Worker::V1::Microserver.instance
  microserver.fail_worker(error) if microserver.working?
  microserver.fail_decider(error) if microserver.deciding?
  raise error
end
