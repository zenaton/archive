<?php

namespace Zenaton\Test\Mock\Task;

use Zenaton\Interfaces\TaskInterface;

class SimpleReturnValueTask implements TaskInterface
{
    private $value;

    public function __construct($value)
    {
        $this->value = $value;
    }

    public function handle()
    {
        return $this->value;
    }
}
