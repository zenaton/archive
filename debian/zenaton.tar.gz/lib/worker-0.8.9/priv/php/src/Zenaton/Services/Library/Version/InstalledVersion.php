<?php

namespace Zenaton\Services\Library\Version;

use Zenaton\Services\Library\Version;
use Zenaton\Version as PublicLibraryVersion;

/**
 * Represents the currently installed version of zenaton-php.
 */
final class InstalledVersion implements Version
{
    public function gt($version)
    {
        return $this->getVersionId() > $version;
    }

    public function gte($version)
    {
        return $this->getVersionId() >= $version;
    }

    public function lt($version)
    {
        return $this->getVersionId() < $version;
    }

    public function lte($version)
    {
        return $this->getVersionId() <= $version;
    }

    /**
     * Returns the current version id of the library.
     *
     * This method assumes that if the version class does not exist, we consider the library to be in version 0.2.0
     *
     * @return int
     */
    private function getVersionId()
    {
        if (!class_exists(PublicLibraryVersion::class)) {
            return 00200;
        }

        return PublicLibraryVersion::ID;
    }
}
