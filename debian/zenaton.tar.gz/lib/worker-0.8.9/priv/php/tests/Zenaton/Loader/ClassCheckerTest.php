<?php

namespace Zenaton\Loader;

use PHPUnit\Framework\TestCase;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;

class ClassCheckerTest extends TestCase
{
    public function testCheck()
    {
        $classes = [];

        $workflow1 = $this->createMock(WorkflowInterface::class);
        $classes[] = get_class($workflow1);

        $workflow2 = $this->createMock(WorkflowInterface::class);
        $classes[] = get_class($workflow2);

        $task1 = $this->createMock(TaskInterface::class);
        $classes[] = get_class($task1);

        $task2 = $this->createMock(TaskInterface::class);
        $classes[] = get_class($task2);

        $classes[] = \DateTime::class;

        $checker = new ClassChecker();
        $result = $checker->check(implode(',', $classes));

        static::assertEquals([
            'workflows' => [
                get_class($workflow1),
                get_class($workflow2),
            ],
            'tasks' => [
                get_class($task1),
                get_class($task2),
            ],
            'undefined' => [
                \DateTime::class,
            ],
        ], $result);
    }
}
