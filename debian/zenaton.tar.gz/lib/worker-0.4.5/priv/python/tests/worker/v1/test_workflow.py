import pytest


@pytest.mark.usefixtures("workflow", "workflow_with_callbacks", "workflow_with_wrong_callbacks", "workflow_without_callbacks")
def test_implemented_callbacks(workflow, workflow_with_callbacks, workflow_with_wrong_callbacks, workflow_without_callbacks):
    workflow.flow = workflow_without_callbacks
    assert workflow.implemented_callbacks() == []
    workflow.flow = workflow_with_wrong_callbacks
    assert workflow.implemented_callbacks() == []
    workflow.flow = workflow_with_callbacks
    callbacks = workflow.implemented_callbacks()
    assert 'onStart' in callbacks
    assert 'onEvent' in callbacks
