<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Services\SyncHttp;
use Zenaton\Tasks\Wait;
use Zenaton\Test\Injector;
use Zenaton\Test\Mock\Event\DummyEvent;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\SingletonTesting;

class MicroServerTest extends TestCase
{
    use SingletonTesting;
    use Injector;

    public function setUp()
    {
        static::destroySingleton(MicroServer::class);
    }

    public static function tearDownAfterClass()
    {
        static::destroySingleton(MicroServer::class);
    }

    /**
     * @dataProvider getDecidingData
     */
    public function testIsDeciding($hash, $uuid, $expected)
    {
        $microserver = MicroServer::getInstance();
        $microserver->setHash($hash);
        $microserver->setUuid($uuid);

        static::assertEquals($expected, $microserver->isDeciding());
    }

    public function getDecidingData()
    {
        yield ['abcde', 'uuid', false];
        yield ['abcde', null, false];
        yield [null, 'uuid', true];
        yield [null, null, false];
    }

    /**
     * @dataProvider getWorkingData
     */
    public function testIsWorking($hash, $uuid, $expected)
    {
        $microserver = MicroServer::getInstance();
        $microserver->setHash($hash);
        $microserver->setUuid($uuid);

        static::assertEquals($expected, $microserver->isWorking());
    }

    public function getWorkingData()
    {
        yield ['abcde', 'uuid', true];
        yield ['abcde', null, false];
        yield [null, 'uuid', false];
        yield [null, null, false];
    }

    public function testResetUuidHashAndWorkerVersion()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $assertions = function () {
            assertEquals('uuid', $this->uuid);
            assertEquals('abcde', $this->hash);
            assertEquals(1, $this->workerVersion);
        };
        $assertions = $assertions->bindTo($microserver, MicroServer::class);
        $assertions();

        $microserver->reset();

        $assertions = function () {
            assertEquals(null, $this->uuid);
            assertEquals(null, $this->hash);
            assertEquals(null, $this->workerVersion);
        };
        $assertions = $assertions->bindTo($microserver, MicroServer::class);
        $assertions();
    }

    public function testAskJob()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('get')
            ->with('http://localhost:4001/api/v_newton/uuid/requested-uuid/type/job-type/job?worker_version=1&')
        ;

        $microserver->askJob('job-type');
    }

    public function testGetBranchToExecute()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('get')
            ->with('http://localhost:4001/api/v_newton/decisions/requested-uuid/branch?worker_version=1&')
        ;

        $microserver->getBranchToExecute();
    }

    public function testExecuteAlreadyExecutedJob()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $expectedResponse = (object) [
            'status' => 'completed',
            'properties' => '{"a":[],"s":[]}',
            'outputs' => [
                (object) [
                    'event_name' => DummyEvent::class,
                    'event_input' => '{"a":[],"s":[]}',
                ],
                '{"d":42,"s":[]}',
            ],
        ];

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/decisions/requested-uuid/execute?worker_version=1&',
                [
                    'works' => [
                        [
                            'position' => null,
                            'sync' => null,
                            'name' => Wait::class,
                            'input' => '{"a":{"event":"Zenaton\\\\Test\\\\Mock\\\\Event\\\\DummyEvent","_buffer":[["hours",1]]},"s":[]}',
                            'type' => 'wait',
                            'maxProcessingTime' => null,
                            'event' => 'Zenaton\Test\Mock\Event\DummyEvent',
                            'timestamp' => null,
                            'duration' => 3600,
                        ],
                        [
                            'position' => null,
                            'sync' => null,
                            'name' => SimpleReturnValueTask::class,
                            'input' => '{"a":{"value":42},"s":[]}',
                            'type' => 'task',
                            'maxProcessingTime' => null,
                        ],
                    ],
                ]
            )
            ->willReturn($expectedResponse)
        ;

        $boxes = [
            new JobBox((new Wait(DummyEvent::class))->hours(1)),
            new JobBox(new SimpleReturnValueTask(42)),
        ];

        $response = $microserver->execute($boxes);

        static::assertEquals((object) [
            'status' => 'completed',
            'properties' => [],
            'outputs' => [
                new DummyEvent(),
                42,
            ],
        ], $response);
    }

    public function testCompleteDecision()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $response = (object) [
            'status' => 'ok',
        ];

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/decisions/requested-uuid/branch?worker_version=1&',
                [
                    'properties' => '{"d":null,"s":[]}',
                ]
            )
            ->willReturn($response)
        ;

        $flow = $this->createMock(Workflow::class);

        $this->inject(function () use ($flow) {
            $this->flow = $flow;
        }, $microserver);

        $result = $microserver->completeDecision();

        static::assertEquals($response, $result);
    }

    public function testCompleteDecisionBranch()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $response = (object) [
            'status' => 'ok',
        ];

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/decisions/requested-uuid/branch?worker_version=1&',
                [
                    'properties' => '{"a":[],"s":[]}',
                    'output' => '{"d":42,"s":[]}',
                ]
            )
            ->willReturn($response)
        ;

        $flow = $this->createMock(Workflow::class);

        $flow
            ->expects($this->once())
            ->method('getProperties')
            ->willReturn([])
        ;

        $this->inject(function () use ($flow) {
            $this->flow = $flow;
        }, $microserver);

        $result = $microserver->completeDecisionBranch(42);

        static::assertEquals($response, $result);
    }

    public function testFailDecider()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $response = (object) [
            'status' => 'ok',
        ];

        $http
            ->expects($this->once())
            ->method('put')
            ->with(
                'http://localhost:4001/api/v_newton/decisions/requested-uuid/?worker_version=1&',
                static::logicalAnd(
                    static::arrayHasKey('status'),
                    static::arrayHasKey('error_code'),
                    static::arrayHasKey('error_message'),
                    static::arrayHasKey('error_name'),
                    static::arrayHasKey('error_stacktrace'),
                    static::arrayHasKey('failed_at')
                )
            )
            ->willReturn($response)
        ;

        $result = $microserver->failDecider(new \RuntimeException('Oops!'));

        static::assertEquals($response, $result);
    }

    public function testFailDecision()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $response = (object) [
            'status' => 'ok',
        ];

        $http
            ->expects($this->once())
            ->method('put')
            ->with(
                'http://localhost:4001/api/v_newton/decisions/requested-uuid/?worker_version=1&',
                static::logicalAnd(
                    static::arrayHasKey('status'),
                    static::arrayHasKey('error_code'),
                    static::arrayHasKey('error_message'),
                    static::arrayHasKey('error_name'),
                    static::arrayHasKey('error_stacktrace'),
                    static::arrayHasKey('failed_at')
                )
            )
            ->willReturn($response)
        ;

        $result = $microserver->failDecision(new \RuntimeException('Oops!'));

        static::assertEquals($response, $result);
    }

    public function testCompleteWork()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/tasks/requested-uuid?worker_version=1&',
                [
                    'status' => 'completed',
                    'output' => '{"d":42,"s":[]}',
                    'hash' => 'abcde',
                ]
            )
        ;

        $microserver->completeWork(42);
    }

    public function testFailWorker()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/tasks/requested-uuid?worker_version=1&',
                static::logicalAnd(
                    static::arrayHasKey('status'),
                    static::arrayHasKey('error_name'),
                    static::arrayHasKey('error_input'),
                    static::arrayHasKey('error_code'),
                    static::arrayHasKey('error_message'),
                    static::arrayHasKey('error_stacktrace'),
                    static::arrayHasKey('failed_at')
                )
            )
        ;

        $microserver->failWorker(new \RuntimeException('Oops!'));
    }

    public function testFailWork()
    {
        $microserver = MicroServer::getInstance();
        $microserver
            ->setUuid('requested-uuid')
            ->setHash('abcde')
            ->setWorkerVersion(1)
        ;

        $http = $this->createMock(SyncHttp::class);
        $this->inject(function () use ($http) {
            $this->http = $http;
        }, $microserver);

        $http
            ->expects($this->once())
            ->method('post')
            ->with(
                'http://localhost:4001/api/v_newton/tasks/requested-uuid?worker_version=1&',
                static::logicalAnd(
                    static::arrayHasKey('status'),
                    static::arrayHasKey('error_name'),
                    static::arrayHasKey('error_input'),
                    static::arrayHasKey('error_code'),
                    static::arrayHasKey('error_message'),
                    static::arrayHasKey('error_stacktrace'),
                    static::arrayHasKey('failed_at')
                )
            )
        ;

        $microserver->failWork(new \RuntimeException('Oops!'));
    }
}
