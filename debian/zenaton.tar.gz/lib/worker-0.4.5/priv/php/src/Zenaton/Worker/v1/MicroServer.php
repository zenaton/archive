<?php

namespace Zenaton\Worker;

use Exception;

use Zenaton\Client;
use Zenaton\Services\Serializer;
use Zenaton\Services\Properties;
use Zenaton\Traits\SingletonTrait;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Interfaces\EventInterface;

use Zenaton\Services\Log;
use Zenaton\Services\SyncHttp;

class MicroServer
{
    use SingletonTrait;

    protected $properties;
    protected $serializer;
    protected $log;
    protected $flow;
    protected $http;

    protected $uuid;
    protected $hash;
    protected $workerVersion;

    public function construct()
    {
        $this->serializer = new Serializer();
        $this->properties = new Properties();
        $this->log = new Log();
        $this->flow = Workflow::getInstance();
        $this->http = new SyncHttp();
    }

    public function getUuid()
    {
        return $this->uuid;
    }

    public function setUuid($uuid)
    {
        $this->uuid = $uuid;

        return $this;
    }

    public function setWorkerVersion($workerVersion)
    {
        $this->workerVersion = $workerVersion;

        return $this;
    }

    public function setHash($hash)
    {
        $this->hash = $hash;

        return $this;
    }

    public function reset()
    {
        $this->uuid = null;
        $this->hash = null;
        $this->workerVersion = null;

        return $this;
    }

    public function isDeciding()
    {
        return (is_null($this->hash) && !is_null($this->uuid));
    }

    public function isWorking()
    {
        return (!is_null($this->hash) && !is_null($this->uuid));
    }

    public function askJob($type)
    {
        $url = $this->getWorkerUrl('uuid/'.$this->uuid.'/type/'.$type.'/job', 'worker_version='. $this->workerVersion);

        $response = $this->http->get($url);

        $this->log->info('INFRA - Ask Job - (get) ' . $url, ['response' => $response], Log::TYPE_INFRA);

        return $response;
    }

    public function getBranchToExecute()
    {
        $url = $this->decisionUrl('branch');

        $response = $this->http->get($url);

        $this->log->info('DECISION - Branch - (get) ' . $url, ['response' => $response], Log::TYPE_DECISION);

        return $response;
    }

    public function execute($boxes)
    {
        $jobs = [];
        foreach ($boxes as $box) {
            $jobs[] = $box->getJob();
        }

        $url = $this->decisionUrl('execute');
        $body = ['works' => $jobs];
        $response = $this->http->post($url, $body);

        if ($response->status === 'completed') {
            // decode properties
            $response->properties = $this->serializer->decode($response->properties);

            // decode outputs ($output can be null, eg. wait task)
            $outputs = array_map(function ($output) {
                if (!is_null($output)) {
                    // if the output is the an event from a Wait(event) - Build this event
                    if (isset($output->event_name) && isset($output->event_input)) {
                        return $this->properties->getObjectFromNameAndProperties(
                            $output->event_name,
                            $this->serializer->decode($output->event_input),
                            EventInterface::class
                        );
                    }

                    return $this->serializer->decode($output);
                }
            }, $response->outputs);

            $response->outputs = $outputs;
        }

        $this->log->info('DECISION - Execute - (post) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_DECISION);

        return $response;
    }


    public function completeDecision()
    {
        $url = $this->decisionUrl('branch');
        $body = [
            'properties' => $this->serializer->encode($this->flow->getProperties()),
            'callbacks' => $this->flow->getImplementedCallbacks(),
        ];
        $response = $this->http->post($url, $body);

        $this->log->info('DECISION - Complete - (post) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_DECISION);

        return $response;
    }


    public function completeDecisionBranch($output)
    {
        $url = $this->decisionUrl('branch');
        $body = [
            'properties' => $this->serializer->encode($this->flow->getProperties()),
            'callbacks' => $this->flow->getImplementedCallbacks(),
        ];
        if (isset($output)) {
            $body['output'] = $this->serializer->encode($output);
        }
        $response = $this->http->post($url, $body);

        $this->log->info('DECISION - Complete Branch - (post) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_DECISION);

        return $response;
    }

    public function failDecider(Exception $e)
    {
        $url = $this->decisionUrl();
        $body = [
            'status' => 'zenatonFailed',
            'error_code' => $e->getCode(),
            'error_message' => $e->getMessage(),
            'error_name' =>  get_class($e),
            'error_stacktrace' => $e->getTraceAsString(),
            'failed_at' => (new \DateTime())->getTimestamp()
        ];
        $response = $this->http->put($url, $body);

        $this->log->info('DECISION - Decider Failure - (put) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_DECISION);

        return $response;
    }

    public function failDecision(Exception $e)
    {

        $url = $this->decisionUrl();
        $body = [
            'status' => 'failed',
            'error_code' => $e->getCode(),
            'error_message' => $e->getMessage(),
            'error_name' =>  get_class($e),
            'error_stacktrace' => $e->getTraceAsString(),
            'failed_at' => (new \DateTime())->getTimestamp()
        ];
        $response = $this->http->put($url, $body);

        $this->log->info('DECISION - Decision Failure - (put) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_DECISION);

        return $response;
    }

    public function completeWork($output)
    {
        $this->sendWork([
            'status' => 'completed',
            'output' => $this->serializer->encode($output)
        ]);
    }

    public function failWorker(Exception $e)
    {
        $this->sendWork([
            'status' => 'zenatonFailed',
            'error_name' =>  get_class($e),
            'error_input' => $this->serializer->encode($this->properties->getPropertiesFromObject($e)),
            'error_code' => $e->getCode(),
            'error_message' => $e->getMessage(),
            'error_stacktrace' => $e->getTraceAsString(),
            'failed_at' => (new \DateTime())->getTimestamp()
        ]);
    }


    public function failWork(Exception $e)
    {
        $this->sendWork([
            'status' => 'failed',
            'error_name' =>  get_class($e),
            'error_input' => $this->serializer->encode($this->properties->getPropertiesFromObject($e)),
            'error_code' => $e->getCode(),
            'error_message' => $e->getMessage(),
            'error_stacktrace' => $e->getTraceAsString(),
            'failed_at' => (new \DateTime())->getTimestamp()
        ]);
    }

    public function sendWork($body)
    {
        $url = $this->getWorkerUrl('tasks/'. $this->uuid, 'worker_version='.$this->workerVersion);
        $body['hash'] = $this->hash;
        $response = $this->http->post($url, $body);

        $this->log->info('Task - Send - (post) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_TASK);

        return $response;
    }

    public function decisionUrl($endpoint = '')
    {
        return $this->getWorkerUrl('decisions/'.$this->uuid.'/'.$endpoint, 'worker_version='. $this->workerVersion);
    }

    protected function getWorkerUrl($ressource, $params = '')
    {
        // taking url from client ensures we use same Worker API version than user library
        return Client::getInstance(true)->getWorkerUrl($ressource, $params);
    }
}
