<?php

namespace Zenaton\Services\Library\Version;

use Zenaton\Services\Library\Version;

final class ArbitraryVersion implements Version
{
    /** @var int */
    private $versionId;

    /**
     * @param int $versionId
     */
    public function __construct($versionId)
    {
        $this->versionId = $versionId;
    }

    public function gt($version)
    {
        return $this->versionId > $version;
    }

    public function gte($version)
    {
        return $this->versionId >= $version;
    }

    public function lt($version)
    {
        return $this->versionId < $version;
    }

    public function lte($version)
    {
        return $this->versionId <= $version;
    }
}
