<?php

$output = [
    'php' => [
        'version' => PHP_VERSION,
        'bin_path' => PHP_BINARY,
        'env' => Env::all(),
    ],
];

$output = Output::clean($output);

echo json_encode($output);

class Output
{
    public static function clean(array $output)
    {
        // Remove env if empty
        if (count($output['php']['env']) === 0) {
            unset($output['php']['env']);
        }

        return $output;
    }
}

class Env
{
    public static function all()
    {
        if (PHP_VERSION_ID >= 70100) {
            return getenv();
        }

        return $_ENV;
    }
}
