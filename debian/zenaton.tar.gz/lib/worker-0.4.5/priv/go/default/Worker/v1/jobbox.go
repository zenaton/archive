package v1

import (
	"fmt"

	"../../services/log"
	"../../services/zenaton"
)

const (
	ATTRIBUTE_NAME                = "name"
	ATTRIBUTE_INPUT               = "input"
	ATTRIBUTE_POSITION            = "position"
	ATTRIBUTE_EVENT               = "event"
	ATTRIBUTE_TIMESTAMP           = "timestamp"
	ATTRIBUTE_DURATION            = "duration"
	ATTRIBUTE_TYPE                = "type"
	ATTRIBUTE_SYNC                = "sync"
	ATTRIBUTE_MAX_PROCESSING_TIME = "maxProcessingTime"
	TYPE_TASK                     = "task"
	TYPE_WORKFLOW                 = "workflow"
	TYPE_WAIT                     = "wait"
)

type JobBox struct {
	job      zenaton.Job
	sync     bool
	position string
}

func NewJobBox(job zenaton.Job) *JobBox {
	return &JobBox{
		job: job,
	}
}

func (jb *JobBox) setSync(sync bool) *JobBox {
	jb.sync = sync
	return jb
}

func (jb *JobBox) setPosition(position string) *JobBox {
	jb.position = position
	return jb
}

func (jb *JobBox) getJob() map[string]interface{} {
	data := make(map[string]interface{})
	name := jb.job.GetName()

	data[ATTRIBUTE_POSITION] = jb.position
	data[ATTRIBUTE_SYNC] = jb.sync
	data[ATTRIBUTE_NAME] = name
	input, err := zenaton.Serializer.Encode(jb.job.GetData())
	if err != nil {
		panic(err)
	}
	data[ATTRIBUTE_INPUT] = input

	switch v := jb.job.(type) {
	case *zenaton.Task:
		data[ATTRIBUTE_TYPE] = TYPE_TASK
		maxTimer, ok := v.Handler.(interface{ MaxTime() int64 })
		if ok {
			data[ATTRIBUTE_MAX_PROCESSING_TIME] = maxTimer.MaxTime()
		} else {
			data[ATTRIBUTE_MAX_PROCESSING_TIME] = nil
		}
	case *zenaton.Wait:
		data[ATTRIBUTE_TYPE] = TYPE_WAIT
		var event = v.Event()

		timestamp, duration, err := v.GetTimestampOrDuration()
		if err != nil {
			panic(err)
		}

		data[ATTRIBUTE_EVENT] = event
		data[ATTRIBUTE_TIMESTAMP] = timestamp
		data[ATTRIBUTE_DURATION] = duration

		log.Info("WAIT", map[string]interface{}{
			"name":      name,
			"event":     event,
			"duration":  duration,
			"timestamp": timestamp,
		}, log.WAIT())
	default:
		panic(fmt.Sprintf("unexpected type %T", v))
	}

	return data
}
