package v1

import (
	"fmt"
	"os"

	"../../services/zenaton"
)

type Decider struct {
	Name        string
	microserver *MicroServer
	flow        *Workflow
}

func NewDecider(name string) *Decider {
	return &Decider{
		Name:        name,
		flow:        NewWorkflow().setWorkflowName(name),
		microserver: NewMicroServer(),
	}
}

func (d *Decider) Launch() error {
	//// execute every branches
	for {
		ok, err := d.getNextBranch()
		if err != nil {
			return err
		}
		if !ok {
			break
		}
		shouldBreak := d.runBranch()
		if shouldBreak {
			break
		}
	}

	// this decision is ended, clean up microserver
	d.microserver.reset()
	return nil
}

func (d *Decider) runBranch() (shouldBreak bool) {

	defer func() {
		r := recover()

		if r == nil {
			return
		}

		message := fmt.Sprint(r)
		name := "WorkflowPanic"
		stack := getTraceWithOffset(4)

		namer, ok := r.(interface{ Name() string })

		if ok {
			name = namer.Name()
		}

		switch r {
		case zenaton.Errors.ScheduledBoxError:
			d.microserver.completeDecision()

		case zenaton.Errors.InternalZenatonError:
			d.microserver.FailDecider(name, message, stack)
			fmt.Fprintln(os.Stderr, r)
			fmt.Fprintln(os.Stderr, stack)
			shouldBreak = true

		default:
			d.microserver.failDecision(name, message, stack)

			fmt.Fprintln(os.Stderr, r)
			fmt.Fprintln(os.Stderr, stack)
			shouldBreak = true
		}

	}()

	output, err := d.flow.runBranch()
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
	}

	combinedOutput := make(map[string]interface{})
	combinedOutput["output"] = output
	if err != nil {
		combinedOutput["error"] = err.Error()
	}

	d.microserver.completeDecisionBranch(combinedOutput)

	return false
}

func (d *Decider) getNextBranch() (bool, error) {
	branch := d.microserver.getBranchToExecute()

	// branch has been set
	if *branch != (Branch{}) {
		err := d.flow.init(branch, branch.Properties)
		if err != nil {
			return false, err
		}
		return true, nil
	}
	return false, nil
}
