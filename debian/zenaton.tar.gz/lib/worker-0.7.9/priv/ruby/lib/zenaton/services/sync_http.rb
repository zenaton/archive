# frozen_string_literal: true

require 'net/http'
require_relative 'log'

module Zenaton
  module Services
    # Class wrapping http requests
    class SyncHttp
      def initialize
        @log = Log.new
      end

      def get(url)
        parsed_url = parse_url(url)
        req = Net::HTTP::Get.new(parsed_url[:uri])
        res = make_request(parsed_url, req)
        parse_and_log(url, 'get', nil, res)
      end

      def post(url, body)
        parsed_url = parse_url(url)
        req = Net::HTTP::Post.new(parsed_url[:uri])
        req['Content-Type'] = 'application/json'
        req.body = body.to_json
        res = make_request(parsed_url, req)
        parse_and_log(url, 'post', body, res)
      end

      def put(url, body)
        parsed_url = parse_url(url)
        req = Net::HTTP::Put.new(parsed_url[:uri])
        req['Content-Type'] = 'application/json'
        req.body = body.to_json
        res = make_request(parsed_url, req)
        parse_and_log(url, 'put', body, res)
      end

      private

      def parse_url(url)
        uri = URI.parse(url)
        { uri: uri, use_ssl: uri.scheme == 'https' }
      end

      def make_request(parsed_url, req)
        Net::HTTP.start(
          parsed_url[:uri].hostname,
          parsed_url[:uri].port,
          use_ssl: parsed_url[:use_ssl]
        ) do |http|
          http.request(req)
        end
      end

      def parse_and_log(url, verb, body, response)
        JSON.parse(response.body).tap do |json_response|
          @log.info(
            "MICROSERVER: (#{verb}) #{url}",
            { response: json_response, body: body },
            Log::TYPE_MICROSERVER
          )
        end
      end
    end
  end
end
