import zenaton
from zenaton.services.serializer import Serializer
from zenaton.singleton import Singleton

from .position import Position
from ...services.importer import Importer


class Workflow(metaclass=Singleton):

    CALLBACKS = {
        'on_event': 'onEvent',
        'on_failure': 'onFailure',
        'on_start': 'onStart',
        'on_success': 'onSuccess',
        'on_timeout': 'onTimeout'
    }

    def __init__(self):
        self.serializer = zenaton.services.serializer.Serializer()
        self.properties = zenaton.services.properties.Properties()
        self.position = Position()

    def run_branch(self):
        branch_type = self.branch['type']
        if branch_type == 'handle':
            self.flow.handle()
        elif branch_type == 'onEvent':
            if hasattr(self.flow, 'on_event'):
                event_class = Importer(self.boot).import_class(self.branch['data']['event_name'])
                event = self.properties.object_from(
                    event_class,
                    self.serializer.decode(self.branch['data']['event_input']),
                    zenaton.abstracts.event.Event
                )
                return self.flow.on_event(event)
        elif branch_type == 'onStart':
            if hasattr(self.flow, 'on_start'):
                task_class = Importer(self.boot).import_class(self.branch['data']['task_name'])
                task = self.properties.object_from(
                    task_class,
                    self.serializer.decode(self.branch['data']['task_input']),
                    zenaton.abstracts.task.Task
                )
                return self.flow.on_start(task)
        elif branch_type == 'onSuccess':
            if hasattr(self.flow, 'on_success'):
                task_class = Importer(self.boot).import_class(self.branch['data']['task_name'])
                task = self.properties.object_from(
                    task_class,
                    self.serializer.decode(self.branch['data']['task_input']),
                    zenaton.abstracts.task.Task
                )
                if not issubclass(type(task), zenaton.tasks.wait.Wait):
                    output = self.serializer.decode(self.branch['data']['task_output'])
                return self.flow.on_success(task, output)
        elif branch_type == 'onFailure':
            if hasattr(self.flow, 'on_failure'):
                task_class = Importer(self.boot).import_class(self.branch['data']['task_name'])
                task = self.properties.object_from(
                    task_class,
                    self.serializer.decode(self.branch['data']['task_input']),
                    zenaton.abstracts.task.Task
                )
                error = self.properties.object_from(
                    self.branch['data']['error_name'],
                    self.serializer.decode(self.branch['data']['error_input']),
                    Exception
                )
                return self.flow.on_failure(task, error)
        elif branch_type == 'onTimeout':
            if hasattr(self.flow, 'on_timeout'):
                task_class = Importer(self.boot).import_class(self.branch['data']['task_name'])
                task = self.properties.object_from(
                    task_class,
                    self.serializer.decode(self.branch['data']['task_input']),
                    zenaton.abstracts.task.Task
                )
                return self.flow.on_timeout(task)

    def get_position(self):
        return self.position.get()

    def next(self):
        return self.position.next()

    def next_async(self):
        return self.position.next_async()

    def next_parallel(self):
        return self.position.next_parallel()

    def read_properties(self):
        return self.properties.from_(self.flow)

    def write_properties(self, properties):
        return self.properties.set(self.flow, properties)

    def build_workflow(self, properties):
        """version = self.properties.blank_instance(self.name)
        if issubclass(type(version), zenaton.workflows.version.Version):
            self.name = str(version.initial)"""
        worflow_class = Importer(self.boot).import_class(self.name)
        if properties is None:
            return worflow_class()
        serializer = Serializer(boot=self.boot, name=self.name)
        args = serializer.decode(properties)
        if args and args.get('args', None) is not None:
            args = args['args']
        return self.properties.object_from(
            worflow_class,
            args,
            zenaton.abstracts.workflow.Workflow
        )

    def build(self, branch, properties):
        self.flow = self.build_workflow(properties)
        self.branch = branch
        self.position = Position()

    def implemented_callbacks(self):
        implemented_callbacks = []
        for callback_snake, callback_camel in self.CALLBACKS.items():
            if hasattr(self.flow, callback_snake):
                implemented_callbacks.append(callback_camel)
        return implemented_callbacks

    def get_retry_delay(self, retry_index):
        if hasattr(self.flow, 'on_failure_retry_delay'):
            self.flow.on_failure_retry_delay(retry_index)

        return None
