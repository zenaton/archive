import logging
import sys

import zenaton

from .microserver import Microserver
from .workflow import Workflow
from ...worker_exceptions import ScheduledBox, ModifiedDecider


class Decider:

    def __init__(self, job, boot):
        logging.basicConfig(stream=sys.stdout)
        self.microserver = Microserver()
        self.flow = Workflow()
        self.flow.name = job['name']
        self.flow.boot = boot
        self.job = job

    def launch(self):
        """execute every branch"""
        extra = {}

        while self.__next_branch():
            if self.job.get('retry_index'):
                try:
                    delay = self.flow.get_retry_delay(self.job['retry_index'])
                except Exception as err:
                    self.microserver.fail_decider(err, extra)
                    break

                if delay != None:
                    extra['retry'] = {'delay': delay}

            try:
                output = self.flow.run_branch()
            except ScheduledBox:
                """nothing more to do for this branch, continue to next one"""
                self.microserver.complete_decision()
                continue
            except zenaton.exceptions.InternalError as err:
                """something bad happened in our code, stop current decision"""
                self.microserver.fail_decider(err, extra)
                self.__fail_and_log(err, extra)
                break
            except ModifiedDecider as err:
                """user did modify its decider, sad!"""
                self.microserver.fail_decider(err, extra)
                self.__fail_and_log(err, extra)
                break
            except Exception as err:
                """something bad happened in user code, stop current decision"""
                self.microserver.fail_decider(err, extra)
                self.__fail_and_log(err, extra)
                break
            """cool, we complete this branch"""
            self.microserver.complete_decision_branch(output)

        """this decision is done, clean up microserver"""
        self.microserver.reset()

    def __fail_and_log(self, err, extra):
        logging.error(err)

    def __next_branch(self):
        branch = self.microserver.branch_to_execute()
        if branch and branch != '':
            self.flow.build(branch['branch'], branch['properties'])
            return True
        return False
