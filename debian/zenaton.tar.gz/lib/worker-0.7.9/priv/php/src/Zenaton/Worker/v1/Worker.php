<?php

namespace Zenaton\Worker;

use Exception;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Services\Log;
use Zenaton\Services\Properties;
use Zenaton\Services\Serializer;

class Worker
{
    protected $log;
    protected $microserver;
    protected $job;
    protected $task;

    public function __construct(Job $job)
    {
        $this->job = $job;
        $this->microserver = MicroServer::getInstance()->setHash($job->get('hash'));
        $input = (new Serializer())->decode($job->get('input'));
        $this->task = (new Properties())->getObjectFromNameAndProperties(
            $job->get('name'),
            $input,
            TaskInterface::class
        );
        (new Log())->info('TASK - Input - '.$job->get('name'), $input, Log::TYPE_TASK);
    }

    public function process()
    {
        $extra = [];

        // collect automatic retry delay in case of failure
        if (method_exists($this->task, 'onFailureRetryDelay') && $this->job->get('attempt_number')) {
            try {
                $delay = $this->task->onFailureRetryDelay($this->job->get('attempt_number'));
                $extra['retry'] = ['delay' => $delay];
                (new Log())->info('TASK - Retry Delay - '.$this->job->get('name').' - Attempt #'.$this->job->get('attempt_number'), $delay, Log::TYPE_TASK);
            } catch (Exception $e) {
                $this->microserver->failWork($e);
                $this->microserver->reset();

                throw $e;
            }
        }

        // do task
        try {
            $output = $this->task->handle();
        } catch (ZenatonException $e) {
            $this->microserver->failWorker($e, $extra);
            $this->microserver->reset();
            throw $e;
        } catch (Exception $e) {
            // tell microserver we have an exception
            $this->microserver->failWork($e, $extra);
            $this->microserver->reset();
            throw $e;
        }

        // tell microserver we have the result
        $this->microserver->completeWork($output);
        $this->microserver->reset();
    }
}
