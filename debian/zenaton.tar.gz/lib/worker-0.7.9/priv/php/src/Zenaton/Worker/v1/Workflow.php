<?php

namespace Zenaton\Worker;

use Zenaton\Interfaces\EventInterface;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Services\Properties;
use Zenaton\Services\Serializer;
use Zenaton\Tasks\Wait;
use Zenaton\Traits\SingletonTrait;
use Zenaton\Workflows\Version;

class Workflow
{
    use SingletonTrait;

    protected $serializer;
    protected $properties;
    protected $position;
    protected $counter;
    protected $name;
    protected $flow;
    protected $branch;

    const CALLBACKS = [
        'onEvent',
        'onFailure',
        'onStart',
        'onSuccess',
        'onTimeout',
    ];

    public function construct()
    {
        $this->serializer = new Serializer();
        $this->properties = new Properties();
        $this->position = new Position();
    }

    public function setWorkflowName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function init($branch, $properties)
    {
        // build workflow object

        // if provided class is a Version, it means it has been replaced since launched
        $version = $this->properties->getNewInstanceWithoutProperties($this->name);
        if ($version instanceof Version) {
            if (method_exists($version, 'initial')) {
                $this->name = $version->initial();
            } else {
                throw new ExternalZenatonException('Unknown initial version of '.$this->name);
            }
        }

        // build from name and properties
        $this->flow = $this->properties->getObjectFromNameAndProperties(
            $this->name,
            $this->serializer->decode($properties),
            WorkflowInterface::class
        );

        // build the branch
        $this->branch = $branch;

        // init position
        $this->position->init();

        return $this;
    }

    public function runBranch()
    {
        if ($this->branch->type === 'handle') {
            return $this->flow->handle();
        }

        if ($this->branch->type === 'onEvent') {
            if (method_exists($this->flow, 'onEvent')) {
                $event = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->event_name,
                    $this->serializer->decode($this->branch->data->event_input),
                    EventInterface::class
                );

                return $this->flow->onEvent($event);
            }
        }

        if ($this->branch->type === 'onStart') {
            if (method_exists($this->flow, 'onStart')) {
                $task = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->task_name,
                    $this->serializer->decode($this->branch->data->task_input),
                    TaskInterface::class
                );

                return $this->flow->onStart($task);
            }
        }

        if ($this->branch->type === 'onSuccess') {
            if (method_exists($this->flow, 'onSuccess')) {
                $task = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->task_name,
                    $this->serializer->decode($this->branch->data->task_input),
                    TaskInterface::class
                );
                // temporary hack
                if (($task instanceof Wait) && is_null($this->branch->data->task_output)) {
                    $output = null;
                } else {
                    $output = $this->serializer->decode($this->branch->data->task_output);
                }

                return $this->flow->onSuccess($task, $output);
            }
        }

        if ($this->branch->type === 'onFailure') {
            if (method_exists($this->flow, 'onFailure')) {
                $task = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->task_name,
                    $this->serializer->decode($this->branch->data->task_input),
                    TaskInterface::class
                );

                $error = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->error_name,
                    $this->serializer->decode($this->branch->data->error_input),
                    \Exception::class
                );

                return $this->flow->onFailure($task, $error);
            }
        }

        if ($this->branch->type === 'onTimeout') {
            if (method_exists($this->flow, 'onTimeout')) {
                $task = $this->properties->getObjectFromNameAndProperties(
                    $this->branch->data->task_name,
                    $this->serializer->decode($this->branch->data->task_input),
                    TaskInterface::class
                );

                return $this->flow->onTimeout($task);
            }
        }
    }

    public function getProperties()
    {
        return $this->properties->getPropertiesFromObject($this->flow);
    }

    public function setProperties($properties)
    {
        $this->properties->setPropertiesToObject($this->flow, $properties);

        return $this;
    }

    /**
     * Return the list of callbacks implemented in the Workflow.
     *
     * @return string[]
     */
    public function getImplementedCallbacks()
    {
        return array_values(array_filter(static::CALLBACKS, function ($callback) {
            return method_exists($this->flow, $callback);
        }));
    }

    public function getPosition()
    {
        return $this->position->get();
    }

    public function next()
    {
        $this->position->next();
    }

    public function nextParallel()
    {
        $this->position->nextParallel();
    }

    public function nextAsync()
    {
        $this->position->nextAsync();
    }

    public function getName()
    {
        return $this->name;
    }
}
