<?php

namespace Zenaton\Worker;

use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ModifiedDeciderException;
use Zenaton\Exceptions\ScheduledBoxException;

class Decider
{
    protected $job;
    protected $microserver;
    protected $flow;

    public function __construct(Job $job)
    {
        $this->job = $job;
        $this->microserver = MicroServer::getInstance();
        $this->flow = Workflow::getInstance()->setWorkflowName($job->get('name'));
    }

    public function launch()
    {
        // execute every branches
        while ($this->getNextBranch()) {
            try {
                $output = $this->flow->runBranch();
            } catch (ScheduledBoxException $e) {
                // nothing more to do for this branch, continue to next one
                $this->microserver->completeDecision();
                continue;
            } catch (InternalZenatonException $e) {
                // something bad happened in our code, stop current decision
                $this->microserver->failDecider($e);
                error_log($e);
                break;
            } catch (ModifiedDeciderException $e) {
                // user did modify it's decider, sad!
                $this->microserver->failDecision($e);
                error_log($e->getMessage());
                break;
            } catch (\Exception $e) {
                // something bad happened in user code, stop current decision
                $this->microserver->failDecision($e);
                error_log($e);
                break;
            }

            // cool, we complete this branch
            $this->microserver->completeDecisionBranch($output);
        }

        // this decision is ended, clean up microserver
        $this->microserver->reset();
    }

    protected function getNextBranch()
    {
        $branch = $this->microserver->getBranchToExecute();
        if ($branch) {
            $this->flow->init($branch->branch, $branch->properties);

            return true;
        }

        return false;
    }
}
