<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ModifiedDeciderException;
use Zenaton\Exceptions\ScheduledBoxException;
use Zenaton\Test\Mock\Workflow\NullWorkflow;
use Zenaton\Test\SingletonTesting;

class DeciderTest extends TestCase
{
    use SingletonTesting;

    public function testLaunchCompleteTheDecisionBranch()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->exactly(2))
            ->method('getBranchToExecute')
            ->willReturnOnConsecutiveCalls((object) [
                'branch' => (object) [
                    'type' => 'handle',
                ],
                'properties' => [],
            ], null);
        $microserver
            ->expects($this->once())
            ->method('completeDecisionBranch')
            ->with(42);
        $microserver
            ->expects($this->once())
            ->method('reset');

        $workflow = $this->replaceSingletonWithMock(Workflow::class);
        $workflow
            ->expects($this->once())
            ->method('runBranch')
            ->willReturn(42);
        $workflow
            ->expects($this->once())
            ->method('setWorkflowName')
            ->willReturnSelf();
        $workflow
            ->expects($this->once())
            ->method('init');

        $job = new \stdClass();
        $job->name = NullWorkflow::class;

        $decider = new Decider(new Job($job));
        $decider->launch();
    }

    public function testLaunchCompleteDecisionWhenCatchingSchduledBoxException()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->exactly(2))
            ->method('getBranchToExecute')
            ->willReturnOnConsecutiveCalls((object) [
                'branch' => (object) [
                    'type' => 'handle',
                ],
                'properties' => [],
            ], null);
        $microserver
            ->expects($this->once())
            ->method('completeDecision');
        $microserver
            ->expects($this->once())
            ->method('reset');

        $workflow = $this->replaceSingletonWithMock(Workflow::class);
        $workflow
            ->expects($this->once())
            ->method('runBranch')
            ->willThrowException(new ScheduledBoxException());
        $workflow
            ->expects($this->once())
            ->method('setWorkflowName')
            ->willReturnSelf();
        $workflow
            ->expects($this->once())
            ->method('init');

        $job = new \stdClass();
        $job->name = NullWorkflow::class;

        $decider = new Decider(new Job($job));
        $decider->launch();
    }

    public function testLaunchFailDeciderWhenCatchingInternalZenatonException()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('getBranchToExecute')
            ->willReturnOnConsecutiveCalls((object) [
                'branch' => (object) [
                    'type' => 'handle',
                ],
                'properties' => [],
            ], null);
        $e = new InternalZenatonException();
        $microserver
            ->expects($this->once())
            ->method('failDecider')
            ->with($e);
        $microserver
            ->expects($this->once())
            ->method('reset');

        $workflow = $this->replaceSingletonWithMock(Workflow::class);
        $workflow
            ->expects($this->once())
            ->method('runBranch')
            ->willThrowException($e);
        $workflow
            ->expects($this->once())
            ->method('setWorkflowName')
            ->willReturnSelf();
        $workflow
            ->expects($this->once())
            ->method('init');

        $job = new \stdClass();
        $job->name = NullWorkflow::class;

        $decider = new Decider(new Job($job));
        $decider->launch();
    }

    public function testLaunchFailDecisionWhenCatchingModifiedDeciderException()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('getBranchToExecute')
            ->willReturnOnConsecutiveCalls((object) [
                'branch' => (object) [
                    'type' => 'handle',
                ],
                'properties' => [],
            ], null);
        $e = new ModifiedDeciderException();
        $microserver
            ->expects($this->once())
            ->method('failDecision')
            ->with($e);
        $microserver
            ->expects($this->once())
            ->method('reset');

        $workflow = $this->replaceSingletonWithMock(Workflow::class);
        $workflow
            ->expects($this->once())
            ->method('runBranch')
            ->willThrowException($e);
        $workflow
            ->expects($this->once())
            ->method('setWorkflowName')
            ->willReturnSelf();
        $workflow
            ->expects($this->once())
            ->method('init');

        $job = new \stdClass();
        $job->name = NullWorkflow::class;

        $decider = new Decider(new Job($job));
        $decider->launch();
    }

    public function testLaunchFailDecisionWhenCatchingAnyOtherException()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('getBranchToExecute')
            ->willReturnOnConsecutiveCalls((object) [
                'branch' => (object) [
                    'type' => 'handle',
                ],
                'properties' => [],
            ], null);
        $e = new \RuntimeException('Oops!');
        $microserver
            ->expects($this->once())
            ->method('failDecision')
            ->with($e);
        $microserver
            ->expects($this->once())
            ->method('reset');

        $workflow = $this->replaceSingletonWithMock(Workflow::class);
        $workflow
            ->expects($this->once())
            ->method('runBranch')
            ->willThrowException($e);
        $workflow
            ->expects($this->once())
            ->method('setWorkflowName')
            ->willReturnSelf();
        $workflow
            ->expects($this->once())
            ->method('init');

        $job = new \stdClass();
        $job->name = NullWorkflow::class;

        $decider = new Decider(new Job($job));
        $decider->launch();
    }
}
