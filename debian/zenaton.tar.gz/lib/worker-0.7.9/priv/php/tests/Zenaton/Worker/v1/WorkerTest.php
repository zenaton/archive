<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Services\Serializer;
use Zenaton\Test\Mock\Task\ExecutingClosureTask;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\SingletonTesting;

class WorkerTest extends TestCase
{
    use SingletonTesting;

    public function testProcessExecutesATask()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->once())
            ->method('completeWork')
            ->with('Hello from task')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = SimpleReturnValueTask::class;
        $job->input = '{"a":{"value":"Hello from task"},"s":[]}';
        $job->hash = 'abcde';

        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessATaskThrowingAZenatonException()
    {
        $this->expectException(ZenatonException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWorker')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = ExecutingClosureTask::class;
        $job->input = $serializer->encode([
            'closure' => function () {
                throw new ZenatonException();
            },
        ]);
        $job->hash = 'abcde';

        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessATaskThrowingANonZenatonException()
    {
        $this->expectException(\RuntimeException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = ExecutingClosureTask::class;
        $job->input = $serializer->encode([
            'closure' => function () {
                throw new \RuntimeException();
            },
        ]);
        $job->hash = 'abcde';
        $worker = new Worker(new Job($job));

        $worker->process();
    }
}
