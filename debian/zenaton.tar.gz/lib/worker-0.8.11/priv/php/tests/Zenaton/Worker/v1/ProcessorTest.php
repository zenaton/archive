<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Client;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ModifiedDeciderException;
use Zenaton\Exceptions\ScheduledBoxException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Services\Library\Version\ArbitraryVersion;
use Zenaton\Test\Injector;
use Zenaton\Test\SingletonTesting;

class ProcessorTest extends TestCase
{
    use SingletonTesting;
    use Injector;

    public function setUp()
    {
        static::destroySingletons(
            MicroServer::class,
            Client::class,
            Workflow::class,
            Processor::class
        );
    }

    public function testProcessBoxesSyncWhenMicroServerIsWorking()
    {
        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->once())
            ->method('handle')
            ->willReturn('workflow')
        ;

        $task = $this->createMock(TaskInterface::class);
        $task
            ->expects($this->once())
            ->method('handle')
            ->willReturn('task')
        ;

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isWorking')
            ->willReturn(true)
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, true);

        static::assertEquals(['workflow', 'task'], $outputs);
    }

    public function testProcessBoxesSyncWhenMicroServerIsDecidingAndDeciderWasModified()
    {
        $this->expectException(ModifiedDeciderException::class);

        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
            ->willReturn('workflow')
        ;

        $task = $this->createMock(TaskInterface::class);

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(true)
        ;
        $microserver
            ->expects($this->once())
            ->method('execute')
            ->willReturn((object) [
                'status' => 'modified',
            ])
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, true);

        static::assertEquals([null, null], $outputs);
    }

    public function testProcessBoxesSyncWhenMicroServerIsDecidingAndDecisionWasScheduled()
    {
        $this->expectException(ScheduledBoxException::class);

        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
            ->willReturn('workflow')
        ;

        $task = $this->createMock(TaskInterface::class);

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(true)
        ;
        $microserver
            ->expects($this->once())
            ->method('execute')
            ->willReturn((object) [
                'status' => 'scheduled',
            ])
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, true);

        static::assertEquals([null, null], $outputs);
    }

    public function testProcessBoxesSyncWhenMicroServerIsDecidingAndDecisionWasCompleted()
    {
        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
            ->willReturn('workflow')
        ;

        $task = $this->createMock(TaskInterface::class);

        $boxes = [$workflow, $task];

        $flow = $this->replaceSingletonWithMock(Workflow::class);
        $flow
            ->expects($this->once())
            ->method('setProperties')
            ->with([])
        ;

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(true)
        ;
        $microserver
            ->expects($this->once())
            ->method('execute')
            ->willReturn((object) [
                'status' => 'completed',
                'properties' => [],
                'outputs' => [42, 'test'],
            ])
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, true);

        static::assertEquals([42, 'test'], $outputs);
    }

    public function testProcessBoxesSyncWhenMicroServerIsDecidingAndDecisionStatusIsUnknownThrowsAnException()
    {
        $this->expectException(InternalZenatonException::class);

        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
            ->willReturn('workflow')
        ;

        $task = $this->createMock(TaskInterface::class);

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(true)
        ;
        $microserver
            ->expects($this->once())
            ->method('execute')
            ->willReturn((object) [
                'status' => 'unknown',
            ])
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, true);
    }

    public function testProcessBoxesAsyncWhenMicroServerIsWorkingBeforeVersion03()
    {
        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
        ;

        $task = $this->createMock(TaskInterface::class);
        $task
            ->expects($this->once())
            ->method('handle')
        ;

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isWorking')
            ->willReturn(true)
        ;

        $client = $this->replaceSingletonWithMock(Client::class);
        $client
            ->expects($this->once())
            ->method('startWorkflow')
            ->with($workflow)
        ;

        $processor = Processor::getInstance();

        $this->inject(function () {
            $this->version = new ArbitraryVersion(00204);
        }, $processor);

        $outputs = $processor->process($boxes, false);

        static::assertEquals([null, null], $outputs);
    }

    public function testProcessBoxesAsyncWhenMicroServerIsWorking()
    {
        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
        ;

        $task = $this->createMock(TaskInterface::class);
        $task
            ->expects($this->never())
            ->method('handle')
        ;

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isWorking')
            ->willReturn(true)
        ;

        $client = $this->replaceSingletonWithMock(Client::class);
        $client
            ->expects($this->once())
            ->method('startWorkflow')
            ->with($workflow)
        ;
        $client
            ->expects($this->once())
            ->method('startTask')
            ->with($task)
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, false);

        static::assertEquals([null, null], $outputs);
    }

    public function testProcessBoxesAsyncWhenMicroServerIsDecidingAndDecisionWasScheduled()
    {
        $workflow = $this->createMock(WorkflowInterface::class);
        $workflow
            ->expects($this->never())
            ->method('handle')
        ;

        $task = $this->createMock(TaskInterface::class);
        $task
            ->expects($this->never())
            ->method('handle')
        ;

        $boxes = [$workflow, $task];

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(true)
        ;
        $microserver
            ->expects($this->once())
            ->method('execute')
            ->willReturn((object) [
                'status' => 'completed',
                'properties' => [],
                'outputs' => [42, 'test'],
            ])
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process($boxes, false);

        static::assertEquals([null, null], $outputs);
    }

    public function testProcessBoxesWithMicroServerInUnknownStateThrowsAnException()
    {
        $this->expectException(InternalZenatonException::class);

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);
        $microserver
            ->expects($this->once())
            ->method('isDeciding')
            ->willReturn(false)
        ;
        $microserver
            ->expects($this->once())
            ->method('isWorking')
            ->willReturn(false)
        ;
        $microserver
            ->expects($this->never())
            ->method('execute')
        ;

        $processor = Processor::getInstance();
        $outputs = $processor->process([], true);
    }
}
