class EnvironmentNotSet(Exception):
    pass


class ModifiedDecider(Exception):
    pass


class ScheduledBox(Exception):
    pass


class ClassNotFound(Exception):
    pass

