# frozen_string_literal: true

require_relative '../services/sync_http'
require_relative '../services/log'
require_relative '../worker/v1/microserver'
require_relative '../worker/v1/processor'
require_relative '../worker/v1/decider'
require_relative '../worker/v1/worker'

module Zenaton
  module Loader
    class Slave
      def initialize(job)
        @job = job
        @http = Zenaton::Services::SyncHttp.new
        @log = Zenaton::Services::Log.new
      end

      def process
        job = fetch_job
        job_class = Object.const_get(job['name'])
        return process_job(job) if valid_job(job_class)
        raise ExternalError, "Unknown #{job['name']} probably missing in your --boot file"
      end

      def process_job(job)
        setup_microserver(job)

        Zenaton::Engine.instance.processor = Zenaton::Worker::V1::Processor.instance

        case job['action']
        when 'DecisionScheduled'
          Zenaton::Worker::V1::Decider.new(job).launch
        when 'TaskScheduled'
          Zenaton::Worker::V1::Worker.new(job).process
        else
          raise InternalError, "Unknown action: #{job['action']}"
        end
      end

      private

      def setup_microserver(job)
        Zenaton::Worker::V1::Microserver.instance.tap do |microserver|
          microserver.uuid = job['uuid']
          microserver.worker_version = job['worker_version']
        end
      end

      def fetch_job
        @http.get(@job).tap do |response|
          @log.info(
            "INFRA - Ask Job - (get) #{@job}",
            { 'response' => response },
            Zenaton::Services::Log::TYPE_INFRA
          )
        end
      end

      def valid_job(klass)
        klass < Zenaton::Interfaces::Workflow || klass < Zenaton::Interfaces::Task
      end
    end
  end
end
