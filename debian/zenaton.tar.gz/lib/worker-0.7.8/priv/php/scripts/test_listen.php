<?php

use Zenaton\Loader\Loader;
use Zenaton\Loader\LoaderException;

// do not display errors on stdout
ini_set("display_errors", 'stderr');

// autoload our classes
require __DIR__ . '/../vendor/autoload.php';

// load class
$loader = new Loader($argv);

try {
    // load boot file
    $loader->boot();
} catch (LoaderException $e) {
    error_log($e->getMessage());

    exit(1);
}

// check parameters
$loader->checkClasses();
