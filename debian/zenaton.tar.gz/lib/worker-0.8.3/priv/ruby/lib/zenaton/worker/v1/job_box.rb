# frozen_string_literal: true

require_relative '../../services/log'

require 'securerandom'

module Zenaton
  module Worker
    module V1
      class JobBox
        ATTRIBUTE_NAME = 'name'
        ATTRIBUTE_INPUT = 'input'
        ATTRIBUTE_POSITION = 'position'
        ATTRIBUTE_EVENT = 'event'
        ATTRIBUTE_TIMESTAMP = 'timestamp'
        ATTRIBUTE_DURATION = 'duration'
        ATTRIBUTE_TYPE = 'type'
        ATTRIBUTE_SYNC = 'sync'
        ATTRIBUTE_MAX_PROCESSING_TIME = 'maxProcessingTime'
        ATTRIBUTE_INTENT_ID = 'intent_id'

        TYPE_TASK = 'task'
        TYPE_WORKFLOW = 'workflow'
        TYPE_WAIT = 'wait'

        INTENT_ID_VERSION = '0.4.2'

        attr_writer :sync, :position

        def initialize(given_job)
          @serializer = Zenaton::Services::Serializer.new
          @properties = Zenaton::Services::Properties.new
          @log = Zenaton::Services::Log.new
          @job = given_job

          if has_sdk_intent_id_capability?
            @intent_id = SecureRandom.uuid
          end
        end

        def job
          name = @job.class.name

          data = {
            ATTRIBUTE_POSITION => @position,
            ATTRIBUTE_SYNC => @sync,
            ATTRIBUTE_NAME => name,
            ATTRIBUTE_INPUT => @serializer.encode(@properties.from(@job)),
            ATTRIBUTE_TYPE => type
          }

          if has_sdk_intent_id_capability?
            data[ATTRIBUTE_INTENT_ID] = @intent_id
          end

          data[ATTRIBUTE_MAX_PROCESSING_TIME] = @job&.max_processing_time if task? && @job.respond_to?(:max_processing_time)

          if wait?
            event = @job.event
            timestamp, duration = @job._get_timestamp_or_duration
            data[ATTRIBUTE_EVENT] = event.to_s
            data[ATTRIBUTE_TIMESTAMP] = timestamp
            data[ATTRIBUTE_DURATION] = duration
            @log.info(
              'WAIT',
              { 'name' => name, 'event' => event,
                'duration' => duration, 'timestamp' => timestamp },
              Zenaton::Services::Log::TYPE_WAIT
            )
          end

          data
        end

        def type
          return TYPE_WAIT if wait?
          return TYPE_TASK if task?
          # return TYPE_WORKFLOW if workflow?
          raise InternalError, 'Unknown type'
        end

        def wait?
          @job.is_a? Zenaton::Tasks::Wait
        end

        def task?
          @job.is_a? Zenaton::Interfaces::Task
        end

        def workflow?
          @job.is_a? Zenaton::Interfaces::Workflow
        end

        def has_sdk_intent_id_capability?
          Gem.loaded_specs["zenaton"].version >= Gem::Version.new(INTENT_ID_VERSION)
        end
      end
    end
  end
end
