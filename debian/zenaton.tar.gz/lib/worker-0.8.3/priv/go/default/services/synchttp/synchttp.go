package synchttp

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"

	"../log"
	"../zenaton"
)

type msg struct {
	body     interface{}
	response interface{}
}

var client = http.Client{
	Transport: &http.Transport{
		DisableKeepAlives: true,
	},
}

func Get(url string, value interface{}) error {
	//resp, err := client.Get(url)
	resp, err := http.Get(url)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	respBodyBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}

	// when there is no decision, the agent returns "[]"
	if string(respBodyBytes) == "[]" {
		value = nil
		log.Info("MICROSERVER: (get) "+url, msg{response: "[]"}, log.MICROSERVER())
		return nil
	}

	err = fromJSON(respBodyBytes, value)
	if err != nil {
		return err
	}

	jsonValue, err := toJSON(value)
	if err != nil {
		return err
	}

	log.Info("MICROSERVER: (get) "+url, msg{response: string(jsonValue)}, log.MICROSERVER())

	return err
}

func Post(url string, body interface{}, respBody interface{}) error {
	jsonBody, err := toJSON(body)
	if err != nil {
		return err
	}

	response, err := client.Post(url, "application/json", bytes.NewReader(jsonBody))
	if err != nil {
		return zenaton.Errors.Wrap(zenaton.Errors.InternalZenatonError, err)
	}
	defer response.Body.Close()

	respBodyBytes, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return zenaton.Errors.Wrap(zenaton.Errors.InternalZenatonError, err)
	}

	err = fromJSON(respBodyBytes, &respBody)
	if err != nil {
		return err
	}
	//todo: make this look more like the js logging
	log.Info("MICROSERVER: (post) "+url, msg{
		body:     string(jsonBody),
		response: string(respBodyBytes),
	}, log.MICROSERVER())

	return nil
}

//todo: is this used?
func Put(url string, body interface{}) (map[string]interface{}, error) {
	jsonBody, err := toJSON(body)
	if err != nil {
		return nil, err
	}

	request, err := http.NewRequest("PUT", url, bytes.NewReader(jsonBody))
	request.Header.Set("Content-Type", "application/json")

	response, err := client.Do(request)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()

	respBodyBytes, err := ioutil.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}

	var respBody map[string]interface{}
	err = fromJSON(respBodyBytes, &respBody)
	if err != nil {
		return nil, err
	}

	log.Info("MICROSERVER: (put) "+url, msg{
		body:     string(jsonBody),
		response: respBody,
	}, log.MICROSERVER())

	return respBody, nil
}

func toJSON(value interface{}) ([]byte, error) {
	jsonValue, err := json.MarshalIndent(value, "", "    ")
	return jsonValue, zenaton.Errors.Wrap(zenaton.Errors.InternalZenatonError, err)
}

func fromJSON(body []byte, value interface{}) error {
	err := json.Unmarshal(body, value)
	return zenaton.Errors.Wrap(zenaton.Errors.InternalZenatonError, err)
}
