<?php

namespace Zenaton\Services;

trait Is
{
    protected function is($name, $class)
    {
        if (is_string($name)) {
            $implements = @class_implements($name);
            if (is_array($implements)) {
                return isset($implements[$class]);
            }
        }

        return false;
    }
}
