import sys

from zenaton.abstracts.task import Task
from zenaton.abstracts.workflow import Workflow


class ClassChecker:
    """Checks if given classes are workflows or tasks"""

    """:param [String] classes comma separated list of class name"""
    def check(self, classes):
        tasks = []
        workflows = []
        undefined = []
        for klass in classes.split(','):
            getattr(sys.modules[__name__], klass)
        return {'tasks': tasks, 'workflows': workflows, 'undefined': undefined}

    def load_class(self, klass, tasks, workflows, undefined):
        if issubclass(type(klass), Workflow):
            workflows.append(klass)
        elif issubclass(type(klass), Task):
            tasks.append(klass)
        else:
            undefined.append(klass)
