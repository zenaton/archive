<?php

namespace Zenaton\Exceptions;

class ModifiedDeciderException extends ExternalZenatonException
{
}
