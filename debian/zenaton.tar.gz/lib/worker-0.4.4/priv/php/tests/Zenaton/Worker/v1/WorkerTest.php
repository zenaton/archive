<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Services\Serializer;
use Zenaton\Test\Mock\Task\ExecutingClosureTask;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\SingletonTesting;

class WorkerTest extends TestCase
{
    use SingletonTesting;

    public function testProcessExecutesATask()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->once())
            ->method('completeWork')
            ->with('Hello from task')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;
        $worker = new Worker(SimpleReturnValueTask::class, '{"a":{"value":"Hello from task"},"s":[]}', 'abcde');

        $worker->process();
    }

    public function testProcessATaskThrowingAZenatonException()
    {
        $this->expectException(ZenatonException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWorker')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;
        $worker = new Worker(ExecutingClosureTask::class, $serializer->encode([
            'closure' => function () {
                throw new ZenatonException();
            },
        ]), 'abcde');

        $worker->process();
    }

    public function testProcessATaskThrowingANonZenatonException()
    {
        $this->expectException(\RuntimeException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;
        $worker = new Worker(ExecutingClosureTask::class, $serializer->encode([
            'closure' => function () {
                throw new \RuntimeException();
            },
        ]), 'abcde');

        $worker->process();
    }
}
