import json
import os
import platform

output_dict = {'python': {'version': platform.python_version(), 'env': dict(os.environ)}}

print(json.dumps(output_dict))
