# frozen_string_literal: true

require_relative './microserver'
require_relative '../../services/log'
require_relative '../../worker_exceptions'

module Zenaton
  module Worker
    module V1
      class Worker
        def initialize(name, input, custom_hash)
          @microserver = Microserver.instance.tap do |microserver|
            microserver.custom_hash = custom_hash
          end
          input = Services::Serializer.new.decode(input)
          @task = Services::Properties.new.object_from(
            name, input, Zenaton::Interfaces::Task
          )
          Zenaton::Services::Log.new.info(
            "TASK - Input - #{name}",
            input,
            Zenaton::Services::Log::TYPE_TASK
          )
        end

        def process
          begin
            output = @task.handle
          rescue Zenaton::Error => error
            @microserver.fail_worker(error)
            @microserver.reset
            raise error
          rescue StandardError => error
            @microserver.fail_work(error)
            @microserver.reset
            raise error
          end
          @microserver.complete_work(output)
          @microserver.reset
        end
      end
    end
  end
end
