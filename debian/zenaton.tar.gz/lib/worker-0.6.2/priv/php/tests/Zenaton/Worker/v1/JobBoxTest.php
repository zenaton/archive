<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Tasks\Wait;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\Mock\Workflow\NullWorkflow;

class JobBoxTest extends TestCase
{
    public function testGetJobWithUserDefinedTask()
    {
        $jobBox = new JobBox(new SimpleReturnValueTask(42));
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => null,
            'sync' => null,
            'name' => SimpleReturnValueTask::class,
            'input' => '{"a":{"value":42},"s":[]}',
            'type' => 'task',
            'maxProcessingTime' => null,
        ], $job);
    }

    public function testGetJobWithUserDefinedTaskWithSyncAndPositionSet()
    {
        $jobBox = (new JobBox(new SimpleReturnValueTask(42)))
            ->setSync(true)
            ->setPosition('1')
        ;
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '1',
            'sync' => true,
            'name' => SimpleReturnValueTask::class,
            'input' => '{"a":{"value":42},"s":[]}',
            'type' => 'task',
            'maxProcessingTime' => null,
        ], $job);
    }

    public function testGetJobWithAWorkflow()
    {
        $this->expectException(InternalZenatonException::class);

        $jobBox = new JobBox(new NullWorkflow());
        $job = $jobBox->getJob();
    }

    public function testGetJobWithUnconfiguredWaitTask()
    {
        $jobBox = new JobBox(new Wait());
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => null,
            'sync' => null,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":null},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => null,
            'duration' => null,
        ], $job);
    }

    public function testGetJobWithWaitTaskWaitingForATimestamp()
    {
        $timestamp = time() + 3600;
        $jobBox = new JobBox((new Wait())->timestamp($timestamp));
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => null,
            'sync' => null,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":[["timestamp",'.$timestamp.']]},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => $timestamp,
            'duration' => null,
        ], $job);
    }

    public function testGetJobWithWaitTaskWaitingForADuration()
    {
        $jobBox = new JobBox((new Wait())->hours(1));
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => null,
            'sync' => null,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":[["hours",1]]},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => null,
            'duration' => 3600,
        ], $job);
    }
}
