<?php

namespace Zenaton\Loader\Symfony;

use Symfony\Component\HttpKernel\Kernel as Symfony;

class Loader
{
    public function autoload()
    {
        // Load the main autoload file
        if ($file = $this->findAutoload()) {
            require $file;
        }

        if (!class_exists(Symfony::class)) {
            return null;
        }

        // Before symfony 2.8, the AppKernel class was not autoloaded using composer
        if (!class_exists(\AppKernel::class)
            && file_exists($file = getenv('ZENATON_APP_DIR').'/app/AppKernel.php')
        ) {
            require $file;
        }

        return Symfony::VERSION_ID;
    }

    public function boot()
    {
        $kernelClass = $this->guessKernelClass();

        if (!$kernelClass) {
            throw new LoaderException(
                sprintf(
                    'Unable to load the Symfony Kernel. We checked for classes named "%s" and "%s" but none could be found. If you are using a non standard Kernel class name, you will need to write a boot file. See https://zenaton.com/documentation for more information.',
                    \AppKernel::class,
                    \App\Kernel::class
                )
            );
        }

        require __DIR__.'/boot.php';
    }

    private function findAutoload()
    {
        return array_shift(array_filter([
            getenv('ZENATON_APP_DIR').'/app/autoload.php',
            getenv('ZENATON_APP_DIR').'/vendor/autoload.php',
        ], 'file_exists'));
    }

    private function guessKernelClass()
    {
        // Default Kernel class used since Symfony Flex
        if (class_exists(\App\Kernel::class)) {
            return \App\Kernel::class;
        }

        // Default Kernel class used before Symfony Flex
        if (class_exists(\AppKernel::class)) {
            return \AppKernel::class;
        }

        return null;
    }
}
