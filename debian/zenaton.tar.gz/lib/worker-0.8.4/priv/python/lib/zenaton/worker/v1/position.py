class Position:
    """Keeping track of position in queue"""

    SEPARATOR_ASYNC = 'a'
    SEPARATOR_PARALLEL = 'p'

    def __init__(self):
        self.main = 0
        self.counter = 0
        self.position = '0'

    def get(self):
        return self.position

    def next(self):
        self.main += 1
        self.position = str(self.main)
        return self.position

    def next_parallel(self):
        if self.__is_in_parallel():
            self.counter += 1
        else:
            self.main += 1
            self.counter = 0
        self.position = '{}{}{}'.format(self.main, self.SEPARATOR_PARALLEL, self.counter)

    def next_async(self):
        self.main += 1
        self.position = '{}{}'.format(self.main, self.SEPARATOR_ASYNC)

    def __is_in_parallel(self):
        try:
            return self.position.index(self.SEPARATOR_PARALLEL)
        except ValueError:
            return None
