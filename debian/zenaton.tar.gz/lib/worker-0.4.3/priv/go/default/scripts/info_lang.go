package main

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"strings"
)

func main() {

	version := runtime.Version()
	version = strings.TrimLeft(version, "go")

	envVariables := make(map[string]string)
	vars := os.Environ()
	for _, v := range vars {
		parts := strings.Split(v, "=")
		envVariables[parts[0]] = parts[1]
	}

	info := map[string]map[string]interface{}{
		"go": {
			"version": version,
			"env": envVariables,
		},
	}

	jsonInfo, err := json.Marshal(info)
	if err != nil {
		panic(err)
	}

	fmt.Print(string(jsonInfo))
}
