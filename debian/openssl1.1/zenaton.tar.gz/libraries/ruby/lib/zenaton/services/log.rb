# frozen_string_literal: true

module Zenaton
  module Services
    # Module for appending messages to the zenaton.log file
    class Log
      TYPE_NONE = ''
      TYPE_ALL = '*'
      TYPE_DECISION = 'decision'
      TYPE_TASK = 'task'
      TYPE_WAIT = 'wait'
      TYPE_MICROSERVER = 'microserver'
      TYPE_INFRA = 'infra'

      LEVEL_NONE = 0
      LEVEL_INFO = 1
      LEVEL_WARNING = 2
      LEVEL_ERROR = 3

      def initialize
        @log_type = ENV['ZENATON_LOG_TYPE'] || TYPE_NONE
        @log_level = ENV['ZENATON_LOG_LEVEL'].to_i || LEVEL_NONE
        @log_file = "#{ENV['ZENATON_APP_DIR']}/zenaton.log"
      end

      def always(title, msg = '', type = TYPE_NONE)
        log(title, msg, LEVEL_NONE, type)
      end

      def info(title, msg = '', type = TYPE_NONE)
        log(title, msg, LEVEL_INFO, type)
      end

      def warning(title, msg = '', type = TYPE_NONE)
        log(title, msg, LEVEL_WARNING, type)
      end

      def error(title, msg = '', type = TYPE_NONE)
        log(title, msg, LEVEL_ERROR, type)
      end

      private

      def log(title, msg, level, type)
        append_log(title, msg) unless filter_log(level, type)
      end

      def filter_log(level, type)
        @log_level < level || (@log_type != TYPE_ALL && @log_type != type)
      end

      def append_log(title, msg)
        title_string = "==== #{title} ===="
        File.open(@log_file, 'a') do |f|
          f.puts title_string
          f.puts msg
        end
      end
    end
  end
end
