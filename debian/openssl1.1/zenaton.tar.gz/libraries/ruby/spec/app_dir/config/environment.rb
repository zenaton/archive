# frozen_string_literal: true

# Mimicks the boot file path for a Ruby on Rails application

RAILS_BOOT_FILE_LOADED = true
