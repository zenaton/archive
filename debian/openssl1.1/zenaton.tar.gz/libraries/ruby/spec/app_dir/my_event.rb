# frozen_string_literal: true

class MyEvent < Zenaton::Interfaces::Event
end
