# frozen_string_literal: true

require 'timecop'
require 'zenaton/worker/v1/microserver'
require 'zenaton/worker/v1/job_box'
require 'app_dir/my_task'
require 'app_dir/my_event'

RSpec.describe Zenaton::Worker::V1::Microserver do
  subject(:microserver) { described_class.instance }

  let(:http) do
    instance_double(
      Zenaton::Services::SyncHttp,
      get: get_response,
      post: post_response,
      put: put_response
    )
  end

  let(:get_response) { {} }
  let(:post_response) { {} }
  let(:put_response) { {} }

  let(:job) { MyTask.new }
  let(:boxes) { [box] }
  let(:box) do
    Zenaton::Worker::V1::JobBox.new(job).tap do |job|
      job.position = '1'
      job.sync = true
    end
  end

  before { setup }

  describe 'initialization' do
    it 'cannot be initialized' do
      expect { described_class.new }.to raise_error NoMethodError
    end

    it 'is a singleton class' do
      microserver2 = described_class.instance
      expect(microserver).to eq(microserver2)
    end

    it 'stores an instance of the log class' do
      expect(microserver.instance_variable_get(:@log)).to \
        be_a(Zenaton::Services::Log)
    end

    it 'stores an instance of the sync http class' do
      expect(microserver.instance_variable_get(:@http)).to eq(http)
    end

    it 'stores an instance of the workflow instance' do
      expect(microserver.instance_variable_get(:@flow)).to \
        be_a(Zenaton::Worker::V1::Workflow)
    end
  end

  describe 'uuid' do
    before { microserver.uuid = 'my-uuid' }

    it 'sets the uuid' do
      expect(microserver.uuid).to eq('my-uuid')
    end
  end

  describe 'worker version' do
    before { microserver.worker_version = '123' }

    it 'sets the microserver worker version' do
      expect(microserver.instance_variable_get(:@worker_version)).to eq('123')
    end

    it 'is not publicly readable' do
      expect { microserver.worker_version }.to raise_error NoMethodError
    end
  end

  describe 'custom hash' do
    before { microserver.custom_hash = '123' }

    it 'sets the microserver hash' do
      expect(microserver.instance_variable_get(:@custom_hash)).to eq('123')
    end

    it 'is not publicly readable' do
      expect { microserver.custom_hash }.to raise_error NoMethodError
    end
  end

  describe 'reset' do
    before do
      microserver.uuid = 'my-uuid'
      microserver.custom_hash = 'my-hash'
      microserver.worker_version = 'my-worker-version'
    end

    it 'resets the uuid' do
      expect { microserver.reset }.to \
        change(microserver, :uuid).from('my-uuid').to(nil)
    end

    it 'resets the custom hash' do
      expect { microserver.reset }.to \
        change { microserver.instance_variable_get(:@custom_hash) }
        .from('my-hash').to(nil)
    end

    it 'resets the worker version' do
      expect { microserver.reset }.to \
        change { microserver.instance_variable_get(:@worker_version) }
        .from('my-worker-version').to(nil)
    end

    it 'does not reset the log' do
      microserver.reset
      expect(microserver.instance_variable_get(:@log)).not_to be_nil
    end

    it 'does not reset the http client' do
      microserver.reset
      expect(microserver.instance_variable_get(:@http)).not_to be_nil
    end

    it 'does not reset the workflow' do
      microserver.reset
      expect(microserver.instance_variable_get(:@flow)).not_to be_nil
    end
  end

  context 'when microserver has no hash and no uuid' do
    it { is_expected.not_to be_deciding }
    it { is_expected.not_to be_working }
  end

  context 'when microserver has no hash and has uuid' do
    before { microserver.uuid = 'my-uuid' }

    it { is_expected.to be_deciding }
    it { is_expected.not_to be_working }
  end

  context 'when microserver has hash but no uuid' do
    before { microserver.custom_hash = '123' }

    it { is_expected.not_to be_deciding }
    it { is_expected.not_to be_working }
  end

  context 'when microserver has both hash and uuid' do
    before do
      microserver.custom_hash = '123'
      microserver.uuid = 'my-uuid'
    end

    it { is_expected.not_to be_deciding }
    it { is_expected.to be_working }
  end

  describe '#branch_to_execute' do
    let(:get_response) do
      {
        'response' => {
          'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
          'branch' => {
            'type' => 'handle',
            'data' => nil
          }
        }
      }
    end

    before do
      microserver.uuid = '123'
      microserver.worker_version = '1'
    end

    it 'calls the correct endpoint' do
      microserver.branch_to_execute
      expect(http).to have_received(:get).with(
        'http://localhost:4001/api/v_newton/decisions/123/branch?worker_version=1'
      )
    end

    it 'returns the response from the api' do
      expect(microserver.branch_to_execute).to eq(get_response)
    end
  end

  describe '#complete_decision' do
    let(:post_response) { 'ok' }
    let(:http_response) { microserver.complete_decision }

    before do
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    it 'calls the correct endpoint' do
      expect(http).to have_received(:post).with(
        'http://localhost:4001/api/v_newton/decisions/123/branch?worker_version=1',
        'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}'
      )
    end

    it 'returns the response from the api' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#complete_decision_branch' do
    let(:post_response) { 'ok' }

    before do
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
    end

    context 'with no ouput' do
      let(:http_response) { microserver.complete_decision_branch }

      before { http_response }

      it 'calls the correct endpoint' do
        expect(http).to have_received(:post).with(
          'http://localhost:4001/api/v_newton/decisions/123/branch?worker_version=1',
          'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}'
        )
      end

      it 'returns the response from the api' do
        expect(http_response).to eq('ok')
      end
    end

    context 'with some ouput' do
      let(:output) { %w[TaskA TaskB] }
      let(:http_response) { microserver.complete_decision_branch(output) }

      before { http_response }

      it 'calls the correct endpoint' do
        expect(http).to have_received(:post).with(
          'http://localhost:4001/api/v_newton/decisions/123/branch?worker_version=1',
          'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
          'output' => '["TaskA","TaskB"]'
        )
      end

      it 'returns the response from the api' do
        expect(http_response).to eq('ok')
      end
    end
  end

  describe '#fail_decider' do
    let(:http_response) { microserver.fail_decider(error) }
    let(:error) { StandardError.new('Oh no') }
    let(:put_response) { 'ok' }
    let(:expected_body) do
      {
        'error_name' => 'StandardError',
        'error_code' => 0,
        'error_message' => 'Oh no',
        'error_stacktrace' => kind_of(String),
        'failed_at' => 1533118985,
        'status' => 'zenatonFailed'
      }
    end

    before do
      Timecop.freeze(Time.at(1533118985))
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    after { Timecop.return }

    it 'calls the correct endpoint' do
      expect(http).to have_received(:put).with(
        'http://localhost:4001/api/v_newton/decisions/123/?worker_version=1',
        expected_body
      )
    end

    it 'returns the api response' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#fail_decision' do
    let(:http_response) { microserver.fail_decision(error) }
    let(:error) { StandardError.new('Oh no') }
    let(:put_response) { 'ok' }
    let(:expected_body) do
      {
        'error_name' => 'StandardError',
        'error_code' => 0,
        'error_message' => 'Oh no',
        'error_stacktrace' => kind_of(String),
        'failed_at' => 1533118985,
        'status' => 'failed'
      }
    end

    before do
      Timecop.freeze(Time.at(1533118985))
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    after { Timecop.return }

    it 'calls the correct endpoint' do
      expect(http).to have_received(:put).with(
        'http://localhost:4001/api/v_newton/decisions/123/?worker_version=1',
        expected_body
      )
    end

    it 'returns the api response' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#complete_work' do
    let(:output) { 'TaskA' }
    let(:post_response) { 'ok' }
    let(:http_response) { microserver.complete_work(output) }
    let(:expected_body) do
      {
        'status' => 'completed',
        'output' => '{"d":"TaskA","s":[]}',
        'hash' => 'my-hash'
      }
    end

    before do
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    it 'calls the correct endpoint' do
      expect(http).to have_received(:post).with(
        'http://localhost:4001/api/v_newton/tasks/123?worker_version=1',
        expected_body
      )
    end

    it 'returns the response from the api' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#fail_worker' do
    let(:http_response) { microserver.fail_worker(error) }
    let(:error) { StandardError.new('Oh no') }
    let(:post_response) { 'ok' }
    let(:expected_body) do
      {
        'error_name' => 'StandardError',
        'error_code' => 0,
        'error_message' => 'Oh no',
        'error_stacktrace' => kind_of(String),
        'failed_at' => 1533118985,
        'status' => 'zenatonFailed',
        'error_input' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
        'hash' => 'my-hash'
      }
    end

    before do
      Timecop.freeze(Time.at(1533118985))
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    after { Timecop.return }

    it 'calls the correct endpoint' do
      expect(http).to have_received(:post).with(
        'http://localhost:4001/api/v_newton/tasks/123?worker_version=1',
        expected_body
      )
    end

    it 'returns the api response' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#fail_work' do
    let(:http_response) { microserver.fail_work(error) }
    let(:error) { StandardError.new('Oh no') }
    let(:post_response) { 'ok' }
    let(:expected_body) do
      {
        'error_name' => 'StandardError',
        'error_code' => 0,
        'error_message' => 'Oh no',
        'error_stacktrace' => kind_of(String),
        'failed_at' => 1533118985,
        'status' => 'failed',
        'error_input' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
        'hash' => 'my-hash'
      }
    end

    before do
      Timecop.freeze(Time.at(1533118985))
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      http_response
    end

    after { Timecop.return }

    it 'calls the correct endpoint' do
      expect(http).to have_received(:post).with(
        'http://localhost:4001/api/v_newton/tasks/123?worker_version=1',
        expected_body
      )
    end

    it 'returns the api response' do
      expect(http_response).to eq('ok')
    end
  end

  describe '#execute' do
    let(:output) { microserver.execute(boxes) }
    let(:expected_post_body) do
      {
        'works' => [{
          'position' => '1',
          'sync' => true,
          'name' => 'MyTask',
          'input' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
          'type' => 'task'
        }]
      }
    end

    before do
      microserver.uuid = '123'
      microserver.worker_version = '1'
      microserver.custom_hash = 'my-hash'
      output
    end

    it 'calls the correct url' do
      expect(http).to have_received(:post).with(
        'http://localhost:4001/api/v_newton/decisions/123/execute?worker_version=1',
        expected_post_body
      )
    end

    context 'when the response status is not completed' do
      let(:post_response) { { 'status' => 'scheduled' } }

      it 'returns the api response' do
        expect(output).to eq('status' => 'scheduled')
      end
    end

    context 'when the response status is completed but outputs is empty' do
      let(:post_response) do
        { 'status' => 'completed', 'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}', 'outputs' => [] }
      end

      it 'deserializes the properties key' do
        expect(output['properties']).to eq({})
      end
    end

    context 'when the response status is completed and outputs contains an event' do
      let(:post_response) do
        {
          'status' => 'completed',
          'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
          'outputs' => [{ 'event_name' => 'MyEvent', 'event_input' => '{"o":"@zenaton#0","s":[{"a":{}}]}' }]
        }
      end

      it 'deserializes the event' do
        expect(output['outputs'].first).to be_a(MyEvent)
      end
    end

    context 'when the response status is completed and outputs contains serialized data' do
      let(:post_response) do
        {
          'status' => 'completed',
          'properties' => '{"o":"@zenaton#0","s":[{"a":{}}]}',
          'outputs' => ['{"d":"TaskA","s":[]}']
        }
      end

      it 'deserializes the outputs' do
        expect(output['outputs'].first).to eq('TaskA')
      end
    end
  end

  def setup
    Singleton.__init__(described_class)
    allow(Zenaton::Services::SyncHttp).to \
      receive(:new).and_return(http)
  end
end
