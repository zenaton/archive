# frozen_string_literal: true

require 'support/stub_http'
require 'zenaton/services/sync_http'

RSpec.describe Zenaton::Services::SyncHttp do
  let(:sync_http) { described_class.new }
  let(:log) { instance_double(Zenaton::Services::Log, info: nil) }

  # Don't write any logs during this test
  before { sync_http.instance_variable_set(:@log, log) }

  describe '#get' do
    let(:url) { 'https://jsonplaceholder.typicode.com/posts/1' }
    let(:response) { sync_http.get(url) }
    # rubocop:disable Metrics/LineLength
    let(:expected_response) do
      {
        'userId' => 1,
        'id' => 1,
        'title' => 'sunt aut facere repellat provident occaecati excepturi optio reprehenderit',
        'body' => "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      }
    end
    # rubocop:enable Metrics/LineLength

    around do |example|
      VCR.use_cassette('get_request_200') { example.run }
    end

    it 'fetches some json' do
      expect(response).to eq(expected_response)
    end

    it 'logs the received data' do
      response
      expect(log).to have_received(:info)
        .with("MICROSERVER: (get) #{url}", /response/, 'microserver')
    end
  end

  describe '#post' do
    let(:url) { 'https://jsonplaceholder.typicode.com/posts' }
    let(:body) { { title: 'title', body: 'body', userId: 1 } }
    let(:response) { sync_http.post(url, body) }
    let(:expected_response) do
      {
        'id' => 101,
        'title' => 'title',
        'body' => 'body',
        'userId' => '1'
      }
    end

    around do |example|
      VCR.use_cassette('post_request_200') { example.run }
    end

    it 'fetches some json' do
      expect(response).to eq(expected_response)
    end

    it 'logs the request data' do
      response
      expect(log).to have_received(:info)
        .with("MICROSERVER: (post) #{url}", /body/, 'microserver')
    end
  end

  describe '#put' do
    let(:url) { 'https://jsonplaceholder.typicode.com/posts/1' }
    let(:body) { { id: 1, title: 'title', body: 'body', userId: 1 } }
    let(:response) { sync_http.put(url, body) }
    let(:expected_response) do
      {
        'id' => 1,
        'title' => 'title',
        'body' => 'body',
        'userId' => '1'
      }
    end

    around do |example|
      VCR.use_cassette('put_request_200') { example.run }
    end

    it 'fetches some json' do
      expect(response).to eq(expected_response)
    end

    it 'logs the request data' do
      response
      expect(log).to have_received(:info)
        .with("MICROSERVER: (put) #{url}", /body/, 'microserver')
    end
  end
end
