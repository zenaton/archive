# frozen_string_literal: true

require 'zenaton/loader/loader'

RSpec.describe Zenaton::Loader::Loader do
  let(:loader) { described_class.new(*params) }

  before { ENV.delete('ZENATON_APP_DIR') }

  after { ENV.delete('ZENATON_APP_DIR') }

  describe 'initialization' do
    let(:params) do
      ['status=192.168.0.1', 'app=./spec/app_dir/']
    end

    it 'converts string params into a hash' do
      expect(loader.instance_variable_get(:@args)).to \
        eq(
          'status' => '192.168.0.1',
          'app' => './spec/app_dir/'
        )
    end

    it 'sets a status url' do
      expect(loader.instance_variable_get(:@status)).to eq('192.168.0.1')
    end

    it 'does not set a framework' do
      expect(loader.instance_variable_get(:@framework)).to be_nil
    end

    it 'sets an app dir without trailing /' do
      expect(loader.instance_variable_get(:@app_dir)).to eq('./spec/app_dir')
    end

    it 'sets the app dir as an environment variable' do
      loader
      expect(ENV['ZENATON_APP_DIR']).to eq('./spec/app_dir')
    end
  end

  describe '#boot' do
    context 'with a boot file' do
      let(:params) do
        ['status=192.168.0.1', 'app=./spec/app_dir/', 'boot=./boot.rb']
      end

      before { loader.boot }

      it 'requires the boot file' do
        expect(IS_BOOT_FILE_LOADED).to eq(true)
      end
    end

    context 'without a boot file' do
      let(:params) do
        ['status=192.168.0.1', 'app=./spec/app_dir/', 'framework=rails']
      end

      before { loader.boot }

      it 'requires rails boot file' do
        expect(RAILS_BOOT_FILE_LOADED).to eq(true)
      end
    end
  end
end
