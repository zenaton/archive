# frozen_string_literal: true

require 'zenaton/loader/class_checker'

RSpec.describe Zenaton::Loader::ClassChecker do
  let(:checker) { described_class.new }
  let(:loaded_classes) { checker.check(' MyWorkflow, MyTask, MyRandomClass ') }

  before do
    class MyWorkflow < Zenaton::Interfaces::Workflow; end
    class MyTask < Zenaton::Interfaces::Task; end
    class MyRandomClass; end
  end

  it 'loads workflows' do
    expect(loaded_classes[:workflows]).to eq([MyWorkflow])
  end

  it 'loads tasks' do
    expect(loaded_classes[:tasks]).to eq([MyTask])
  end

  it 'loads custom classes' do
    expect(loaded_classes[:undefined]).to eq([MyRandomClass])
  end
end
