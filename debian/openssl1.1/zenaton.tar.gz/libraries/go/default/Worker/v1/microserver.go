package v1

import (
	"errors"
	"time"

	"encoding/json"

	"../../services/log"
	"../../services/synchttp"
	"../../services/zenaton"
)

var instance *MicroServer

type MicroServer struct {
	flow *Workflow
	//todo: why put http here instead of just using the synchttp directly?
	uuid          string
	workerVersion string
	hash          string
}

func NewMicroServer() *MicroServer {
	if instance == nil {
		instance = &MicroServer{
			flow: NewWorkflow(),
		}
	}
	return instance
}

func (ms *MicroServer) getUUID() string {
	return ms.uuid
}

func (ms *MicroServer) SetUUID(uuid string) *MicroServer {
	ms.uuid = uuid
	return ms
}

func (ms *MicroServer) SetWorkerVersion(workerVersion string) *MicroServer {
	ms.workerVersion = workerVersion
	return ms
}

func (ms *MicroServer) setHash(hash string) *MicroServer {
	ms.hash = hash
	return ms
}

func (ms *MicroServer) reset() *MicroServer {
	ms.uuid = ""
	ms.hash = ""
	ms.workerVersion = ""
	return ms
}

func (ms *MicroServer) IsDeciding() bool {
	return ms.hash == "" && ms.uuid != ""
}

func (ms *MicroServer) IsWorking() bool {
	return ms.hash != "" && ms.uuid != ""
}

type Branch struct {
	Branch     BranchBranch `json:"branch"`
	Properties string       `json:"properties"`
}

type BranchBranch struct {
	Type string     `json:"type"`
	Data BranchData `json:"data"`
}

type BranchData struct {
	EventName  string      `json:"event_name"`
	EventInput string      `json:"event_input"`
	TaskName   string      `json:"task_name"`
	TaskInput  string      `json:"task_input"`
	TaskOutput interface{} `json:"task_output"`
}

func (ms *MicroServer) getBranchToExecute() *Branch {
	url := ms.decisionURL("branch")
	var b Branch
	err := synchttp.Get(url, &b)
	if err != nil {
		panic(err)
	}

	log.Info("DECISION - Branch - (get) "+url, log.LogMSG{
		Response: b,
	}, log.DECISION())
	return &b
}

type ExecuteResponse struct {
	Status        string        `json:"status"`
	Properties    string        `json:"properties"`
	OutputStrings []interface{} `json:"outputs"`
	Outputs       []string
}

//todo: check that all the types are as they should be in here, a lot of interface{}, maybe can do better
func (ms *MicroServer) execute(boxes []*JobBox) ExecuteResponse {

	type BodyType struct {
		Works []map[string]interface{} `json:"works"`
	}

	var jobInfos []map[string]interface{}
	for _, box := range boxes {
		jobInfos = append(jobInfos, box.getJob())
	}

	url := ms.decisionURL("execute")
	body := BodyType{Works: jobInfos}

	var response ExecuteResponse
	err := synchttp.Post(url, body, &response)
	if err != nil {
		panic(err)
	}

	if response.Status == "completed" {

		// decode outputs (output can be null, eg. wait task)
		for _, output := range response.OutputStrings {
			eventMap, ok := output.(map[string]interface{})
			if ok { //output is an event
				jsonEvent, err := json.Marshal(eventMap)
				if err != nil {
					panic(err)
				}
				response.Outputs = append(response.Outputs, string(jsonEvent))
			} else { // else return unserialized output
				if output == nil {
					continue
				}
				response.Outputs = append(response.Outputs, output.(string))
			}
		}
	}

	log.Info("DECISION - Execute - (post) -"+url, log.LogMSG{
		Body:     body,
		Response: response,
	}, log.DECISION())

	return response
}

func (ms *MicroServer) completeDecision() map[string]interface{} {

	type requestBody struct {
		Properties string `json:"properties"`
	}
	url := ms.decisionURL("branch")

	encodedProperties, err := zenaton.Serializer.Encode(ms.flow.getProperties())
	if err != nil {
		panic(err)
	}

	body := requestBody{
		Properties: encodedProperties,
	}

	//todo: get rid of all these unnecessary map[string]inteface{}
	var response map[string]interface{}
	err = synchttp.Post(url, body, &response)
	if err != nil {
		panic(err)
	}

	log.Info("DECISION - Complete - "+url, log.LogMSG{
		Body:     body,
		Response: response,
	}, log.DECISION())

	return response
}

func (ms *MicroServer) completeDecisionBranch(output interface{}) map[string]interface{} {
	type requestBody struct {
		Properties string `json:"properties"`
		Output     string `json:"output,omitempty"`
	}

	url := ms.decisionURL("branch")

	properties, err := zenaton.Serializer.Encode(ms.flow.getProperties())
	if err != nil {
		panic(err)
	}
	body := requestBody{
		Properties: properties,
	}

	if output != nil {
		body.Output, err = zenaton.Serializer.Encode(output)
		if err != nil {
			panic(err)
		}
	}

	var response map[string]interface{}
	err = synchttp.Post(url, body, &response)
	if err != nil {
		panic(err)
	}

	log.Info("DECISION - Complete Branch - "+url, log.LogMSG{Body: body, Response: response}, log.DECISION())

	return response
}

type body struct {
	//todo: confirm these json tags
	Output          string `json:"output,omitempty,omitempty"`
	Status          string `json:"status,omitempty"`
	ErrorName       string `json:"error_name"`
	ErrorInput      string `json:"error_input,omitempty"`
	ErrorCode       int    `json:"error_code"`
	ErrorMessage    string `json:"error_message,omitempty"`
	ErrorStacktrace string `json:"error_stacktrace"`
	FailedAt        int64  `json:"failed_at,omitempty"`
	Hash            string `json:"hash,omitempty"`
}

func (ms *MicroServer) FailDecider(name, message, stack string) {
	url := ms.decisionURL("")
	b := body{
		Status:          "zenatonFailed",
		ErrorCode:       0,
		ErrorMessage:    message,
		ErrorName:       name,
		ErrorStacktrace: stack,
		FailedAt:        time.Now().Unix(), //todo: the right number of digits?
	}

	response, err := synchttp.Put(url, b)
	if err != nil {
		panic(err)
	}

	log.Info("DECISION - Decision Failure - "+url, log.LogMSG{
		Body:     b,
		Response: response,
	}, log.DECISION())
}

func (ms *MicroServer) failDecision(name, message, stack string) map[string]interface{} {
	url := ms.decisionURL("")
	b := body{
		Status:          "failed",
		ErrorCode:       0,
		ErrorMessage:    message,
		ErrorName:       name,
		ErrorStacktrace: stack,
		FailedAt:        time.Now().Unix(), //todo: the right number of digits?
	}
	response, err := synchttp.Put(url, b)
	if err != nil {
		panic(err)
	}

	log.Info("DECISION - Decision Failure - "+url, log.LogMSG{
		Body:     b,
		Response: response,
	}, log.DECISION())

	return response
}

func (ms *MicroServer) completeWork(output interface{}) error {

	var encodededOutput string
	var err error

	if output != nil {
		encodededOutput, err = zenaton.Serializer.Encode(output)
		if err != nil {
			panic(err)
		}
	}
	ms.sendWork(body{
		Status: "completed",
		Output: encodededOutput,
	})

	return errors.New("bob")
}

//todo: figure out the javascript error handling and duplicate the results
func (ms *MicroServer) FailWorker(name, message, stack string) {

	//encodedErrorInput, err := zenaton.Serializer.Encode(e)
	//if err != nil {
	//	panic(err)
	//}

	ms.sendWork(body{
		Status:          "zenatonFailed",
		ErrorName:       name,
		ErrorInput:      message,
		ErrorCode:       0,
		ErrorMessage:    message,
		ErrorStacktrace: stack,
		FailedAt:        time.Now().Unix(), //todo: make sure correct digits
	})
}

func (ms *MicroServer) failWork(name, message, stack string) {

	//todo: what is errorInput?
	encodedErrorInput, err := zenaton.Serializer.Encode(message)
	if err != nil {
		panic(err)
	}

	ms.sendWork(body{
		Status:          "failed",
		ErrorName:       name,
		ErrorInput:      encodedErrorInput,
		ErrorCode:       0,
		ErrorMessage:    message,
		ErrorStacktrace: stack,
		FailedAt:        time.Now().Unix(), //todo: make sure correct digits
	})
}

func (ms *MicroServer) sendWork(b body) {
	url := ms.getWorkerUrl("tasks/"+ms.uuid, "worker_version="+ms.workerVersion)
	b.Hash = ms.hash
	var response string
	err := synchttp.Post(url, b, &response)

	//todo: response here isn't a map[string]interface, shouldn't return that from post
	//fmt.Printf("sendWork response: %+v\n\n", response)
	if err != nil {
		panic(err)
	}
	log.Info("Task - Send - (post) "+url, log.LogMSG{
		Body:     b,
		Response: response,
	}, log.TASK())
}

func (ms *MicroServer) decisionURL(endpoint string) string {
	return ms.getWorkerUrl("decisions/"+ms.uuid+"/"+endpoint, "worker_version="+ms.workerVersion)
}

func (ms *MicroServer) getWorkerUrl(resource string, params string) string {
	// taking url from client ensures we use same Worker API version than user library
	return getWorkerUrl(resource, params)
}

//todo: ms is copied from the client library for now. Should actually use the client library
func getWorkerUrl(resources string, params string) string {
	return zenaton.Client.GetWorkerUrl(resources, params)
}
