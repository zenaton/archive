package v1

import (
	"../../services/zenaton"
)

type Workflow struct {
	flow     *zenaton.Workflow
	name     string
	branch   *Branch
	position *Position
}

var workflowInstance *Workflow

func NewWorkflow() *Workflow {
	if workflowInstance == nil {
		workflowInstance = &Workflow{
			position: NewPosition(),
		}
	}
	return workflowInstance
}

func (wf *Workflow) setWorkflowName(name string) *Workflow {
	wf.name = name
	return wf
}

func (wf *Workflow) init(branch *Branch, properties string) error {

	wfInstance, err := zenaton.WorkflowManager.GetInstance(wf.name, properties)

	if err != nil {
		return err
	}

	wf.flow = wfInstance
	if err != nil {

	}

	wf.branch = branch

	wf.position.init()

	return nil
}

func (wf *Workflow) runBranch() (interface{}, error) {

	if wf.branch.Branch.Type == "handle" {
		return wf.flow.Handle()
	}

	if wf.branch.Branch.Type == "onEvent" {

		if wf.flow.OnEventer != nil {
			var input interface{}
			zenaton.Serializer.Decode(wf.branch.Branch.Data.EventInput, input)
			wf.flow.OnEvent(wf.branch.Branch.Data.EventName, input)
		}

		return nil, nil
	}

	//if wf.branch.Branch.Type == "onStart" {
	//	//fmt.Println("onStart")
	//	task := zenaton.TaskManager.GetTask(wf.branch.Branch.Data.TaskName, wf.branch.Branch.Data.TaskInput)
	//	wf.flow.OnStart(task)
	//	return nil, nil
	//}
	//
	if wf.branch.Branch.Type == "onSuccess" {
		//fmt.Println("onSuccess")
		//task := zenaton.TaskManager.GetTask(wf.branch.Branch.Data.TaskName, wf.branch.Branch.Data.TaskInput)
		var output interface{}
		//todo: can I just check that it's a wait some other way? what if someone names their task _Wait?
		if wf.branch.Branch.Data.TaskName != "_Wait" && wf.branch.Branch.Data.TaskOutput != nil {
			err := zenaton.Serializer.Decode(wf.branch.Branch.Data.TaskOutput.(string), &output)
			if err != nil {
				panic(err)
			}
		}
		//wf.flow.OnSuccess(task, output)
		return nil, nil
	}

	//if wf.branch.Branch.Type == "onFailure"{
	//  if wf.flow.OnFailure != nil {
	//    task := taskManager.GetTask(wf.branch.Branch.Data.TaskName, wf.branch.Branch.Data.TaskInput)
	//
	//    var error = new Error()
	//
	//    // wf.branch.Branch.Data.errorName wf.branch.Branch.Data.errorInput
	//    wf.flow.OnFailure(task, error)
	//    return nil
	//  }
	//}

	//if wf.branch.Branch.Type == "onTimeout" {
	//	//fmt.Println("onTimeout")
	//	if wf.flow.OnTimeout != nil {
	//		task := zenaton.TaskManager.GetTask(wf.branch.Branch.Data.TaskName, wf.branch.Branch.Data.TaskInput)
	//
	//		wf.flow.OnTimeout(task)
	//		return nil, nil
	//	}
	//}

	return nil, nil
}

func (wf *Workflow) getProperties() interface{} {
	//return wf.flow.GetData()
	return wf.flow.GetData()
}

func (wf *Workflow) setProperties(encoded string) error {
	err := zenaton.Serializer.Decode(encoded, wf.flow)
	return err
}

func (wf *Workflow) getPosition() string {
	return wf.position.get()
}

func (wf *Workflow) next() {
	wf.position.next()
}

func (wf *Workflow) nextParallel() {
	wf.position.nextParallel()
}

func (wf *Workflow) nextAsync() {
	wf.position.nextAsync()
}
