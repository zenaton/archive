/* global process */

// Just checking presence and version of node
process.stdout.write('version=' + process.version.substr(1))
