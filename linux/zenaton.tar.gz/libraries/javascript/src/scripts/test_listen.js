/* global process */

const Loader = require('../Loader/Loader')

let args = process.argv
// remove first 2 elements
args.splice(0,2)

// load class
let loader = new Loader(args)

// load boot file
loader.boot()

// check parameters
loader.checkClasses()
