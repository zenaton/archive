const { InternalZenatonError } = require('../Services/Zenaton').Errors
const { workflowManager, taskManager } = require('../Services/Zenaton')
const ZenatonError = require('./Errors/ZenatonError')

const Microserver = require('../Worker/v1/Microserver')
const Decider = require('../Worker/v1/Decider')
const Worker = require('../Worker/v1/Worker')
const Processor = require('../Worker/v1/Processor')
const { Engine } = require('../Services/Zenaton')
const SyncHttp = require('../Services/SyncHttp')
const Log = require('../Services/Log')

const DECISION_SCHEDULED = 'DecisionScheduled'
const TASK_SCHEDULED = 'TaskScheduled'

module.exports = class Slave {
	constructor(job) {
		// url to retrieve job
		this.job = job
		// init http service
		this.http = new SyncHttp()
		// init log service
		this.log = new Log()
	}

	process() {
		// get job to do
		let job = this.getJob()

		// check sources version
		if (this.isWorkflow(job.name) || this.isTask(job.name) ) {
			return this.processJob(job)
		}

		throw new ZenatonError('Unknown job type for "' + job.name + '", you should probably update your Zenaton worker')
	}

	processJob(job) {
		// set uuid and worker version for calls to microserver
		new Microserver().setUuid(job.uuid).setWorkerVersion(job.worker_version)

		// inject processor in Zenaton library engine ;-)
		new Engine().setProcessor(new Processor())

		// launch decider or worker
		switch (job.action) {
		case DECISION_SCHEDULED:
			new Decider(job.name).launch()
			break
		case TASK_SCHEDULED:
			new Worker(job.name, job.input, job.hash).process()
			break
		default:
			throw new InternalZenatonError('Error - unknown action: ' + job.action)
		}
	}

	/*
     * Get job to perform
     */
	getJob() {
		let response = this.http.get(this.job)

		Log.info('INFRA - Ask Job - (get) ' + this.job, {response: response}, Log.TYPE_INFRA)

		return response
	}

	isWorkflow(name) {
		return undefined !== workflowManager.getClass(name)
	}

	isTask(name) {
		return undefined !== taskManager.getClass(name)
	}
}
