const { InternalZenatonError, ScheduledBoxError } = require('../../Services/Zenaton').Errors
const Workflow = require('./Workflow')
const Microserver = require('./Microserver')

module.exports = class Decider {
	constructor(name) {
		this.microserver = new Microserver()
		this.flow = new Workflow().setWorkflowName(name)
	}

	launch() {
		let response = this.microserver.getBranchToExecute()
		while (('object' === typeof response) && (Object.keys(response).length > 0)) {

			this.flow.init(response.branch, response.properties)
			this.process()

			response = this.microserver.getBranchToExecute()
		}

		this.microserver.reset()
	}

	process() {
		let output
		try {
			output = this.flow.runBranch()
		} catch (e) {

			if (e instanceof ScheduledBoxError) {
				this.microserver.completeDecision()
				return
			}

			if (e instanceof InternalZenatonError) {
				this.microserver.failDecider(e)
				this.microserver.reset()
				throw e
			}

			this.microserver.failDecision(e)
			this.microserver.reset()
			throw e
		}

		this.microserver.completeDecisionBranch(output)
	}
}
