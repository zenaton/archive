const Workflow = require('./Workflow')
const Microserver = require('./Microserver')
const JobBox = require('./JobBox')
let {workflowManager, taskManager, Client} = require('../../Services/Zenaton')
const {ScheduledBoxError, InternalZenatonError, ModifiedDeciderError} = require('../../Services/Zenaton').Errors

const STATUS_MODIFIED = 'modified'
const STATUS_SCHEDULED = 'scheduled'
const STATUS_COMPLETED = 'completed'

module.exports = class {
	constructor() {
		this.microserver = new Microserver()
		this.flow = new Workflow()
	}

	process(boxes, isSync) {
		if (this.microserver.isWorking()) {
			return this.processFromTask(boxes, isSync)
		}
		if (this.microserver.isDeciding()) {
			return this.processFromWorkflow(boxes, isSync)
		}
		throw new InternalZenatonError('process: Unknown state')
	}

	processFromTask(boxes, isSync)
	{
		let client = new Client

		let outputs = []
		// handle sync executions and dispatch async
		boxes.forEach(box => {
			if (undefined !== workflowManager.getClass(box.name)) {
				if (isSync) {
					outputs.push(box.handle())
				} else {
					outputs.push(client.startWorkflow(box))
				}
			} else if (undefined !== taskManager.getClass(box.name)) {
				if (isSync) {
					outputs.push(box._promiseHandle())
				} else {
					// outputs.push(client.startTask(box))
					outputs.push(box._promiseHandle())
				}
			} else {
				throw new InternalZenatonError('processFromTask: Unknown type')
			}
		})

		// return results
		return outputs
	}

	processFromWorkflow(boxes, isSync) {
		// construct array of decorated boxes
		let dboxes = []
		boxes.forEach(box => {
			// Go to the next position
			if (! isSync) {
				this.flow.nextAsync()
			} else if (boxes.length > 1) {
				this.flow.nextParallel()
			} else {
				this.flow.next()
			}
			//
			dboxes.push((new JobBox(box)).setSync(isSync).setPosition(this.flow.getPosition()))
		})

		// schedule task or get result if already done
		let response = this.microserver.execute(dboxes)

		// Decider was modified
		if (response.status === STATUS_MODIFIED) {
			throw new ModifiedDeciderError(
				'"' + this.flow.name + '" has been modified since launch of current instance.' +
				'\nYou can\'t. Seriously.\nSee https://zenaton.com/documentation#workflow-versioning-for-running-instances'
			)
		}

		// Nothing more to do for asynchronous execution
		if (! isSync) {
			// return an array full of undefined
			return Array.apply(null, {length: boxes.length})
		}

		if (response.status === STATUS_SCHEDULED) {
			throw new ScheduledBoxError()
		}

		if (response.status === STATUS_COMPLETED) {
			// Set properties for last execution
			this.flow.setProperties(response.properties)

			// return output
			return response.outputs
		}

		throw new InternalZenatonError('processFromWorkflow: InputBox with Unkwnon status at position '.this.flow.getPosition())
	}
}
