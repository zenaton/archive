<?php

use Zenaton\Services\Loader;
use Zenaton\Exception\LoaderException;

// do not display errors on stdout
ini_set("display_errors", 'stderr');

// autoload our classes
require __DIR__ . '/../vendor/autoload.php';

// load class
$loader = new Loader($argv, __FILE__);

// load boot file
$loader->boot();

// check parameters
$loader->checkClasses();
