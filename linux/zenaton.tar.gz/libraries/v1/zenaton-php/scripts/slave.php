<?php

use Zenaton\Services\Loader;
use Zenaton\Exceptions\LoaderException;

use Zenaton\Exceptions\ExternalZenatonException;
use Zenaton\Worker\MicroServer;
use Zenaton\Worker\Slave;

try {
    $ok = false;

    // autoload our classes
    require __DIR__ . '/../vendor/autoload.php';

    // load class
    $loader = new Loader($argv, __FILE__);

    // load boot file
    $loader->boot();

    // get envId
    $envId = $loader->getEnvId();
    // create Slave getInstance
    $slave = new Slave($envId);

    // define shutdown to catch non-thrown error
    function shutdown()
    {
        $ms = MicroServer::getInstance();

        $last = error_get_last();
        $str = '"'.$last['message'].'" on line '.$last['line'].' in file "'.$last['file'].'"';
        $e = new ExternalZenatonException($str);

        if ($ms->isWorking()) {
            $ms->failWorker($e);
        }

        if ($ms->isDeciding()) {
            $ms->failDecider($e);
        }
    }
    register_shutdown_function('shutdown');

    // we have all what we need
    $ok = true;
    $loader->success();

} catch (LoaderException $e) {
    $msg = $e->getMessage();
    echo $msg;
    if (!$ok || strlen($msg) > 0) return;
} catch (\Exception $e) {
    echo $e->getMessage() . PHP_EOL;
    echo $e->getTraceAsString();
    return;
}
// we arrive here only if everything went well, including the success() call to url
$slave->process();
