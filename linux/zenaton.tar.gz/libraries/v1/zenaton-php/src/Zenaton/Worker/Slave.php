<?php

namespace Zenaton\Worker;

use Zenaton\Worker\Decider;
use Zenaton\Worker\Worker;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Engine\Engine;
use Zenaton\Processer;

class Slave
{
    protected $microserver;
    protected $type;
    protected $workerVersion;

    public function __construct($uuid, $type, $workerVersion)
    {
        $this->microserver = MicroServer::getInstance()->setUuid($uuid)->setWorkerVersion($workerVersion);
        $this->type = $type;
        // inject Processer in Zenaton library
		Engine::getInstance()->setProcesser(Processer::getInstance());
    }

    public function process()
    {
        $response = $this->microserver->askJob($this->type);

        switch ($response->action) {
            case 'DecisionScheduled':
                (new Decider($response->name))->launch();
                break;
            case 'TaskScheduled':
                (new Worker($response->name, $response->input, $response->hash))->process();
                break;
            default:
                throw new InternalZenatonException('Error - unknown action in result: ' . $response->action);
        }
    }

}
