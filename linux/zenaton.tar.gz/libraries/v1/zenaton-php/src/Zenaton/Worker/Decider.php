<?php

namespace Zenaton\Worker;

use Exception;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ScheduledBoxException;

class Decider
{
    protected $microserver;
    protected $flow;

    public function __construct($name)
    {
        $this->microserver = MicroServer::getInstance();
        $this->flow = Workflow::getInstance()->setWorkflowName($name);
    }

    public function launch()
    {
        while ($response = $this->microserver->getBranchToExecute()) {
            $this->flow->init($response->branch, $response->properties);
            $this->process();
        }
        $this->microserver->reset();
    }

    public function process()
    {
        // do workflow
        try {
            $output = $this->flow->runBranch();
        } catch (ScheduledBoxException $e) {
            $this->microserver->completeDecision();
            return;
        } catch (InternalZenatonException $e) {
            $this->microserver->failDecider($e);
            // terminate this decision
            $this->microserver->reset();
            throw $e;
        } catch (Exception $e) {
            $this->microserver->failDecision($e);
            // terminate this decision
            $this->microserver->reset();
            throw $e;
        }

        // send result to microserver
        $this->microserver->completeDecisionBranch($output);
    }
}
