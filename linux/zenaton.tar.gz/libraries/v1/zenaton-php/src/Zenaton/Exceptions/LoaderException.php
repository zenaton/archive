<?php

namespace Zenaton\Exceptions;

class LoaderException extends \Exception
{
}
