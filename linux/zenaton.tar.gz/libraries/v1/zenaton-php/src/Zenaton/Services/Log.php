<?php

namespace Zenaton\Services;

class Log
{
    const TYPE_NONE = '';
    const TYPE_ALL = '*';
    const TYPE_DECISION = 'decision';
    const TYPE_TASK = 'task';
    const TYPE_WAIT = 'wait';
    const TYPE_MICROSERVER = 'microserver';
    const TYPE_INFRA = 'infra';

    const LEVEL_NONE = 0;
    const LEVEL_INFO = 1;
    const LEVEL_WARNING = 2;
    const LEVEL_ERROR = 3;

    protected $logLevel;
    protected $logType;

    public function __construct()
    {
        $level = getenv('ZENATON_LOG_LEVEL');
        $type = getenv('ZENATON_LOG_TYPE');
        $this->logLevel = is_null($level) ? self::LEVEL_NONE : (int) $level;
        $this->logType = is_null($type) ? self::TYPE_NONE : $type;
    }

    public function always($title, $msg = '', $type = self::TYPE_NONE)
    {
    	return $this->log($title, $msg, self::LEVEL_NONE, $type);
    }

    public function info($title, $msg = '', $type = self::TYPE_NONE)
    {
    	return $this->log($title, $msg, self::LEVEL_INFO, $type);
	}

    public function warning($title, $msg = '', $type = self::TYPE_NONE)
    {
    	return $this->log($title, $msg, self::LEVEL_WARNING, $type);
    }

    public function error($title, $msg = '', $type = self::TYPE_NONE)
    {
    	return $this->log($title, $msg, self::LEVEL_ERROR, $type);
    }

    protected function log($title, $msg, $level, $type)
    {
        if ($this->logLevel >= $level && (self::TYPE_ALL === $this->logType || $this->logType === $type)) {
			echo('==== ' . $title . ' ====' . PHP_EOL);
			var_dump($msg);
            echo('===============' . PHP_EOL);
		}
    }
}
