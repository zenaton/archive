<?php

namespace Zenaton\Services;

use Zenaton\Exceptions\LoaderException;
use Zenaton\Client as Zenaton;

class Loader
{
    protected $args;
    protected $file;
    protected $url;
    protected $framework;
    protected $appDir;
    protected $http;

    const PARAM_URL = 'url';
    const PARAM_BOOT_FILE = 'boot';
    const PARAM_APP_DIR = 'app';
    const PARAM_FRAMEWORK = 'framework';
    const PARAM_CLASSES = 'classes';
    const PARAM_UUID = 'uuid';
    const PARAM_TYPE = 'type';
    const PARAM_WORKER_VERSION = 'version';
    const FRAMEWORK_LARAVEL = 'laravel';

    public function __construct($args, $file = '')
    {
        // parse $args into $this->args
        parse_str(implode('&', array_slice($args, 1)), $this->args);

        // store calling file
        $this->file = $file;
        // provided url
        $this->url = $this->getUrl();
        // init http service
        $this->http = new SyncHttp();
        // get framework, if any
        $this->framework = $this->getFramework(false);
        // app directory
        $this->appDir = $this->getAppDir();
        // store this in environnement (used by Log)
        putenv("ZENATON_APP_DIR=".$this->appDir);
    }

    /*
     * boot autoload file
     */
    public function boot() {
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            $boot = $this->getLaravelBootFilePath();
        }  else {
            $boot = $this->getBootFilePath();
        }

        // load autoload file
        require($boot);

        // check if public Zenaton libray is now known
        if (! class_exists(Zenaton::class)) {
            $this->post(["error" => "Unable to load Zenaton library - please add it to your composer.json, and run composer install"]);
        }

        // boot frameworks
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            $this->bootLaravelFramework();
        }
    }

    /*
     * Get provided classes parameter
     */
    public function checkClasses()
    {
        $checker = new ClassChecker();

        $classes = $this->getClasses();
        $handleOnly = isset($classes->handle_only) && $classes->handle_only ? ($checker->check($classes->handle_only)) :  null;
        $handleExcept = isset($classes->handle_except) && $classes->handle_except ? ($checker->check($classes->handle_except)) :  null;

        $this->success([
            "handle_only" => $handleOnly,
            "handle_except" => $handleExcept
        ]);
    }

    /*
     * path of boot file
     */
    public function getBootFilePath($mandatory = true) {
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            return $this->getLaravelBootFilePath();
        }

        $boot = $this->arg(self::PARAM_BOOT_FILE, $mandatory);

        if (! is_file($boot)) {
            $this->post(["error" => "'" . $boot . "' is not a file"]);
        }

        return $boot;
    }

    /*
     * Get provided uuid parameter
     */
    public function getUuid($mandatory = true) {
        return $this->arg(self::PARAM_UUID, $mandatory);
    }

    /*
     * Get provided type parameter
     */
    public function getType($mandatory = true) {
        return $this->arg(self::PARAM_TYPE, $mandatory);
    }

    /*
     * Get provided worker_version parameter
     */
     public function getWorkerVersion($mandatory = true) {
         return $this->arg(self::PARAM_WORKER_VERSION);
     }

    /*
     * Get provided url parameter
     */
    protected function getUrl($mandatory = true) {
        return $this->arg(self::PARAM_URL, $mandatory);
     }

    /*
     * Get provided envId
     */
    protected function getClasses($mandatory = true) {
        $json = $this->arg(self::PARAM_CLASSES, $mandatory);

        $classes = @json_decode($json);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->post(["error" => "Provided classes parameter '" . $json . "' is invalid json"]);
        }

        return $classes;
    }

    /*
     * Get framework name, if any
     */
    protected function getFramework($mandatory = true) {
        $framework = $this->arg(self::PARAM_FRAMEWORK, $mandatory);

        // optional parameter
        if ($framework && self::FRAMEWORK_LARAVEL !== $framework) {
            $this->post(["error" => "'" . $framework . "' is not a supported framework"]);
        }

        return $framework;
    }

    /*
     * Get path of user application directory
     */
    protected function getAppDir($mandatory = true) {
        $dir = rtrim($this->arg(self::PARAM_APP_DIR, $mandatory), '/');

        $this->checkDir($dir);

        return $dir;
    }

    /*
     * Get provided parameter
     */
    protected function arg($type, $mandatory = true)
    {
        if (isset($this->args[$type])) {
            return $this->args[$type];
        }

        if ($mandatory) {
            $this->post(["error" => "Missing '" . $type . "' parameter"]);
        }
    }

    /*
     * Send success to miscroserver
     */
    public function success($data = []) {
        $this->post(["status" => "ok", "data" => $data], false);
    }

    /*
     * Post response to micro-server
     * (ALWAYS LAST ACTION)
     */
    protected function post($body, $ending = true) {
        try {
            $this->http->post($this->url, $body);
            if ($ending) {
                throw new LoaderException();
            }
        } catch (\Exception $e) {
            $msg = " (" . $this->url . ") - post request failed for " . json_encode($body);
            throw new LoaderException($msg, 0, $e);
        }
    }

    /*
     * Get autoload for Laravel Framework
     */
    protected function getLaravelBootFilePath() {
        $boot = $this->appDir . "/bootstrap/autoload.php";
        if (! file_exists($boot)) {
            $boot = $this->appDir . "/vendor/autoload.php";
        }
        if (! file_exists($boot)) {
            $this->post(["error" => "Unable to find the autoload file of your Laravel app (" . $this->appDir . "/bootstrap/autoload.php)"]);
        }

        return $boot;
    }

    /*
     * Boot Laravel Framework
     */
    protected function bootLaravelFramework() {
        // laravel 5.*
        $bootstrap = $this->appDir . '/bootstrap/app.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
            $kernel->bootstrap();
            return true;
        }

        // laravel 4.*
        $bootstrap = $this->appDir . '/bootstrap/start.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $app->boot();
            return true;
        }

        $this->post(["error" => "Unable to find the boostrap file of your Laravel app (" . $this->appDir ."/bootstrap/app.php)"]);
    }

    /*
     * Check accessible file
     */
    protected function checkFile($file) {
        if (! is_file($file)) {
            $this->post(["error" => "'" . $file . "' is not a file"]);
        }
        if (! is_readable($file)) {
            $this->post(["error" => "Can not read '" . $file . "' file"]);
        }
	}

    /*
     * Check accessible directory
     */
    protected function checkDir($dir) {
        if (! is_dir($dir)) {
            $this->post(["error" => "'" . $dir . "' is not a directory"]);
        }
        if (! is_readable($dir)) {
            $this->post(["error" => "Can not read '" . $dir . "' directory"]);
        }
	}

    /*
     * Check url validity
     */
    protected function checkUrl($url) {
        return true === filter_var($url, FILTER_VALIDATE_URL);
    }
}
