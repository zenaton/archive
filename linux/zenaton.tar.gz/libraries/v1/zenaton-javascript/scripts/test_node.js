/* global process */

// We do not use microserver to test node execution
// to avoid having to deal with fetching environment
// to get microserver port
process.stdout.write("zenaton");
