const request = require('sync-request')
const Log = require('./Log')

module.exports = class SyncHttp {

	get(url) {
		const response = this.parseBody(request('GET', url))
		Log.info('MICROSERVER: (get) ' + url, {response: response}, Log.MICROSERVER)

		return response
	}

	post(url, body) {
		const response = this.parseBody(request('POST', url, { json: body }))
		Log.info('MICROSERVER: (post) ' + url, {body: body, response: response}, Log.MICROSERVER)

		return response
	}

	put(url, body) {
		const response = this.parseBody(request('PUT', url, { json: body }))
		Log.info('MICROSERVER: (put) ' + url, {body: body, response: response}, Log.MICROSERVER)

		return response
	}

	parseBody(response) {
		// getBody function ensures an exception is thrown if any http error
		return JSON.parse(response.getBody('utf8'))
	}
}
