/* global process */

const LoaderException = require('../Exceptions/LoaderException')
const SyncHttp = require('./SyncHttp')
const ClassChecker = require('./ClassChecker')
const fs = require('fs')

const PARAM_URL = 'url'
const PARAM_BOOT_FILE = 'boot'
const PARAM_APP_DIR = 'app'
const PARAM_FRAMEWORK = 'framework'
const PARAM_CLASSES = 'classes'
const PARAM_UUID = 'uuid'
const PARAM_TYPE = 'type'
const PARAM_WORKER_VERSION = 'version'

module.exports = class {

	constructor(args, file = '') {
		// parse args into this.args
		this.args = {}
		let tmp, key, value
		args.forEach( param => {
			tmp = param.split('=')
			key = tmp[0]
			value = (tmp.length < 2) ? '' : tmp[1]
			this.args[key] = value
		})
		// store calling file
		this.file = file
		// provided url
		this.url = this.getUrl()
		// init http service
		this.http = new SyncHttp()
		// get framework, if any
		this.framework = this.getFramework(false)
		// app directory
		this.appDir = this.getAppDir()
		// make sure the execution path of node is the app directory
		process.chdir(this.appDir)
		// store this in environnement (used by Log)
		process.env.ZENATON_APP_DIR = this.appDir
	}

	/*
     * boot autoload file
     */
	boot() {
		let boot = this.getBootFilePath()

		// load autoload file
		require(boot)

		// check if public Zenaton libray is now known
		if (undefined === process.env.ZENATON_LIBRARY_PATH) {
			this.post({error: 'Unable to load Zenaton library - please add it to your package.json, and run npm install'})
		}
	}

	/*
     * Get provided classes parameter
     */
	checkClasses() {
		let checker = new ClassChecker()

		let classes = this.getClasses()
		let handleOnly = classes.handle_only  ? checker.check(classes.handle_only) :  null
		let handleExcept = classes.handle_except ? checker.check(classes.handle_except) :  null

		this.success({
			handle_only: handleOnly,
			handle_except: handleExcept
		})
	}

	/*
     * path of boot file
     */
	getBootFilePath(mandatory = true) {
		let boot = this.arg(PARAM_BOOT_FILE, mandatory)

		this.checkFile(boot)

		return boot
	}

	/*
     * Get provided uuid parameter
     */
	getUuid(mandatory = true) {
		return this.arg(PARAM_UUID, mandatory)
	}

	/*
     * Get provided type parameter
     */
	getType(mandatory = true) {
		return this.arg(PARAM_TYPE, mandatory)
	}

	/*
     * Get provided worker_version parameter
     */
	getWorkerVersion(mandatory = true) {
		return this.arg(PARAM_WORKER_VERSION, mandatory)
	}

	/*
     * Get provided url parameter
     */
	getUrl(mandatory = true) {
		let url = this.arg(PARAM_URL, mandatory)

		if (! this.checkUrl(url)) {
			throw new LoaderException(this.file + ': \'' + url + '\' is an invalid url')
		}

		return url
	}

	/*
     * Get provided envId
     */
	getClasses(mandatory = true) {
		let json = this.arg(PARAM_CLASSES, mandatory)

		try {
			return JSON.parse(json)
		} catch (e) {
			this.post({error: 'Provided \'' + PARAM_CLASSES + '\' parameter \'' + json + '\' is invalid json'})
		}
	}

	/*
     * Get framework name, if any
     */
	getFramework(mandatory = true) {
		let framework = this.arg(PARAM_FRAMEWORK, mandatory)

		// optional parameter
		if (undefined !== framework) {
			this.post({error: framework + ' is not a supported framework'})
		}

		return framework
	}

	/*
     * Get path of user application directory
     */
	getAppDir(mandatory = true) {
		let dir = this.arg(PARAM_APP_DIR, mandatory).replace(/\/$/, '')

		this.checkDir(dir)

		return dir
	}

	/*
     * Get provided parameter
     */
	arg(type, mandatory = true)
	{
		let arg = this.args[type]

		if (undefined === arg && mandatory) {
			this.post({error: 'Missing \'' + type + '\' parameter'})
		}

		return arg
	}

	/*
     * Send success to microserver
     */
	success(data = []) {
		this.post({status: 'ok', data: data}, false)
	}

	/*
     * Post response to micro-server
     * (ALWAYS LAST ACTION)
     */
	post(body, ending = true) {
		let error = new LoaderException()
		try {
			this.http.post(this.url, body)
			if (ending) {
				throw error
			}
		} catch (e) {
			error.message = e.message
			error.stack = e.stack
			throw error
		}
	}

	/*
     * Check accessible file
     */
	checkFile(file) {
		try {
			fs.statSync(file).isFile()
		} catch (e) {
			this.post({error: '\'' + file + '\' is not a file'})
		}
		try {
			fs.accessSync(file, fs.constants.R_OK)
		} catch (e) {
			this.post({error: 'Can not read \'' + file + '\' file'})
		}
	}

	/*
     * Check accessible directory
     */
	checkDir(dir) {
		try {
			fs.statSync(dir).isDirectory()
		} catch (e) {
			this.post({error: '\'' + dir + '\' is not a directory'})
		}
		try {
			fs.accessSync(dir, fs.constants.R_OK)
		} catch (e) {
			this.post({error: 'Can not read \'' + dir + '\' directory'})
		}
	}

	/*
     * Check url validity
     */
	checkUrl(url) {
		// https://github.com/nescalante/urlregex
		let ip = '(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}'
		let protocol = '(?:http(s?)\:\/\/)?'
		let auth = '(?:\\S+(?::\\S*)?@)?'
		let host = '(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)'
		let domain = '(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*'
		let tld = '(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?'
		let port = '(?::\\d{2,5})?'
		let path = '(?:[/?#][^\\s"]*)?'
		let regex = '(?:' + protocol + '|www\\.)' + auth + '(?:localhost|' + ip + '|' + host + domain + tld + ')' + port + path

		return new RegExp('(?:^' + regex + '$)', 'i').test(url)
	}
}
