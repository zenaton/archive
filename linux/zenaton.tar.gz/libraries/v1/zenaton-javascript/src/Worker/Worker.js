const Log  = require('../Services/Log')
const {ZenatonException} = require('../Services/Zenaton').Exceptions
const Microserver = require('./Microserver')
const { taskManager } = require('../Services/Zenaton')

module.exports = class Worker {
	constructor(name, input, hash) {
		this.microserver = new Microserver().setHash(hash)
		this.task = taskManager.getTask(name, input)
		Log.info('TASK - Input - ' + name, input, Log.TASK)
	}

	process() {
		try {
			this.task.handle(this.done.bind(this))
		} catch (e) {
			if (e instanceof ZenatonException) {
				this.microserver.failWorker(e)
				this.microserver.reset()
				throw e
			}
			this.microserver.failWork(e)
			this.microserver.reset()
			throw e
		}
	}

	done(error = null, output = null) {
		if (error) {
			this.microserver.failWork(error)
			this.microserver.reset()
			return
		}
		this.microserver.completeWork(output)
		this.microserver.reset()
	}
}
