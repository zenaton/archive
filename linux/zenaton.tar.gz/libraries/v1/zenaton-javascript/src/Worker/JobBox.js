const { serializer, Wait, AbstractTask, AbstractWorkflow } = require('../Services/Zenaton')
const { InternalZenatonException } = require('../Services/Zenaton').Exceptions
const Log = require('../Services/Log')

const ATTRIBUTE_NAME = 'name'
const ATTRIBUTE_INPUT = 'input'
const ATTRIBUTE_POSITION = 'position'
const ATTRIBUTE_EVENT = 'event'
const ATTRIBUTE_TIMESTAMP = 'timestamp'
const ATTRIBUTE_DURATION = 'duration'
const ATTRIBUTE_TYPE = 'type'
const ATTRIBUTE_SYNC = 'sync'
const ATTRIBUTE_MAX_PROCESSING_TIME = 'maxProcessingTime'

const TYPE_TASK = 'task'
const TYPE_WORKFLOW = 'workflow'
const TYPE_WAIT = 'wait'

module.exports = class JobBox {
	constructor(job) {
		this.job = job
	}

	setSync(sync) {
		this.sync = sync

		return this
	}

	setPosition(position) {
		this.position = position

		return this
	}

	getJob() {
		const data = {}
		const name = this.job.name

		data[ATTRIBUTE_POSITION] = this.position
		data[ATTRIBUTE_SYNC] = this.sync
		data[ATTRIBUTE_NAME] = name
		data[ATTRIBUTE_INPUT] = serializer.encode(this.job.data)
		data[ATTRIBUTE_TYPE] = this.getType()

		if (this.isTask()) {
			data[ATTRIBUTE_MAX_PROCESSING_TIME] =
				('function' === typeof this.job.getMaxProcessingTime) ?
					this.job.getMaxProcessingTime() * 1000 : null
		}

		if (this.isWait()) {
			const event = this.job.event
			const [timestamp, duration] = this.job._getTimestampOrDuration()
			data[ATTRIBUTE_EVENT] = event
			data[ATTRIBUTE_TIMESTAMP] = timestamp
			data[ATTRIBUTE_DURATION] = duration
			Log.info('WAIT' , {name: name, event: event, duration: duration, timestamp: timestamp}, Log.WAIT)
		}

		return data
	}

	getType() {
		if (this.isWait()) {
			return TYPE_WAIT
		}
		if (this.isTask()) {
			return TYPE_TASK
		}
		// if (this.isWorkflow()) {
		// 	return TYPE_WORKFLOW
		// }
		throw new InternalZenatonException('Unknown type')
	}

	isWait() {
		return (this.job instanceof Wait)
	}

	isTask() {
		return (this.job instanceof AbstractTask)
	}

	isWorkflow() {
		return (this.job instanceof AbstractWorkflow)
	}
}
