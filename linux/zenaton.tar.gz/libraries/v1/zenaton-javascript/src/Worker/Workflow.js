let {serializer, WorkflowManager, TaskManager} = require('../Services/Zenaton')
let Position = require('./Position')

let instance

module.exports = class Workflow {
	constructor() {
		if (instance) { return instance }
		instance = this

		this.position = new Position()
		this.workflows = new WorkflowManager()
		this.tasks = new TaskManager()
	}

	setWorkflowName(name) {
		this.name = name

		return this
	}

	init(branch, properties) {
		// build workflow object

		// if provided class is a Version, it means it has been replaced since launched
		//TODO

		// build from name and properties
		this.flow = this.workflows.getWorkflow(this.name, serializer.decode(properties))

		// build the branch
		this.branch = branch

		// init position
		this.position.init()

		return this
	}

	runBranch() {
		if (this.branch.type === 'handle') {
			return this.flow.handle()
		}

		if (this.branch.type === 'onEvent') {
			if ('undefined' !== typeof this.flow.onEvent) {
				this.flow.onEvent(this.branch.data.event_name, serializer.decode(this.branch.data.event_input))
				return
			}
		}

		if (this.branch.type === 'onStart') {

			if ('undefined' !== typeof this.flow.onStart) {
				let task = this.tasks.getTask(this.branch.data.task_name, serializer.decode(this.branch.data.task_input))
				this.flow.onStart(task)
				return
			}
		}

		if (this.branch.type === 'onSuccess') {
			if ('undefined' !== typeof this.flow.onSuccess) {
				let task = this.tasks.getTask(this.branch.data.task_name, serializer.decode(this.branch.data.task_input))
				this.flow.onSuccess(task, serializer.decode(this.branch.data.task_output))
				return
			}
		}

		if (this.branch.type === 'onFailure') {
			if ('undefined' !== typeof this.flow.onFailure) {
				let task = this.tasks.getTask(this.branch.data.task_name, serializer.decode(this.branch.data.task_input))
				let error = new Error() // this.branch.data.error_name this.branch.data.error_input
				this.flow.onFailure(task, error)
				return
			}
		}

		if (this.branch.type === 'onTimeout') {
			if ('undefined' !== typeof this.flow.onTimeout) {
				let task = this.tasks.getTask(this.branch.data.task_name, serializer.decode(this.branch.data.task_input))
				this.flow.onTimeout(task)
				return
			}
		}
	}

	getProperties() {
		return this.flow.data
	}

	setProperties(data) {
		this.assign(this.flow.data, data)

		return this
	}

	getPosition() {
		return this.position.get()
	}

	next() {
		this.position.next()
	}

	nextParallel() {
		this.position.nextParallel()
	}

	nextAsync() {
		this.position.nextAsync()
	}

	assign(target, source) {
		// empty target object
		for (var prop in target) {
			if (target.hasOwnProperty(prop)) {
				delete target[prop]
			}
		}
		// fill with new values
		Object.assign(target, source)
	}
}
