const Log = require('../Services/Log')
const SyncHttp = require('../Services/SyncHttp')
const { serializer, Client } = require('../Services/Zenaton')
const Workflow = require('./Workflow')

let instance = null

module.exports = class Microserver {
	constructor() {
		// Singleton
		if (instance) { return instance }
		instance = this

		this.flow = new Workflow()
		this.http = new SyncHttp()
	}

	getUuid() {
		return this.uuid
	}

	setUuid(uuid) {
		this.uuid = uuid
		return this
	}

	setWorkerVersion(workerVersion) {
		this.workerVersion = workerVersion
		return this
	}

	setHash(hash) {
		this.hash = hash
		return this
	}

	reset() {
		this.uuid = null
		this.hash = null
		this.workerVersion = null
		return this
	}

	isDeciding() {
		return (!this.hash && this.uuid)
	}

	isWorking() {
		return (this.hash && this.uuid)
	}

	askJob(type) {
		let url = this.getWorkerUrl('uuid/' + this.uuid + '/type/' + type + '/job', 'worker_version='+ this.workerVersion)

		const response = this.http.get(url)

		Log.info('INFRA - Ask Job - (get) ' + url, {response: response}, Log.INFRA)

		return response
	}

	getBranchToExecute() {
		let url = this.decisionUrl('branch')

		const response = this.http.get(url)

		Log.info('DECISION - Branch - (get) '+ url, {response: response}, Log.DECISION)

		return response
	}

	execute(boxes) {

		const jobs = []
		boxes.forEach(box => {
			jobs.push(box.getJob())
		})

		let url = this.decisionUrl('execute')
		const body = {works: jobs}
		let response = this.http.post(url, body)

		if (response.status === 'completed') {
			// decode properties
			response.properties = serializer.decode(response.properties)

			// decode outputs (output can be null, eg. wait task)
			const outputs = response.outputs.map(output => {
				if (output) {
					// if the output is the an event from a Wait(event) - Build this event
					if (undefined !== output.event_name && undefined !== output.event_input) {
						return {event_name: output.event_name, event_input: serializer.decode(output.event_input)}
					}

					return serializer.decode(output)
				}
			})

			response.outputs = outputs
		}

		Log.info('DECISION - Execute - (post) -' + url, {body: body, response: response}, Log.DECISION)

		return response
	}

	completeDecision() {
		const url = this.decisionUrl('branch')
		const body = {
			properties: serializer.encode(this.flow.getProperties())
		}
		const response = this.http.post(url, body)

		Log.info('DECISION - Complete - ' + url, {body: body, response: response}, Log.DECISION)

		return response
	}

	completeDecisionBranch(output) {
		const url = this.decisionUrl('branch')
		let body = {
			properties: serializer.encode(this.flow.getProperties())
		}
		if (output) {
			body.output = serializer.encode(output)
		}
		const response = this.http.post(url, body)

		Log.info('DECISION - Complete Branch - ' + url, {body: body, response: response}, Log.DECISION)

		return response
	}

	failDecider(e) {
		const url = this.decisionUrl()
		const body = {
			status: 'zenatonFailed',
			error_code: 0,
			error_message: e.message,
			error_name: e.name,
			error_stacktrace: e.stack,
			failed_at: Math.round(new Date().getTime() / 1000)
		}
		const response =  this.http.put(url, body)

		Log.info('DECISION - Decider Failure - ' + url, {body: body, response: response}, Log.DECISION)

		return response
	}

	failDecision(e) {
		let url = this.decisionUrl()
		const body = {
			status: 'failed',
			error_code: 0,
			error_message: e.message,
			error_name: e.name,
			error_stacktrace: e.stack,
			failed_at: Math.round(new Date().getTime() / 1000)
		}
		const response = this.http.put(url, body)

		Log.info('DECISION - Decision Failure - ' + url, {body: body, response: response}, Log.DECISION)

		return response
	}

	completeWork(output)
	{
		this.sendWork({
			status: 'completed',
			output: (output) ? serializer.encode(output) : null,
		})
	}

	failWorker(e) {
		this.sendWork({
			status: 'zenatonFailed',
			error_name: e.name,
			error_input: serializer.encode(e),
			error_code: 0,
			error_message: e.message,
			error_stacktrace: e.stack,
			failed_at: Math.round(new Date().getTime() / 1000)
		})
	}

	failWork(e) {
		this.sendWork({
			status: 'failed',
			error_name: e.name,
			error_input: serializer.encode(e),
			error_code: 0,
			error_message: e.message,
			error_stacktrace: e.stack ,
			failed_at: Math.round(new Date().getTime() / 1000)
		})
	}

	sendWork(body) {
		const url = this.getWorkerUrl('tasks/' + this.uuid, 'worker_version=' + this.workerVersion)
		body.hash = this.hash

		const response = this.http.post(url, body)

		Log.info('Task - Send - (post) ' + url, {body: body, response: response}, Log.TASK)

		return response
	}

	decisionUrl(endpoint = '') {
		return this.getWorkerUrl('decisions/' + this.uuid + '/' + endpoint, 'worker_version=' + this.workerVersion)
	}

	getWorkerUrl(ressource, params = '') {
		// taking url from client ensures we use same Worker API version than user library
		return new Client(true).getWorkerUrl(ressource, params)
	}
}
