const Microserver = require('./Microserver')
const Decider = require('./Decider')
const Worker = require('./Worker')
const Processer = require('../Processer')
const { Engine } = require('../Services/Zenaton')
const { InternalZenatonException } = require('../Services/Zenaton').Exceptions

const DECISION_SCHEDULED = 'DecisionScheduled'
const TASK_SCHEDULED = 'TaskScheduled'

module.exports = class Slave {
	constructor(uuid, type, workerVersion) {
		this.microserver = new Microserver().setUuid(uuid).setWorkerVersion(workerVersion)
		this.type = type
		// inject Processer in Zenaton library
		new Engine().setProcesser(new Processer())
	}

	process() {
		let response = this.microserver.askJob(this.type)

		switch (response.action) {
		case DECISION_SCHEDULED:
			new Decider(response.name).launch()
			break
		case TASK_SCHEDULED:
			new Worker(response.name, response.input, response.hash).process()
			break
		default:
			throw new InternalZenatonException('Error - unknown action in response: ' + response.action)
		}
	}
}
