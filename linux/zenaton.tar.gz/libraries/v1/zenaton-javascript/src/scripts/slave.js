/* global process, __filename */

const Loader = require('../Services/Loader')

let args = process.argv
// remove first 2 elements
args.splice(0,2)
let loader = new Loader(args, __filename)

// load boot file
loader.boot()

// create Slave getInstance
const type = loader.getType()
const uuid = loader.getUuid()
const workerVersion = loader.getWorkerVersion()
const Slave = require('../Worker/Slave')
let slave = new Slave(uuid, type, workerVersion)

// we have all what we need
loader.success()

// Use uncaughtException to catch all errors
process.on('uncaughtException', function (e) {
	const Microserver = require('../Worker/Microserver')
	let ms = new Microserver()
	if (ms.isWorking()) {
		ms.failWorker(e)
	}
	if (ms.isDeciding()) {
		ms.failDecider(e)
	}
	// let die
	throw e
})

// we arrive here only if everything went well, including the success() call to url
slave.process()
