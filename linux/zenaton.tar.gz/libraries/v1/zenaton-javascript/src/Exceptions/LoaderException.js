const ExtendableError = require('./ExtendableError')

module.exports = class extends ExtendableError {}
