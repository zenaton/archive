<?php

namespace Zenaton\Worker;

use Zenaton\Client;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Traits\SingletonTrait;
use Zenaton\Exceptions\ScheduledBoxException;
use Zenaton\Exceptions\ModifiedDeciderException;

class Processor
{
    use SingletonTrait;

    protected $microserver;
    protected $flow;

    const STATUS_MODIFIED = 'modified';
    const STATUS_SCHEDULED = 'scheduled';
    const STATUS_COMPLETED = 'completed';

    public function construct()
    {
        $this->microserver = MicroServer::getInstance();
        $this->flow = Workflow::getInstance();
    }

    public function process($boxes, $isSync)
    {
        if ($this->microserver->isWorking()) {
            return $this->processFromTask($boxes, $isSync);
        }
        if ($this->microserver->isDeciding()) {
            return $this->processFromWorkflow($boxes, $isSync);
        }
        throw new InternalZenatonException('process: Unknown state');
    }

    protected function processFromTask($boxes, $isSync)
    {
        $client = Client::getInstance();

        $outputs = [];
        // handle sync executions and dispatch async
        foreach ($boxes as $box) {
            if ($box instanceof WorkflowInterface) {
                if ($isSync) {
                    $outputs[] = $box->handle();
                } else {
                    $client->startWorkflow($box);
                    $outputs[] = null;
                }
            } elseif ($box instanceof TaskInterface) {
                if ($isSync) {
                    $outputs[] = $box->handle();
                } else {
                    // $client->startTask($box);
                    // $outputs[] = null;
                    $box->handle();
                    $outputs[] = null;
                }
            } else {
                throw new InternalZenatonException('processFromTask: Unknown type');
            }
        }
        // return results
        return $outputs;
    }

    protected function processFromWorkflow($boxes, $isSync)
    {
        // construct array of decorated boxes
        $dboxes = [];
        foreach ($boxes as $box) {
            // Go to the next position
            if (!$isSync) {
                $this->flow->nextAsync();
            } elseif (count($boxes) > 1) {
                $this->flow->nextParallel();
            } else {
                $this->flow->next();
            }

            $dboxes[] = (new JobBox($box))->setSync($isSync)->setPosition($this->flow->getPosition());
        }

        // schedule task or get result if already done
        $response = $this->microserver->execute($dboxes);

        // Decider was modified
        if (self::STATUS_MODIFIED === $response->status) {
            throw new ModifiedDeciderException(
                '"'.$this->flow->getName().'" has been modified since launch of current instance.'.PHP_EOL.
                'You can\'t. Seriously.'.PHP_EOL.
                'See https://zenaton.com/documentation#workflow-versioning-for-running-instances'
            );
        }

        // Nothing more to do for asynchronous execution
        if (!$isSync) {
            return;
        }

        if (self::STATUS_SCHEDULED === $response->status) {
            throw new ScheduledBoxException();
        }

        if (self::STATUS_COMPLETED === $response->status) {
            // Set properties for last execution
            $this->flow->setProperties($response->properties);

            // return output
            return $response->outputs;
        }

        throw new InternalZenatonException('processFromWorkflow: InputBox with Unkwnon status at position '.$this->flow->getPosition());
    }
}
