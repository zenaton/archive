<?php

namespace Zenaton\Worker;

use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WaitInterface;
use Zenaton\Interfaces\JobInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Services\Serializer;
use Zenaton\Services\Properties;

use Zenaton\Services\Log;

class JobBox
{
    const ATTRIBUTE_NAME = 'name';
    const ATTRIBUTE_INPUT = 'input';
    const ATTRIBUTE_POSITION = 'position';
    const ATTRIBUTE_EVENT = 'event';
    const ATTRIBUTE_TIMESTAMP = 'timestamp';
    const ATTRIBUTE_DURATION = 'duration';
    const ATTRIBUTE_TYPE = 'type';
    const ATTRIBUTE_SYNC = 'sync';
    const ATTRIBUTE_MAX_PROCESSING_TIME = 'maxProcessingTime';

    const TYPE_TASK = 'task';
    const TYPE_WORKFLOW = 'workflow';
    const TYPE_WAIT = 'wait';

    protected $serializer;
    protected $properties;
    protected $job;
    protected $position;
    protected $sync;

    public function __construct(JobInterface $job)
    {
        $this->serializer = new Serializer();
        $this->properties = new Properties();
        $this->log = new Log();
        $this->job = $job;
    }

    public function setSync($sync)
    {
        $this->sync = $sync;

        return $this;
    }

    public function setPosition($position)
    {
        $this->position = $position;

        return $this;
    }

    public function getJob()
    {
        $name = get_class($this->job);

        $data = [
            self::ATTRIBUTE_POSITION => $this->position,
            self::ATTRIBUTE_SYNC => $this->sync,
            self::ATTRIBUTE_NAME => $name,
            self::ATTRIBUTE_INPUT => $this->serializer->encode($this->properties->getPropertiesFromObject($this->job)),
            self::ATTRIBUTE_TYPE => $this->getType()
        ];

        if ($this->isTask()) {
            $data[self::ATTRIBUTE_MAX_PROCESSING_TIME] =
                (method_exists($this->job, 'getMaxProcessingTime')) ?
                    $this->job->getMaxProcessingTime() * 1000 : null;
        }

        if ($this->isWait()) {
            $event = $this->job->getEvent();
            [$timestamp, $duration] = $this->job->_getTimestampOrDuration();
            $data[self::ATTRIBUTE_EVENT] = $event;
            $data[self::ATTRIBUTE_TIMESTAMP] = $timestamp;
            $data[self::ATTRIBUTE_DURATION] = $duration;
            $this->log->info('WAIT', ['name'=>$name, 'event'=>$event, 'duration'=>$duration, 'timestamp'=>$timestamp], Log::TYPE_WAIT);
        }

        return $data;
    }

    protected function getType()
    {
        if ($this->isWait()) {
            return self::TYPE_WAIT;
        }
        if ($this->isTask()) {
            return self::TYPE_TASK;
        }
        // if ($this->isWorkflow()) {
        //     return self::TYPE_WORKFLOW;
        // }
        throw new InternalZenatonException('Unknown type');
    }

    public function isWait()
    {
        return $this->job instanceof WaitInterface;
    }

    public function isTask()
    {
        return $this->job instanceof TaskInterface;
    }

    public function isWorkflow()
    {
        return $this->job instanceof WorkflowInterface;
    }
}
