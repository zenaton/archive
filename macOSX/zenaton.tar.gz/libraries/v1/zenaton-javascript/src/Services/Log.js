/* global process, console */
const util = require('util')

const TYPE_NONE = ''
const TYPE_ALL = '*'
const TYPE_DECISION = 'decision'
const TYPE_TASK = 'task'
const TYPE_WAIT = 'wait'
const TYPE_MICROSERVER = 'microserver'
const TYPE_INFRA = 'infra'

const LEVEL_NONE = 0
const LEVEL_INFO = 1
const LEVEL_WARNING = 2
const LEVEL_ERROR = 3

const logLevel = (undefined === process.env.ZENATON_LOG_LEVEL) ? LEVEL_NONE : parseInt(process.env.ZENATON_LOG_LEVEL)
const logType = (undefined === process.env.ZENATON_LOG_TYPE) ? TYPE_NONE : process.env.ZENATON_LOG_TYPE


module.exports = class {

	static always(title, msg = '', type = TYPE_NONE) {
		return this.log(title, msg, LEVEL_NONE, type)
	}

	static info(title, msg = '', type = TYPE_NONE) {
		return this.log(title, msg, LEVEL_INFO, type)
	}

	static warning(title, msg = '', type = TYPE_NONE) {
		return this.log(title, msg, LEVEL_WARNING, type)
	}

	static error(title, msg = '', type = TYPE_NONE) {
		return this.log(title, msg, LEVEL_ERROR, type)
	}

	static get DECISION() {
		return TYPE_DECISION
	}

	static get TASK() {
		return TYPE_TASK
	}

	static get WAIT() {
		return TYPE_WAIT
	}

	static get MICROSERVER() {
		return TYPE_MICROSERVER
	}

	static get INFRA() {
		return TYPE_INFRA
	}

	static log(title, msg, level, type) {
		if (logLevel >= level && (TYPE_ALL === logType || logType === type)) {
			console.log('==== ' + title + ' ====')
			console.log(util.inspect(msg, false, null))
			console.log('===============')
		}
	}
}
