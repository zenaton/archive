/* global process, console */

const LoaderException = require('../Exceptions/LoaderException')

const PARAM_URL = 'url'
const PARAM_BOOT_FILE = 'boot'
const PARAM_APP_DIR = 'app'
const PARAM_FRAMEWORK = 'framework'
const PARAM_CLASSES = 'classes'
const PARAM_UUID = 'uuid'
const PARAM_TYPE = 'type'
const PARAM_WORKER_VERSION = 'version'
const FRAMEWORK_LARAVEL = 'laravel'


module.exports = class {

	constructor(args, file = '') {
		this.args = {}
		let tmp, key, value
		args.forEach( (param) => {
			tmp = param.split('=')
			key = tmp[0]
			value = (tmp.length < 2) ? '' : tmp[1]
			this.args[key] = value
		})

		throw this.args
	}
}
