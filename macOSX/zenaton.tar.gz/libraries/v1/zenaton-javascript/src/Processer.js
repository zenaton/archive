const Workflow = require('./Worker/Workflow')
const Microserver = require('./Worker/Microserver')
const JobBox = require('./Worker/JobBox')
const {ScheduledBoxException, InternalZenatonException, ModifiedDeciderException} = require('./Services/Zenaton').Exceptions

const STATUS_MODIFIED = 'modified'
const STATUS_SCHEDULED = 'scheduled'
const STATUS_COMPLETED = 'completed'

module.exports = class {
	constructor() {
		this.microserver = new Microserver()
		this.flow = new Workflow()
	}

	process(boxes, isSync)
	{
		// construct array of decorated boxes
		let dboxes = []
		boxes.forEach(box => {
			// Go to the next position
			if (! isSync) {
				this.flow.nextAsync()
			} else if (boxes.length > 1) {
				this.flow.nextParallel()
			} else {
				this.flow.next()
			}
			//
			dboxes.push((new JobBox(box)).setSync(isSync).setPosition(this.flow.getPosition()))
		})

		// schedule task or get result if already done
		let response = this.microserver.execute(dboxes)

		// Decider was modified
		if (response.status === STATUS_MODIFIED) {
			throw new ModifiedDeciderException()
		}

		// Nothing more to do for asynchronous execution
		if (! isSync) {
			return
		}

		if (response.status === STATUS_SCHEDULED) {
			throw new ScheduledBoxException()
		}

		if (response.status === STATUS_COMPLETED) {
			// Set properties for last execution
			this.flow.setProperties(response.properties)

			// return output
			return response.outputs
		}

		throw new InternalZenatonException('InputBox with Unkwnon status at position '.this.flow.getPosition())
	}
}
