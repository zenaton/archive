const Log  = require('../Services/Log')
const {ZenatonException} = require('../Services/Zenaton').Exceptions
const Microserver = require('./Microserver')
const { serializer, TaskManager } = require('../Services/Zenaton')

module.exports = class Worker {
	constructor(uuid, name, input, hash, workerVersion) {
		this.microserver = new Microserver().setUuid(uuid).setHash(hash).setWorkerVersion(workerVersion)
		input = serializer.decode(input)
		this.task = new TaskManager().getTask(name, input)
		Log.info('TASK - Input - ' + name, input, Log.TASK)
	}

	process() {
		try {
			this.task.handle(this.done.bind(this))
		} catch (e) {
			if (e instanceof ZenatonException) {
				this.microserver.failWorker(e)
				this.microserver.reset()
				throw e
			}
			this.microserver.failWork(e)
			this.microserver.reset()
			throw e
		}
	}

	done(error = null, output = null) {
		if (error) {
			this.microserver.failWork(error)
			this.microserver.reset()
			return
		}
		this.microserver.completeWork(output)
		this.microserver.reset()
	}
}
