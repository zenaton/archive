const { workflowManager, taskManager} = require('../Services/Zenaton')

module.exports = class HandleParameters {

	process(classes) {
		let workflows = []
		let tasks = []
		let unknown = []

		classes = classes.trim().split(',')
		classes.forEach( c => {
			if (taskManager.getClass(c)) {
				tasks.push(c)
			} else if (workflowManager.getClass(c)) {
				workflows.push(c)
			} else {
				unknown.push(c)
			}
		})

		return {
			tasks: tasks,
			workflows: workflows,
			undefined: unknown
		}
	}
}
