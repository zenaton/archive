const Microserver = require('./Microserver')
const Decider = require('./Decider')
const Worker = require('./Worker')
const Processer = require('../Processer')
const { Engine } = require('../Services/Zenaton')
const { InternalZenatonException } = require('../Services/Zenaton').Exceptions

const DECISION_SCHEDULED = 'DecisionScheduled'
const TASK_SCHEDULED = 'TaskScheduled'

module.exports = class Slave {
	constructor(envId) {
		this.envId = envId
		this.microserver = new Microserver()
		// inject Executer in Zenaton library
		new Engine().setProcesser(new Processer())
	}

	process() {
		let result = this.microserver.askJob(this.envId)
		switch (result.action) {
		case DECISION_SCHEDULED:
			(new Decider(result.uuid, result.name, result.worker_version)).launch()
			break
		case TASK_SCHEDULED:
			(new Worker(result.uuid, result.name, result.input, result.hash, result.worker_version)).process()
			break
		default:
			throw new InternalZenatonException('Error - unknown action in result: ' + result.action)
		}
	}
}
