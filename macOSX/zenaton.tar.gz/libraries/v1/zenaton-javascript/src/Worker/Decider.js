const Log  = require('../Services/Log')
const { InternalZenatonException, ScheduledBoxException } = require('../Services/Zenaton').Exceptions
const Workflow = require('./Workflow')
const Microserver = require('./Microserver')

module.exports = class Decider {
	constructor(uuid, name, workerVersion) {
		this.microserver = new Microserver().setUuid(uuid).setWorkerVersion(workerVersion)
		this.flow = new Workflow().setWorkflowName(name)
	}

	launch() {
		let response = this.microserver.getBranchToExecute()
		while (('object' === typeof response) && (Object.keys(response).length > 0)) {

			this.flow.init(response.branch, response.properties)
			this.process()

			response = this.microserver.getBranchToExecute()
		}

		this.microserver.reset()
	}

	process() {
		let output
		try {
			output = this.flow.runBranch()
		} catch (e) {

			if (e instanceof ScheduledBoxException) {
				this.microserver.completeDecision()
				return
			}

			if (e instanceof InternalZenatonException) {
				this.microserver.failDecider(e)
				this.microserver.reset()
				throw e
			}

			this.microserver.failDecision(e)
			this.microserver.reset()
			throw e
		}

		this.microserver.completeDecisionBranch(output)
	}
}
