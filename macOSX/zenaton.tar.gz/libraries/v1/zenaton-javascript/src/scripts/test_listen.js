/* global process, __filename */

const Loader = require('../Services/Loader')

let args = process.argv
// remove first 2 elements
args.splice(0,2)

// load class
let loader = new Loader(args, __filename)

// load boot file
loader.boot()

// check parameters
loader.checkClasses()
