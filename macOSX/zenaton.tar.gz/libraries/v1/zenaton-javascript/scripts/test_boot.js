/* global process */

var bootPath = process.argv[2];
var appPath = process.argv[3];

// autoload user's boot file
process.env.ZENATON_BOOT_PATH = bootPath;
process.env.ZENATON_APP_PATH = appPath;
require("./boot");

// MUST be behind boot in order to get process.env.ZENATON_LIBRARY_PATH
var Microserver = require("../lib/Worker/Microserver");

// return feedback to ms
new Microserver().giveBootFeedback();
