/* global process */

var bootPath = process.argv[2];
var envId = process.argv[3];
var appPath = process.argv[4];

// autoload user's boot file
process.env.ZENATON_BOOT_PATH = bootPath;
process.env.ZENATON_APP_PATH = appPath;

require("./boot");

// MUST be behind boot in order to get process.env.ZENATON_LIBRARY_PATH
var Slave = require("../lib/Worker/Slave");

// launch script
(new Slave(envId)).process();
