/* global process */

var bootPath = process.argv[3];
var classes = JSON.parse(process.argv[2]);

// autoload user's boot file
process.env.ZENATON_BOOT_PATH = bootPath;
// process.env.ZENATON_APP_PATH = appPath;
require("./boot");

// MUST be behind boot in order to get process.env.ZENATON_LIBRARY_PATH
var HandleParameters = require("../lib/Worker/HandleParameters");
var Microserver = require("../lib/Worker/Microserver");

// response back
var handleOnly = (classes.handle_only) ? (new HandleParameters()).process(classes.handle_only) : null;
var handleExcept = (classes.handle_except) ? (new HandleParameters()).process(classes.handle_except) : null;

new Microserver().giveHandleParameters(handleOnly, handleExcept);
