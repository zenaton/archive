/* global process, console, __filename */

process.on("uncaughtException", function (e) {
	console.log(e);
	process.exit(1);
});

const LoaderException = require("../src/Exceptions/LoaderException");
const Loader = require("../src/Services/Loader");

try {
	let loader = new Loader(process.argv);

	// load boot file
	loader.boot();

	// check parameters
	loader.checkClasses();

} catch (e) {
	if (e instanceof LoaderException) {
		console.log(e.message);
	} else {
		console.log(e);
	}
}
