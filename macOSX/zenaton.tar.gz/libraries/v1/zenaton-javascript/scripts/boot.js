"use strict";
/* global process */

// make sure the execution path of node is the same than user's
process.chdir(process.env.ZENATON_APP_PATH);

// require boot file
module.exports = require(process.env.ZENATON_BOOT_PATH);
