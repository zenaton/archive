"use strict";

/* global process */

var path = require("path");

// make sure the execution path of node is the same than user's
process.chdir(path.dirname(process.env.ZENATON_BOOT_PATH));

// require boot file
module.exports = require(process.env.ZENATON_BOOT_PATH);
