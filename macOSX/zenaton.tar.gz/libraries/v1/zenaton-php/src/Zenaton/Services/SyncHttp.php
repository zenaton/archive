<?php

namespace Zenaton\Services;

use Garden\Http\HttpClient;

class SyncHttp
{
    public function __construct($base = '')
    {
        $this->http = new HttpClient($base);
        $this->http->setDefaultHeader('Content-Type', 'application/json');
        $this->http->setThrowExceptions(true);
        $this->log = new Log;
    }
    public function get($url)
    {
        $response = $this->http->get($url);

        $response = json_decode($response->getRawBody());
        $this->log->info('MICROSERVER: (get) ' . $url, ['response' => $response], Log::TYPE_MICROSERVER);
        return $response;
    }

    public function post($url, $body)
    {
        $response = $this->http->post($url, $body);
        $response = json_decode($response->getRawBody());
        $this->log->info('MICROSERVER: (post) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_MICROSERVER);
        return $response;
    }

    public function put($url, $body)
    {
        $response = $this->http->put($url, $body);

        $response =json_decode($response->getRawBody());

        $this->log->info('MICROSERVER: (put) ' . $url, ['body' => $body, 'response' => $response], Log::TYPE_MICROSERVER);


        return $response;
    }
}
