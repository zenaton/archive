<?php

namespace Zenaton\Services;

use Zenaton\Traits\IsImplementationOfTrait;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;


class ClassChecker
{
    use IsImplementationOfTrait;

    public function check($classes)
    {
        $tasks = [];
        $workflows = [];
        $undefined = [];
        $classes = array_map('trim', explode(',', $classes));

        foreach ($classes as $class) {
            if ($this->isImplementationOf($class, WorkflowInterface::class)) {
                $workflows[] = $class;
            } elseif ($this->isImplementationOf($class, TaskInterface::class)) {
                $tasks[] = $class;
            } else {
                $undefined[] = $class;
            }
        }

        return [
            'tasks' => $tasks,
            'workflows' => $workflows,
            'undefined' => $undefined
        ];
    }

}
