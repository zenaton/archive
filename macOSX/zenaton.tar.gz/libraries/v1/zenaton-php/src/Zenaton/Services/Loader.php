<?php

namespace Zenaton\Services;

use Zenaton\Exceptions\LoaderException;
use Zenaton\Client as Zenaton;

class Loader
{
    protected $args;
    protected $file;
    protected $url;
    protected $framework;
    protected $appDir;
    protected $http;

    const PARAM_URL = 'url';
    const PARAM_BOOT_FILE = 'boot';
    const PARAM_APP_DIR = 'app';
    const PARAM_FRAMEWORK = 'framework';
    const PARAM_CLASSES = 'classes';
    const PARAM_UUID = 'uuid';
    const PARAM_TYPE = 'type';
    const PARAM_WORKER_VERSION = 'version';
    const FRAMEWORK_LARAVEL = 'laravel';

    public function __construct($args, $file = '')
    {
        // parse $args into $this->args
        parse_str(implode('&', array_slice($args, 1)), $this->args);

        // store calling file
        $this->file = $file;

        // provided url
        $this->url = $this->getUrl();
        // init http service with mandatory url parameter
        $this->http = new SyncHttp();
        // get framework, if any
        $this->framework = $this->getFramework();

        // if a framework, it should have an app directory
        if ($this->framework) {
            $this->appDir = $this->getAppDir();
        }
    }

    // path of boot file
    public function getBootFilePath($name = '') {
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            return $this->getLaravelBootFilePath();
        }

        $boot = $this->arg(self::PARAM_BOOT_FILE);
        if (is_null($boot)) {
            $this->post(["error" => "Missing boot parameter"]);
        }
        if (! is_file($boot)) {
            $this->post(["error" => "'" . $boot . "' is not a file"]);
        }

        return $boot;
    }

    /*
     * boot autoload file
     */
    public function boot() {
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            $boot = $this->getLaravelBootFilePath();
        }  else {
            $boot = $this->getBootFilePath();
        }

        // load autoload file
        require($boot);

        // check if public Zenaton libray is now known
        if (! class_exists(Zenaton::class)) {
            $this->post(["error" => "Unable to load Zenaton library - please add it to your composer.json, and run composer install"]);
        }

        // boot frameworks
        if ($this->framework === self::FRAMEWORK_LARAVEL) {
            $this->bootLaravelFramework();
        }
    }

    /*
     * Get provided classes parameter
     */
    public function checkClasses()
    {
        $checker = new ClassChecker();

        $classes = $this->getClasses();
        $handleOnly = isset($classes->handle_only) && $classes->handle_only ? ($checker->check($classes->handle_only)) :  null;
        $handleExcept = isset($classes->handle_except) && $classes->handle_except ? ($checker->check($classes->handle_except)) :  null;

        $this->success([
            "handle_only" => $handleOnly,
            "handle_except" => $handleExcept
        ]);
    }

    /*
     * Get provided uuid parameter
     */
    public function getUuid() {
        $uuid = $this->arg(self::PARAM_UUID);

        if (! $uuid) {
            $this->post(["error" => "Missing uuid"]);
        }

        return $uuid;
    }

    /*
     * Get provided type parameter
     */
    public function getType() {
        $type = $this->arg(self::PARAM_TYPE);

        if (! $type) {
            $this->post(["error" => "Missing type"]);
        }

        return $type;
    }

    /*
     * Get provided worker_version parameter
     */
     public function getWorkerVersion() {
         $workerVersion = $this->arg(self::PARAM_WORKER_VERSION);

         if (! $workerVersion) {
             $this->post(["error" => "Missing worker_version"]);
         }

         return $workerVersion;
     }

    /*
     * Send success to miscroserver
     */
    public function success($data = []) {
        $this->post(["status" => "ok", "data" => $data]);
    }

    /*
     * Get provided parameter
     */
    protected function arg($type)
    {
        if (isset($this->args[$type])) {
            return $this->args[$type];
        }
    }

    /*
     * Get provided url parameter
     */
    protected function getUrl() {
        $url = $this->arg(self::PARAM_URL);
        if (FALSE === filter_var($url, FILTER_VALIDATE_URL)) {
            throw new LoaderException($this->file . ": '" . $url . "' is an invalid url");
        }

        return $url;
    }

    /*
     * Get provided envId
     */
    protected function getClasses() {
        $json = $this->arg(self::PARAM_CLASSES);

        if (is_null($json)) {
            $this->post(["error" => "Missing classes parameter"]);
        }

        $classes = @json_decode($json);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->post(["error" => "Provided classes parameter '" . $json . "' is invalid json"]);
        }

        return $classes;
    }

    /*
     * Post response to micro-server
     * (ALWAYS LAST ACTION)
     */
    protected function post($body) {

        try {
            $response = $this->http->post($this->url, $body);
            $msg = "";
        } catch (\Exception $e) {
            $msg = $this->file . " (" . $this->url . ") - post request failed for " . json_encode($body) . " : " . $response->getStatus();

        }

        throw new LoaderException($msg);
    }

    /*
     * Get framework name, if any
     */
    protected function getFramework() {
        $framework = $this->arg(self::PARAM_FRAMEWORK);

        // optional parameter
        if ($framework && self::FRAMEWORK_LARAVEL !== $framework) {
            $this->post(["error" => $framework . " is not a supported framework"]);
        }

        return $framework;
    }

    /*
     * Get path of user application directory
     */
    protected function getAppDir() {
        $dir = $this->arg(self::PARAM_APP_DIR);

        if (is_null($dir)) {
            $this->post(["error" => "Missing app directory"]);
        }

        if (! is_dir($dir)) {
            $this->post(["error" => $dir . " is not a directory"]);
        }

        return $dir;
    }

    /*
     * Get autoload for Laravel Framework
     */
    protected function getLaravelBootFilePath() {
        $boot = $this->appDir . "/bootstrap/autoload.php";
        if (! file_exists($boot)) {
            $boot = $this->appDir . "/vendor/autoload.php";
        }
        if (! file_exists($boot)) {
            $this->post(["error" => "Unable to find the autoload file of your Laravel app (" . $this->appDir . "/bootstrap/autoload.php)"]);
        }

        return $boot;
    }

    /*
     * Boot Laravel Framework
     */
    protected function bootLaravelFramework() {
        // laravel 5.*
        $bootstrap = $this->appDir . '/bootstrap/app.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
            $kernel->bootstrap();
            return true;
        }

        // laravel 4.*
        $bootstrap = $this->appDir . '/bootstrap/start.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $app->boot();
            return true;
        }

        $this->post(["error" => "Unable to find the boostrap file of your Laravel app (" . $this->appDir ."/bootstrap/app.php)"]);
    }
}
