<?php

namespace Zenaton\Worker;

use Zenaton\Worker\Decider;
use Zenaton\Worker\Worker;
use Zenaton\Exceptions\InternalZenatonException;

class Slave
{
    protected $envId;
    protected $microserver;

    public function __construct($envId)
    {
        $this->microserver = MicroServer::getInstance();
        $this->envId = $envId;
    }

    public function process()
    {
        $response = $this->microserver->askJob($this->envId);
        switch ($response->action) {
            case 'DecisionScheduled':
                (new Decider($response->uuid, $response->name, $response->worker_version))->launch();
                break;
            case 'TaskScheduled':
                (new Worker($response->uuid, $response->name, $response->input, $response->hash, $response->worker_version))->process();
                break;
            default:
                throw new InternalZenatonException('Error - unknown action in result: ' . $response->action);
        }
    }

}
