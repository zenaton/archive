<?php

namespace Zenaton\Worker;

use Zenaton\Worker\Decider;
use Zenaton\Worker\Worker;
use Zenaton\Exceptions\InternalZenatonException;

class Slave
{
    protected $uuid;
    protected $microserver;
    protected $type;
    protected $workerVersion;

    public function __construct($uuid, $type, $workerVersion)
    {
        $this->microserver = MicroServer::getInstance()->setUuid($uuid)->setWorkerVersion($workerVersion);
        $this->uuid = $uuid;
        $this->type = $type;
    }

    public function process()
    {
        $response = $this->microserver->askJob($this->type);

        switch ($response->action) {
            case 'DecisionScheduled':
                (new Decider($response->name))->launch();
                break;
            case 'TaskScheduled':
                (new Worker($response->name, $response->input, $response->hash))->process();
                break;
            default:
                throw new InternalZenatonException('Error - unknown action in result: ' . $response->action);
        }
    }

}
