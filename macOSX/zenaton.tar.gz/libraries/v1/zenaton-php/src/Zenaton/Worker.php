<?php

namespace Zenaton;

use Exception;
use Zenaton\Worker\JobBox;
use Zenaton\Worker\MicroServer;
use Zenaton\Worker\Workflow;
use Zenaton\Exceptions\ExternalZenatonException;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ScheduledBoxException;
use Zenaton\Exceptions\ModifiedDeciderException;
use Zenaton\Interfaces\JobInterface;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Traits\SingletonTrait;

class Worker
{
    use SingletonTrait;

    protected $microserver;
    protected $flow;

    const STATUS_MODIFIED = "modified";
    const STATUS_SCHEDULED = "scheduled";
    const STATUS_COMPLETED = "completed";

    public function construct()
    {
        $this->microserver = MicroServer::getInstance();
        $this->flow = Workflow::getInstance();
    }

    public function process($boxes, $isSync)
    {
        // construct array of decorated boxes
        $dboxes = [];
        foreach ($boxes as $box) {
            // Go to the next position
            if (! $isSync) {
                $this->flow->nextAsync();
            } elseif (count($boxes) > 1) {
                $this->flow->nextParallel();
            } else {
                $this->flow->next();
            }
            //
            $dboxes[] = (new JobBox($box))->setSync($isSync)->setPosition($this->flow->getPosition());
        }

        // schedule task or get result if already done
        $response = $this->microserver->execute($dboxes);

        // Decider was modified
        if ($response->status === self::STATUS_MODIFIED) {
            throw new ModifiedDeciderException;
        }

        // Nothing more to do for asynchronous execution
        if (! $isSync) {
            return;
        }

        if ($response->status === self::STATUS_SCHEDULED) {
            throw new ScheduledBoxException;
        }

        if ($response->status === self::STATUS_COMPLETED) {
            // Set properties for last execution
            $this->flow->setProperties($response->properties);

            // return output
            return $response->outputs;
        }

        throw new InternalZenatonException('InputBox with Unkwnon status at position '.$this->flow->getPosition());
    }
}
