<?php

namespace Zenaton\Loader\Symfony;

use Symfony\Component\HttpKernel\Kernel as Symfony;

class Loader
{
    public function autoload()
    {
        // 2 <= Symfony < 3
        $file = getenv('ZENATON_APP_DIR').'/app/bootstrap.php.cache';
        if (file_exists($file)) {
            require $file;

            if (Symfony::VERSION_ID < 20800) {
                require_once getenv('ZENATON_APP_DIR').'/app/AppKernel.php';
            } else {
                require_once getenv('ZENATON_APP_DIR').'/app/autoload.php';
            }

            if (class_exists(Symfony::class)) {
                return Symfony::VERSION_ID;
            }
        }

        // 3.0 <= Symfony <=3.2
        $file = getenv('ZENATON_APP_DIR').'/app/autoload.php';
        if (file_exists($file)) {
            require $file;

            include_once getenv('ZENATON_APP_DIR').'/var/bootstrap.php.cache';

            if (class_exists(Symfony::class)) {
                return Symfony::VERSION_ID;
            }
        }

        // Symfony >= 3.3
        $file = getenv('ZENATON_APP_DIR').'/vendor/autoload.php';
        if (file_exists($file)) {
            require $file;

            if (class_exists(Symfony::class)) {
                return Symfony::VERSION_ID;
            }
        }
    }

    public function boot()
    {
        if (Symfony::VERSION_ID < 30300) {
            require __DIR__.'/boot<3.3.php';
        } else {
            require __DIR__.'/boot>=3.3.php';
        }
    }
}
