<?php

$kernel = new AppKernel('prod', false);
$kernel->loadClassCache();
$kernel->boot();

// helper : add global container function
$GLOBALS['zenatonSymfonyKernel'] = $kernel;

function container()
{
    global $zenatonSymfonyKernel;

    return $zenatonSymfonyKernel->getContainer();
}
