const Log  = require('../../Services/Log')
const {ZenatonError} = require('../../Services/Zenaton').Errors
const { taskManager } = require('../../Services/Zenaton')
const Microserver = require('./Microserver')

module.exports = class Worker {
	constructor(name, input, hash) {
		this.microserver = new Microserver().setHash(hash)
		this.task = taskManager.getTask(name, input)
		Log.info('TASK - Input - ' + name, input, Log.TASK)
	}

	process() {
		try {
			this.task.handle(this.done.bind(this))
		} catch (e) {
			if (e instanceof ZenatonError) {
				this.microserver.failWorker(e)
				this.microserver.reset()
				throw e
			}
			this.microserver.failWork(e)
			this.microserver.reset()
			throw e
		}
	}

	done(error = null, output = null) {
		if (error) {
			this.microserver.failWork(error)
			this.microserver.reset()
			return
		}
		this.microserver.completeWork(output)
		this.microserver.reset()
	}
}
