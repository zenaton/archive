const Workflow = require('./Workflow')
const Microserver = require('./Microserver')
const JobBox = require('./JobBox')
const {ScheduledBoxError, InternalZenatonError, ModifiedDeciderError} = require('../../Services/Zenaton').Errors

const STATUS_MODIFIED = 'modified'
const STATUS_SCHEDULED = 'scheduled'
const STATUS_COMPLETED = 'completed'

module.exports = class {
	constructor() {
		this.microserver = new Microserver()
		this.flow = new Workflow()
	}

	process(boxes, isSync)
	{
		// construct array of decorated boxes
		let dboxes = []
		boxes.forEach(box => {
			// Go to the next position
			if (! isSync) {
				this.flow.nextAsync()
			} else if (boxes.length > 1) {
				this.flow.nextParallel()
			} else {
				this.flow.next()
			}
			//
			dboxes.push((new JobBox(box)).setSync(isSync).setPosition(this.flow.getPosition()))
		})

		// schedule task or get result if already done
		let response = this.microserver.execute(dboxes)

		// Decider was modified
		if (response.status === STATUS_MODIFIED) {
			throw new ModifiedDeciderError(
				'"' + this.flow.name + '" has been modified since launch of current instance.' +
				'\nYou can\'t. Seriously.\nSee https://zenaton.com/documentation#workflow-versioning-for-running-instances'
			)
		}

		// Nothing more to do for asynchronous execution
		if (! isSync) {
			return
		}

		if (response.status === STATUS_SCHEDULED) {
			throw new ScheduledBoxError()
		}

		if (response.status === STATUS_COMPLETED) {
			// Set properties for last execution
			this.flow.setProperties(response.properties)

			// return output
			return response.outputs
		}

		throw new InternalZenatonError('InputBox with Unkwnon status at position '.this.flow.getPosition())
	}
}
