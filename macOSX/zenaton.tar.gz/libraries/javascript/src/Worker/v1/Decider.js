/* global console */

const { InternalZenatonError, ScheduledBoxError, ModifiedDeciderError } = require('../../Services/Zenaton').Errors
const Workflow = require('./Workflow')
const Microserver = require('./Microserver')

module.exports = class Decider {
	constructor(name) {
		this.microserver = new Microserver()
		this.flow = new Workflow().setWorkflowName(name)
	}

	launch() {
		let output

		// execute every branches
		while (this.getNextBranch()) {
			try {
				output = this.flow.runBranch()
			} catch (e) {
				// nothing more to do for this branch, continue to next one
				if (e instanceof ScheduledBoxError) {
					this.microserver.completeDecision()
					continue
				}

				// something bad happened in our code, stop current decision
				if (e instanceof InternalZenatonError) {
					this.microserver.failDecider(e)
					console.error(e)
					break
				}

				// user did modify it's decider, sad!
				if (e instanceof ModifiedDeciderError) {
					this.microserver.failDecision(e)
					console.error(e.message)
					break
				}

				// something bad happened in user code, stop current decision
				this.microserver.failDecision(e)
				console.error(e)
				break
			}

			// cool, we complete this branch
			this.microserver.completeDecisionBranch(output)
		}

		// this decision is ended, clean up microserver
		this.microserver.reset()
	}

	getNextBranch() {
		let branch = this.microserver.getBranchToExecute()

		if ('object' === typeof branch && Object.keys(branch).length > 0) {
			// init workflow at this branch stage
			this.flow.init(branch.branch, branch.properties)
			return true
		}
		return false
	}
}
