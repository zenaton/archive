/* global process */

// process.env.ZENATON_LIBRARY_PATH was set by index.js during boot loading
module.exports = require(process.env.ZENATON_LIBRARY_PATH)
