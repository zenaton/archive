package main

import (
	"fmt"
	"runtime"
	"strings"
)

// to run this script, execute "go run path/to/test_lang.go"
func main() {
	version := runtime.Version()
	version = strings.TrimLeft(version, "go")
	fmt.Print("version=" + version)
}
