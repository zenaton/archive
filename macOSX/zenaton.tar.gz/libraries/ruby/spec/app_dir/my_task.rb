# frozen_string_literal: true

class MyTask < Zenaton::Interfaces::Task
  include Zenaton::Traits::Zenatonable

  def handle
    'Task handled'
  end
end
