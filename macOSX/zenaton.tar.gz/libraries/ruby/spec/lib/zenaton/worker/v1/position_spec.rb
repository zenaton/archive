# frozen_string_literal: true

require 'zenaton/worker/v1/position'

RSpec.describe Zenaton::Worker::V1::Position do
  let(:position) { described_class.new }

  describe 'initialization' do
    it 'sets main at 0' do
      expect(position.instance_variable_get(:@main)).to eq(0)
    end

    it 'sets counter at 0' do
      expect(position.instance_variable_get(:@counter)).to eq(0)
    end
    it 'sets position at 0' do
      expect(position.instance_variable_get(:@position)).to eq('0')
    end
  end

  describe '.get' do
    it 'returns the position' do
      position.next
      expect(position.get).to eq('1')
    end
  end

  describe '.next' do
    before { position.next }

    it 'increments the main counter' do
      expect(position.instance_variable_get(:@main)).to eq(1)
    end

    it 'overwrites the position counter' do
      expect(position.instance_variable_get(:@position)).to eq('1')
    end
  end

  describe '.next_async' do
    before { position.next_async }

    it 'increments the main counter' do
      expect(position.instance_variable_get(:@main)).to eq(1)
    end

    it 'overwrites the position counter' do
      expect(position.instance_variable_get(:@position)).to eq('1a')
    end
  end

  describe '.next_parallel' do
    before { position.next_parallel }

    context 'when no previous parallels' do
      it 'increments the main counter' do
        expect(position.instance_variable_get(:@main)).to eq(1)
      end

      it 'resets the counter counter' do
        expect(position.instance_variable_get(:@counter)).to eq(0)
      end

      it 'overwrites the position counter' do
        expect(position.instance_variable_get(:@position)).to \
          eq('1p0')
      end
    end

    context 'when processing in parallel' do
      before { position.next_parallel }

      it 'increments the counter counter' do
        expect(position.instance_variable_get(:@counter)).to eq(1)
      end

      it 'does not change the main counter' do
        expect(position.instance_variable_get(:@main)).to eq(1)
      end

      it 'overwrites the posision counter' do
        expect(position.instance_variable_get(:@position)).to \
          eq('1p1')
      end
    end
  end
end
