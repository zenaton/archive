# frozen_string_literal: true

require 'zenaton/worker/v1/worker'
require 'app_dir/my_task'
require 'support/stub_http'

RSpec.describe Zenaton::Worker::V1::Worker do
  let(:input) { { 'a' => {}, 's' => [] }.to_json }
  let(:worker) { described_class.new('MyTask', input, 'my-hash') }
  let(:microserver) do
    instance_double(
      Zenaton::Worker::V1::Microserver,
      "custom_hash=": nil,
      complete_work: nil,
      reset: nil
    )
  end

  before { setup_test_doubles }

  it 'sets the microserver hash' do
    worker
    expect(microserver).to have_received(:custom_hash=).with('my-hash')
  end

  it 'instantiate the named task' do
    expect(worker.instance_variable_get(:@task)).to be_a(MyTask)
  end

  describe '#process' do
    before { worker.process }

    it 'sends the task result to the microserver' do
      expect(microserver).to have_received(:complete_work).with('Task handled')
    end

    it 'resets the microserver' do
      expect(microserver).to have_received(:reset)
    end
  end

  def setup_test_doubles
    allow(Zenaton::Worker::V1::Microserver).to \
      receive(:instance).and_return(microserver)
  end
end
