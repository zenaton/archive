<?php

namespace Zenaton\Worker;

use Ramsey\Uuid\UuidFactoryInterface;
use Ramsey\Uuid\UuidFactory;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Interfaces\WaitInterface;
use Zenaton\Interfaces\JobInterface;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Services\Library\Version\InstalledVersion;
use Zenaton\Services\Serializer;
use Zenaton\Services\Properties;
use Zenaton\Services\Log;

class JobBox
{
    const ATTRIBUTE_NAME = 'name';
    const ATTRIBUTE_INPUT = 'input';
    const ATTRIBUTE_POSITION = 'position';
    const ATTRIBUTE_EVENT = 'event';
    const ATTRIBUTE_TIMESTAMP = 'timestamp';
    const ATTRIBUTE_DURATION = 'duration';
    const ATTRIBUTE_TYPE = 'type';
    const ATTRIBUTE_SYNC = 'sync';
    const ATTRIBUTE_MAX_PROCESSING_TIME = 'maxProcessingTime';
    const ATTRIBUTE_INTENT_ID = 'intent_id';

    const TYPE_TASK = 'task';
    const TYPE_WORKFLOW = 'workflow';
    const TYPE_WAIT = 'wait';

    protected $version;
    protected $serializer;
    protected $properties;
    protected $job;
    protected $position;
    protected $sync;
    protected $intentId;

    private static $uuidFactory;

    public function __construct(JobInterface $job, $isSync, $position)
    {
        $this->version = new InstalledVersion();
        $this->serializer = new Serializer();
        $this->properties = new Properties();
        $this->log = new Log();
        $this->job = $job;
        $this->sync = $isSync;
        $this->position = $position;
        if ($this->version->gte(00305)) {
            $this->intentId = static::getUuidFactory()->uuid4();
        }
    }

    public function getJob()
    {
        $name = get_class($this->job);

        $data = [
            self::ATTRIBUTE_POSITION => $this->position,
            self::ATTRIBUTE_SYNC => $this->sync,
            self::ATTRIBUTE_NAME => $name,
            self::ATTRIBUTE_INPUT => $this->serializer->encode($this->properties->getPropertiesFromObject($this->job)),
            self::ATTRIBUTE_TYPE => $this->getType(),
        ];

        if ($this->version->gte(00305)) {
            $data[self::ATTRIBUTE_INTENT_ID] = $this->intentId->toString();
        }

        if ($this->isTask()) {
            $data[self::ATTRIBUTE_MAX_PROCESSING_TIME] =
                (method_exists($this->job, 'getMaxProcessingTime')) ?
                    $this->job->getMaxProcessingTime() : null;
        }

        if ($this->isWait()) {
            $event = $this->job->getEvent();
            list($timestamp, $duration) = $this->job->_getTimestampOrDuration();
            $data[self::ATTRIBUTE_EVENT] = $event;
            $data[self::ATTRIBUTE_TIMESTAMP] = $timestamp;
            $data[self::ATTRIBUTE_DURATION] = $duration;
            $this->log->info('WAIT', ['name' => $name, 'event' => $event, 'duration' => $duration, 'timestamp' => $timestamp], Log::TYPE_WAIT);
        }

        return $data;
    }

    protected function getType()
    {
        if ($this->isWait()) {
            return self::TYPE_WAIT;
        }
        if ($this->isTask()) {
            return self::TYPE_TASK;
        }
        // if ($this->isWorkflow()) {
        //     return self::TYPE_WORKFLOW;
        // }
        throw new InternalZenatonException('Unknown type');
    }

    public function isWait()
    {
        return $this->job instanceof WaitInterface;
    }

    public function isTask()
    {
        return $this->job instanceof TaskInterface;
    }

    public function isWorkflow()
    {
        return $this->job instanceof WorkflowInterface;
    }

    public static function setUuidFactory(UuidFactoryInterface $uuidFactory)
    {
        static::$uuidFactory = $uuidFactory;
    }

    public static function getUuidFactory()
    {
        if (null === static::$uuidFactory) {
            static::$uuidFactory = new UuidFactory();
        }

        return static::$uuidFactory;
    }

    public static function resetUuidFactory()
    {
        static::$uuidFactory = null;
    }
}
