import zenaton

from ..services.importer import Importer
from ..services.log import Log
from ..services.sync_http import SyncHttp
from ..worker.v1.decider import Decider
from ..worker.v1.microserver import Microserver
from ..worker.v1.processor import Processor
from ..worker.v1.worker import Worker


class Slave:

    def __init__(self, job, boot):
        self.job = job
        self.boot = boot
        self.http = SyncHttp()
        self.log = Log()

    def process(self):
        self.job = self.__fetch_job()
        job_class_name = self.job['name']
        job_class = Importer(self.boot).import_class(job_class_name)
        if self.__valid_job(job_class):
            return self.process_job(self.job)
        raise Exception('Unknown {} probably missing in your --boot file'.format(self.job['name']))

    def process_job(self, job):
        self.__setup_microserver(job)
        zenaton.engine.Engine().processor = Processor()
        action = job['action']
        if action == 'DecisionScheduled':
            return Decider(job, self.boot).launch()
        elif action == 'TaskScheduled':
            return Worker(job, self.boot).process()
        else:
            raise Exception('Unknown action {}'.format(action))

    def __setup_microserver(self, job):
        microserver = Microserver(boot=self.boot, name=job['name'])
        microserver.boot = self.boot
        microserver.uuid = job['uuid']
        microserver.worker_version = job['worker_version']
        return microserver

    def __fetch_job(self):
        response = self.http.get(self.job)
        self.log.info('INFRA - Ask Job - (get) {}'.format(self.job),
                      {'response': response},
                      Log.TYPE_INFRA)
        return response

    def __valid_job(self, klass):
        return issubclass(klass, zenaton.abstracts.workflow.Workflow) or issubclass(klass,
                                                                                    zenaton.abstracts.task.Task)
