<?php

namespace Zenaton\Test\Mock\Task;

use Zenaton\Interfaces\TaskInterface;

class NoAutomaticRetryTask implements TaskInterface
{
    public function handle()
    {
        throw new \RuntimeException("I'm always failing!");
    }

    public function onErrorRetryDelay()
    {
        return false;
    }
}
