from zenaton.abstracts.task import Task
from zenaton.abstracts.workflow import Workflow
from zenaton.services.properties import Properties
from zenaton.services.serializer import Serializer
from zenaton.tasks.wait import Wait

from ...services.log import Log

from ...services.version import Version
import uuid

class JobBox:
    ATTRIBUTE_NAME = 'name'
    ATTRIBUTE_INPUT = 'input'
    ATTRIBUTE_POSITION = 'position'
    ATTRIBUTE_EVENT = 'event'
    ATTRIBUTE_TIMESTAMP = 'timestamp'
    ATTRIBUTE_DURATION = 'duration'
    ATTRIBUTE_TYPE = 'type'
    ATTRIBUTE_SYNC = 'sync'
    ATTRIBUTE_MAX_PROCESSING_TIME = 'maxProcessingTime'
    ATTRIBUTE_INTENT_ID = 'intent_id'

    TYPE_TASK = 'task'
    TYPE_WORKFLOW = 'workflow'
    TYPE_WAIT = 'wait'

    def __init__(self, given_job):
        self.serializer = Serializer()
        self.properties = Properties()
        self.log = Log()
        self.job = given_job
        if Version.sdk_installed_version() > 303:
            self.intent_id = str(uuid.uuid4())

    def job_data(self):
        name = type(self.job).__name__

        data = {
            self.ATTRIBUTE_POSITION: self.position,
            self.ATTRIBUTE_SYNC: self.sync,
            self.ATTRIBUTE_NAME: name,
            self.ATTRIBUTE_INPUT: self.serializer.encode(self.properties.from_(self.job)),
            self.ATTRIBUTE_TYPE: self.job_type()
        }

        if self.is_task() and hasattr(self.job, 'max_processing_time'):
            data[self.ATTRIBUTE_MAX_PROCESSING_TIME] = self.job.max_processing_time()

        if Version.sdk_installed_version() > 303:
            data[self.ATTRIBUTE_INTENT_ID] = self.intent_id

        if self.is_wait():
            timestamp, duration = self.job.get_timetamp_or_duration()
            if hasattr(self.job, 'event'):
                event = self.job.event
                data[self.ATTRIBUTE_EVENT] = event
            else:
                event = None
            data[self.ATTRIBUTE_TIMESTAMP] = timestamp
            data[self.ATTRIBUTE_DURATION] = int(duration) if duration else duration
            self.log.info(
                'WAIT',
                {'name': name, 'event': event, 'duration': duration, 'timestamp': timestamp},
                Log.TYPE_WAIT
            )
        return data

    def job_type(self):
        if self.is_wait():
            return self.TYPE_WAIT
        if self.is_task():
            return self.TYPE_TASK
        raise Exception('Unknown type')

    def is_wait(self):
        return issubclass(type(self.job), Wait)


    def is_task(self):
        return issubclass(type(self.job), Task)

    def is_workflow(self):
        return issubclass(type(self.job), Workflow)
