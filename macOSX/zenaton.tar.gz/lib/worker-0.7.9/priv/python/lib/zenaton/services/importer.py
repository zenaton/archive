import importlib.util
import inspect

from ..worker_exceptions import ClassNotFound


class Importer:

    def __init__(self, boot):
        self.boot = boot

    def import_workflow(self, name, args):

        spec = importlib.util.spec_from_file_location('boot', self.boot)
        boot = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(boot)

        if args is None or args == {}:
            return getattr(boot, name)()
        else:
            if args.get('args', None) is not None:
                return getattr(boot, name)(**(dict(args['args'])))
            else:
                return getattr(boot, name)(**args)

    def import_class(self, name):

        spec = importlib.util.spec_from_file_location('boot', self.boot)
        boot = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(boot)

        if hasattr(boot, name):
            return getattr(boot, name)

        for module in dir(boot):
            try:
                workflow_path = inspect.getfile(getattr(boot, module))
                workflow_spec = importlib.util.spec_from_file_location('workflow', workflow_path)
                workflow_module = importlib.util.module_from_spec(workflow_spec)
                workflow_spec.loader.exec_module(workflow_module)
                return getattr(workflow_module, name)
            except (AttributeError, TypeError):
                pass

        raise ClassNotFound(
            "Importer could not find the {} class in {} nor its imported packages".format(name, self.boot))
