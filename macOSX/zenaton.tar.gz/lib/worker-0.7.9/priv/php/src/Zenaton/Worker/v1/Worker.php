<?php

namespace Zenaton\Worker;

use Exception;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Services\Log;
use Zenaton\Services\Properties;
use Zenaton\Services\Serializer;

class Worker
{
    protected $log;
    protected $microserver;
    protected $job;
    protected $task;

    public function __construct(Job $job)
    {
        $this->job = $job;
        $this->microserver = MicroServer::getInstance()->setHash($job->get('hash'));
        $input = (new Serializer())->decode($job->get('input'));
        $this->task = (new Properties())->getObjectFromNameAndProperties(
            $job->get('name'),
            $input,
            TaskInterface::class
        );

        if (\class_exists(\Zenaton\Runtime\Contexts\TaskContext::class) && \method_exists($this->task, 'setContext')) {
            $this->task->setContext(new \Zenaton\Runtime\Contexts\TaskContext([
                'id' => $job->get('intent_id'),
                'retryIndex' => $job->get('retry_index'),
            ]));
        }

        (new Log())->info('TASK - Input - '.$job->get('name'), $input, Log::TYPE_TASK);
    }

    public function process()
    {
        $extra = [];

        // do task
        try {
            $output = $this->task->handle();
        } catch (ZenatonException $e) {
            $this->microserver->failWorker($e, $extra);
            $this->microserver->reset();
            throw $e;
        } catch (Exception $e) {
            // Execute method onErrorRetryDelay if it exists
            if (false !== $retryDelay = $this->retrieveRetryDelay($e)) {
                $extra['retry'] = ['delay' => $retryDelay];
            }

            // tell microserver we have an exception
            $this->microserver->failWork($e, $extra);
            $this->microserver->reset();
            throw $e;
        }

        // tell microserver we have the result
        $this->microserver->completeWork($output);
        $this->microserver->reset();
    }

    /**
     * Retrieves the delay to wait before the next automatically retried attempt.
     *
     * @param Exception $e The exception which failed the task.
     *
     * @return false|int
     */
    private function retrieveRetryDelay($e)
    {
        if (\method_exists($this->task, 'onErrorRetryDelay')) {
            try {
                $delay = $this->task->onErrorRetryDelay($e);

                // null and false means the user does not want the task to be retried
                if (null === $delay || false === $delay) {
                    return false;
                }

                // We expect user to return a float or int >= 0
                if ((\is_float($delay) || \is_int($delay)) && $delay >= 0) {
                    (new Log())->info('TASK - Retry Delay - '.$this->job->get('name').' - Attempt #'.$this->job->get('retry_index'), $delay, Log::TYPE_TASK);

                    return (int) $delay;
                }

                // Any other value is considered an error from the user
                $error = <<<'MESSAGE'
Unexpected value of type %s returned in %s::onErrorRetryDelay() method: %s

The method is expected to return a number superior or equal to 0, corresponding to the number of
seconds to wait before automatically retrying the task. If the task must not be automatically retried,
the method is expected to return either null or false.
MESSAGE;

                throw new \UnexpectedValueException(\sprintf($error, \gettype($delay), $this->job->get('name'), \print_r($delay, true)));
            } catch (Exception $e) {
                $this->microserver->failWork($e);
                $this->microserver->reset();

                throw $e;
            }
        }

        return false;
    }
}
