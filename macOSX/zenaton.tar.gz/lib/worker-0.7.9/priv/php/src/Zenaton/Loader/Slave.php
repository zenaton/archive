<?php

namespace Zenaton\Loader;

use Zenaton\Engine\Engine;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Interfaces\TaskInterface as Task;
use Zenaton\Interfaces\WorkflowInterface as Workflow;
use Zenaton\Services\Is;
use Zenaton\Services\Log;
use Zenaton\Services\SyncHttp;
use Zenaton\Worker\Decider;
use Zenaton\Worker\Job;
use Zenaton\Worker\MicroServer;
use Zenaton\Worker\Processor;
use Zenaton\Worker\Worker;

class Slave
{
    use Is;

    protected $job;
    protected $http;
    protected $log;

    public function __construct($job)
    {
        // url to retrieve job
        $this->job = $job;
        // init http service
        $this->http = new SyncHttp();
        // init log service
        $this->log = new Log();
    }

    public function process()
    {
        // get job to do
        $job = $this->getJob();

        // check sources version
        if ($this->is($job->get('name'), Workflow::class) || $this->is($job->get('name'), Task::class)) {
            return $this->processJob($job);
        }

        throw new ZenatonException('Unknown job type for "'.$job->get('name').'", you should probably update your Zenaton worker');
    }

    protected function processJob($job)
    {
        // set uuid and worker version for calls to microserver
        MicroServer::getInstance()->setUuid($job->get('uuid'))->setWorkerVersion($job->get('worker_version'));

        // inject processor in Zenaton library engine ;-)
        Engine::getInstance()->setProcessor(Processor::getInstance());

        // launch decider or worker
        switch ($job->get('action')) {
            case 'DecisionScheduled':
                (new Decider($job))->launch();
                break;
            case 'TaskScheduled':
                (new Worker($job))->process();
                break;
            default:
                throw new InternalZenatonException('Unknown action: '.$job->get('action'));
        }
    }

    /**
     * Get job to perform.
     */
    protected function getJob()
    {
        $response = $this->http->get($this->job);

        $this->log->info('INFRA - Ask Job - (get) '.$this->job, ['response' => $response], Log::TYPE_INFRA);

        return new Job($response);
    }
}
