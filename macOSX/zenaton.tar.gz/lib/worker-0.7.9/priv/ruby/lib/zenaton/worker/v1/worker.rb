# frozen_string_literal: true

require_relative './microserver'
require_relative '../../services/log'
require_relative '../../worker_exceptions'

module Zenaton
  module Worker
    module V1
      class Worker
        def initialize(job)
          @microserver = Microserver.instance.tap do |microserver|
            microserver.custom_hash = job['custom_hash']
          end
          input = Services::Serializer.new.decode(job['input'])
          @task = Services::Properties.new.object_from(
            job['name'], input, Zenaton::Interfaces::Task
          )
          @job = job
          Zenaton::Services::Log.new.info(
            "TASK - Input - #{job['name']}",
            input,
            Zenaton::Services::Log::TYPE_TASK
          )
        end

        def process
          extra = {}

          if @task.respond_to?("on_failure_retry_delay") && @job['attempt_number']
            begin
              delay = @task.on_failure_retry_delay(@job['attempt_number'])
              extra['retry'] = {'delay': delay}
            rescue => error
              @microserver.fail_work(error, extra)
              @microserver.reset
              raise error
            end
          end

          begin
            output = @task.handle
          rescue Zenaton::Error => error
            @microserver.fail_worker(error, extra)
            @microserver.reset
            raise error
          rescue StandardError => error
            @microserver.fail_work(error, extra)
            @microserver.reset
            raise error
          end
          @microserver.complete_work(output)
          @microserver.reset
        end
      end
    end
  end
end
