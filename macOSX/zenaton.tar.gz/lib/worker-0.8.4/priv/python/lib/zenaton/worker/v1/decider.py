import logging
import sys

import zenaton

from .microserver import Microserver
from .workflow import Workflow
from ...worker_exceptions import ScheduledBox, ModifiedDecider


class Decider:

    def __init__(self, job, boot):
        logging.basicConfig(stream=sys.stdout)
        self.microserver = Microserver()
        self.flow = Workflow()
        self.flow.name = job['name']
        self.flow.boot = boot
        self.job = job

    def launch(self):
        """execute every branch"""
        while self.__next_branch():
            try:
                output = self.flow.run_branch()
            except ScheduledBox:
                """nothing more to do for this branch, continue to next one"""
                self.microserver.complete_decision()
                continue
            except zenaton.exceptions.InternalError as err:
                """something bad happened in our code, stop current decision"""
                self.microserver.fail_decider(err)
                self.__fail_and_log(err)
                break
            except ModifiedDecider as err:
                """user did modify its decider, sad!"""
                self.microserver.fail_decider(err)
                self.__fail_and_log(err)
                break
            except Exception as err:
                """something bad happened in user code, stop current decision"""
                self.microserver.fail_decider(err)
                self.__fail_and_log(err)
                break
            """cool, we complete this branch"""
            self.microserver.complete_decision_branch(output)

        """this decision is done, clean up microserver"""
        self.microserver.reset()

    def __fail_and_log(self, err):
        logging.error(err)

    def __next_branch(self):
        branch = self.microserver.branch_to_execute()
        if branch and branch != '':
            context_data = {'id': self.job.get('intent_id')}
            self.flow.build(branch['branch'], branch['properties'], context_data)
            return True
        return False
