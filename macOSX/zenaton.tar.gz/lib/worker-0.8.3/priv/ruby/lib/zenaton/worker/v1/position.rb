# frozen_string_literal: true

module Zenaton
  module Worker
    module V1
      # Keeping track of position in queue
      class Position
        SEPARATOR_ASYNC = 'a'
        SEPARATOR_PARALLEL = 'p'

        def initialize
          init
        end

        def init
          @main = 0
          @counter = 0
          @position = '0'
        end

        def get
          @position
        end

        def next
          @main += 1
          @position = @main.to_s
        end

        def next_parallel
          if in_parallel?
            @counter += 1
          else
            @main += 1
            @counter = 0
          end
          @position = "#{@main}#{SEPARATOR_PARALLEL}#{@counter}"
        end

        def next_async
          @main += 1
          @position = "#{@main}#{SEPARATOR_ASYNC}"
        end

        private

        def in_parallel?
          @position.index(SEPARATOR_PARALLEL)
        end
      end
    end
  end
end
