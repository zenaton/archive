import time
import json
import traceback

from zenaton.abstracts.event import Event
from zenaton.client import Client
from zenaton.services.properties import Properties
from zenaton.services.serializer import Serializer
from zenaton.singleton import Singleton

from .workflow import Workflow
from ...services.importer import Importer
from ...services.log import Log
from ...services.sync_http import SyncHttp


class Microserver(metaclass=Singleton):

    def __init__(self, boot=None, name=None):
        self.serializer = Serializer(boot=boot, name=name)
        self.properties = Properties()
        self.log = Log()
        self.http = SyncHttp()
        self.flow = Workflow()

    def reset(self):
        self.uuid = None
        self.custom_hash = None
        self.worker_version = None

    def is_deciding(self):
        return getattr(self, 'custom_hash', None) is None and self.uuid is not None

    def is_working(self):
        return getattr(self, 'custom_hash', False) and self.uuid is not None

    def ask_job(self, job_type):
        url = self.worker_url(
            'uuid/{}/type/{}/job'.format(self.uuid, job_type),
            'worker_version={}'.format(self.worker_version)
        )

        response = self.http.get(url)
        self.log.info(
            'INFRA - Ask Job - (get) {}'.format(url),
            {'response': response},
            Log.TYPE_INFRA
        )
        return response

    def branch_to_execute(self):
        url = self.decision_url('branch')
        response = self.http.get(url)
        self.log.info(
            'DECISION - Branch - (get) {}'.format(url),
            {'response': response},
            Log.TYPE_DECISION
        )
        return response

    def execute(self, boxes):
        url = self.decision_url('execute')
        body = {'works': [box.job_data() for box in boxes]}
        response = self.http.post(url, body)
        if response['status'] == 'completed':
            self.__parse_completed(response)
        self.log.info(
            'DECISION - Execute - (post)  {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_DECISION
        )
        return response

    def complete_decision(self):
        url = self.decision_url('branch')
        body = self.decision_body()
        response = self.http.post(url, body)
        self.log.info(
            'DECISION - Complete - (post) {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_DECISION
        )
        return response

    def complete_decision_branch(self, output=None):
        url = self.decision_url('branch')
        body = self.decision_body()
        if output:
            body['output'] = json.loads(output)
        response = self.http.post(url, body)
        self.log.info(
            'DECISION - Complete Branch - (post) {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_DECISION
        )
        return response

    def decision_body(self):
        return {
            'properties': self.serializer.encode(self.flow.read_properties()),
            'callbacks': self.flow.implemented_callbacks()
        }

    def fail_decider(self, error):
        url = self.decision_url()
        body = self.error_body(error)
        body['status'] = 'zenatonFailed'
        response = self.http.put(url, body)
        self.log.info(
            'DECISION - Decider Failure - (put) {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_DECISION
        )
        return response

    def fail_decision(self, error):
        url = self.decision_url()
        body = self.error_body(error)
        body['status'] = 'failed'
        response = self.http.put(url, body)
        self.log.info(
            'DECISION - Decision Failure - (put) {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_DECISION
        )
        return response

    def decision_url(self, endpoint=''):
        return self.worker_url('decisions/{}/{}'.format(self.uuid, endpoint),
                               'worker_version={}'.format(self.worker_version))

    def complete_work(self, output):
        self.send_work({'status': 'completed', 'output': self.serializer.encode(output)})

    def fail_worker(self, error):
        self.handle_fail_work(error, 'zenatonFailed')

    def fail_work(self, error):
        self.handle_fail_work(error, 'failed')

    def handle_fail_work(self, error, status):
        data = self.error_body(error)
        data['status'] = status
        data['error_input'] = self.serializer.encode(self.properties.from_(error))
        self.send_work(data)

    def send_work(self, body):
        url = self.worker_url('tasks/{}'.format(self.uuid), 'worker_version={}'.format(self.worker_version))
        body['hash'] = self.custom_hash
        response = self.http.post(url, body)
        self.log.info(
            'Task - Send - (post) {}'.format(url),
            {'body': body, 'response': response},
            Log.TYPE_TASK
        )

    def __parse_completed(self, response):
        response['properties'] = self.serializer.decode(response['properties'])
        response['outputs'] = [self.__parse_output(output) for output in response['outputs']]

    def __parse_output(self, output):
        if not output:
            return None
        if type(output) == str:
            output_json = self.serializer.decode(output)
        else:
            if output['event_name'] and output['event_input']:
                output_json = self.decode_event(output)
            else:
                output_json = self.serializer.decode(json.dumps(output))
        return output_json

    def decode_event(self, output):
        event_class = Importer(boot=self.boot).import_task(output['event_name'])
        return self.properties.object_from(
            event_class,
            self.serializer.decode(output['event_input']),
            Event
        )

    def worker_url(self, resource, params=''):
        return Client().worker_url(resource, params)

    def error_body(self, error):
        return {
            'error_name': type(error).__name__,
            'error_code': 0,
            'error_message': str(error),
            'error_stacktrace': self.stacktrace_for(error),
            'failed_at': int(time.time())
        }

    def stacktrace_for(self, error):
        traceback.print_exc()
        return traceback.format_exc()

