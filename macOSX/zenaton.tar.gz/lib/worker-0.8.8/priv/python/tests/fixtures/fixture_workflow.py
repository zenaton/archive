import pytest

from worker.priv.python.lib.zenaton.worker.v1.workflow import Workflow

@pytest.fixture
def workflow():
    return Workflow()
