import platform

print('version={}'.format(str(platform.python_version())))
