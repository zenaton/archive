# frozen_string_literal: true

module Zenaton
  class EnvironmentNotSet < Zenaton::Error; end
  class ModifiedDecider < Zenaton::Error; end
  class ScheduledBox < Zenaton::Error; end
end
