<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Test\Injector;
use Zenaton\Test\Mock\Event\DummyEvent;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\Mock\Workflow\NullWorkflowWithProperties;
use Zenaton\Test\Mock\Workflow\VersionnedWorkflow;
use Zenaton\Test\SingletonTesting;

class WorkflowTest extends TestCase
{
    use Injector;
    use SingletonTesting;

    public function setUp()
    {
        static::destroySingleton(Workflow::class);
    }

    public function testInit()
    {
        $branch = (object) [
            'type' => 'handle',
        ];

        $workflow = Workflow::getInstance();
        $workflow->setWorkflowName(NullWorkflowWithProperties::class);
        $workflow->init($branch, '{"a":{"a":42},"s":[]}');

        $assertions = function () use ($branch) {
            assertEquals(NullWorkflowWithProperties::class, $this->name);
            assertEquals($branch, $this->branch);
            assertInstanceOf(Position::class, $this->position);
        };
        $assertions = $assertions->bindTo($workflow, get_class($workflow));
        $assertions();
    }

    public function testInitOnVersionnedWorkflowInitializesInitialVersion()
    {
        $branch = (object) [
            'type' => 'handle',
        ];

        $workflow = Workflow::getInstance();
        $workflow->setWorkflowName(VersionnedWorkflow::class);
        $workflow->init($branch, '{"a":{"a":42},"s":[]}');

        $assertions = function () use ($branch) {
            assertEquals(NullWorkflowWithProperties::class, $this->name);
            assertEquals($branch, $this->branch);
            assertInstanceOf(Position::class, $this->position);
        };
        $assertions = $assertions->bindTo($workflow, get_class($workflow));
        $assertions();
    }

    public function testRunBranchHandle()
    {
        $branch = (object) [
            'type' => 'handle',
        ];

        $workflow = Workflow::getInstance();

        $flow = $this->createMock(WorkflowInterface::class);

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('handle')
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    public function testRunBranchOnEvent()
    {
        $branch = (object) [
            'type' => 'onEvent',
            'data' => (object) [
                'event_name' => DummyEvent::class,
                'event_input' => '{"a":[],"s":[]}',
            ],
        ];

        $workflow = Workflow::getInstance();

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onEvent',
                'handle',
            ])
            ->getMock()
        ;

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('onEvent')
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    public function testRunBranchOnStart()
    {
        $branch = (object) [
            'type' => 'onStart',
            'data' => (object) [
                'task_name' => SimpleReturnValueTask::class,
                'task_input' => '{"a":[],"s":[]}',
            ],
        ];

        $workflow = Workflow::getInstance();

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onStart',
                'handle',
            ])
            ->getMock()
        ;

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('onStart')
            ->with($this->isInstanceOf(SimpleReturnValueTask::class))
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    public function testRunBranchOnSuccess()
    {
        $branch = (object) [
            'type' => 'onSuccess',
            'data' => (object) [
                'task_name' => SimpleReturnValueTask::class,
                'task_input' => '{"a":[],"s":[]}',
                'task_output' => '{"d":"hello","s":[]}',
            ],
        ];

        $workflow = Workflow::getInstance();

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onSuccess',
                'handle',
            ])
            ->getMock()
        ;

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('onSuccess')
            ->with($this->isInstanceOf(SimpleReturnValueTask::class))
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    public function testRunBranchOnFailure()
    {
        $branch = (object) [
            'type' => 'onFailure',
            'data' => (object) [
                'task_name' => SimpleReturnValueTask::class,
                'task_input' => '{"a":[],"s":[]}',
                'error_name' => \RuntimeException::class,
                'error_input' => '{"a":[],"s":[]}',
            ],
        ];

        $workflow = Workflow::getInstance();

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onFailure',
                'handle',
            ])
            ->getMock()
        ;

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('onFailure')
            ->with(
                $this->isInstanceOf(SimpleReturnValueTask::class),
                $this->isInstanceOf(\RuntimeException::class)
            )
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    public function testRunBranchOnTimeout()
    {
        $branch = (object) [
            'type' => 'onTimeout',
            'data' => (object) [
                'task_name' => SimpleReturnValueTask::class,
                'task_input' => '{"a":[],"s":[]}',
            ],
        ];

        $workflow = Workflow::getInstance();

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onTimeout',
                'handle',
            ])
            ->getMock()
        ;

        $this->inject(function () use ($branch, $flow) {
            $this->branch = $branch;
            $this->flow = $flow;
        }, $workflow);

        $flow
            ->expects($this->once())
            ->method('onTimeout')
            ->with($this->isInstanceOf(SimpleReturnValueTask::class))
            ->willReturn(42)
        ;

        $result = $workflow->runBranch();

        static::assertEquals(42, $result);
    }

    /**
     * @dataProvider dataProviderForTestGetImplementedCallbacks
     */
    public function testGetImplementedCallbacks($flow, $expected)
    {
        $workflow = Workflow::getInstance();

        $this->inject(function () use ($flow) {
            $this->flow = $flow;
        }, $workflow);

        static::assertCount(count($expected), $workflow->getImplementedCallbacks());
        static::assertArraySubset($workflow->getImplementedCallbacks(), $expected, true);
    }

    public function dataProviderForTestGetImplementedCallbacks()
    {
        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->setMethods([
                'onEvent',
                'onFailure',
                'onStart',
                'onSuccess',
                'onTimeout',
                'handle',
            ])
            ->getMock()
        ;

        yield [$flow, [
            'onEvent',
            'onFailure',
            'onStart',
            'onSuccess',
            'onTimeout',
        ]];

        $flow = $this
            ->getMockBuilder(WorkflowInterface::class)
            ->getMock()
        ;

        yield [$flow, []];
    }
}
