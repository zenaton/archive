# frozen_string_literal: true

module Zenaton
  module Loader
    class LoaderError < StandardError; end
  end
end
