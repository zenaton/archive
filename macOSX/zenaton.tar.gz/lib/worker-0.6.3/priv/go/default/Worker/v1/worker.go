package v1

import (
	"bytes"
	"fmt"
	"os"
	"runtime/debug"

	"../../services/log"
	"../../services/zenaton"
)

type Worker struct {
	microserver *MicroServer
	task        *zenaton.Task
}

func NewWorker(name, input, hash string) *Worker {
	log.Info("TASK - Input - "+name, input, log.TASK())
	return &Worker{
		microserver: NewMicroServer().setHash(hash),
		task:        zenaton.TaskManager.UnsafeGetInstance(name, input),
	}
}

func (w *Worker) Process() error {
	defer func() {
		r := recover()

		if r == nil {
			return
		}

		namer, ok := r.(interface{ Name() string })
		name := "TaskPanic"

		if ok {
			name = namer.Name()
		}

		stack := getTraceWithOffset(4)
		message := fmt.Sprint(r)

		switch r {
		case zenaton.Errors.InternalZenatonError, zenaton.Errors.ExternalZenatonError:
			w.microserver.FailWorker(name, message, stack)
		default:

			w.microserver.failWork(name, message, stack)
			w.microserver.reset()

			fmt.Fprintln(os.Stderr, r)
			fmt.Fprintln(os.Stderr, stack)
			os.Exit(0)
		}
	}()

	output, err := w.task.Handle()

	combinedOutput := make(map[string]interface{})
	combinedOutput["output"] = output
	if err != nil {
		combinedOutput["error"] = err.Error()
	}

	w.microserver.completeWork(combinedOutput)
	w.microserver.reset()
	return nil
}

func getTraceWithOffset(offset int) string {
	stack := debug.Stack()
	parts := bytes.Split(stack, []byte("\n"))
	partsMinusRemoved := parts[offset*2+1:]
	stack = bytes.Join(partsMinusRemoved, []byte("\n"))
	return string(stack)
}
