package log

import (
	"fmt"
	"os"
	"strconv"
)

const (
	TypeAll         = "*"
	TypeDecision    = "decision"
	TypeTask        = "task"
	TypeWait        = "wait"
	TypeMicroserver = "microserver"
	TypeInfra       = "infra"
	LevelNone       = 0
	LevelInfo       = 1
	LevelWarning    = 2
	LevelError      = 3
)

type LogMSG struct {
	Body     interface{} `json:"body"` //todo: do I need these json tags?
	Response interface{} `json:"body"`
}

func Always(title string, msg interface{}, Type string) {
	Log(title, msg, LevelNone, Type)
}

func Info(title string, msg interface{}, Type string) {
	Log(title, msg, LevelInfo, Type)
}

func Warning(title string, msg interface{}, Type string) {
	Log(title, msg, LevelWarning, Type)
}

func Error(title string, msg interface{}, Type string) {
	Log(title, msg, LevelError, Type)
}

func DECISION() string {
	return TypeDecision
}

func TASK() string {
	return TypeTask
}

func WAIT() string {
	return TypeWait
}

func MICROSERVER() string {
	return TypeMicroserver
}

func INFRA() string {
	return TypeInfra
}

//todo: ask Gilles what to do in the case of these errors. Should I panic? Do nothing? Return an error?
//todo: it seems that failing to log shouldn't crash the application, or stop a workflow, for example.
func Log(title string, msg interface{}, level int, Type string) {

	var logLevel int
	var err error

	if os.Getenv("ZENATON_LOG_LEVEL") == "" {
		logLevel = LevelNone
	} else {
		logLevel, err = strconv.Atoi(os.Getenv("ZENATON_LOG_LEVEL"))
		if err != nil {
			panic(err)
		}
	}

	var logType string
	if os.Getenv("ZENATON_LOG_TYPE") == "" {
		logType = TypeAll
	} else {
		logType = os.Getenv("ZENATON_LOG_TYPE")
	}

	logFile := os.Getenv("ZENATON_APP_DIR") + "/zenaton.log"

	if logLevel >= level && (TypeAll == logType || logType == Type) {
		var str = "\n==== " + title + " ====\n"

		str = fmt.Sprintf("%s %+v\n", str, msg)

		f, err := os.OpenFile(logFile, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
		if err != nil {
			panic(err)
		}
		_, err = f.Write([]byte(str))
		if err != nil {
			panic(err)
		}
		err = f.Close()
		if err != nil {
			panic(err)
		}
	}
}
