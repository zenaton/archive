# frozen_string_literal: true

require 'json'
info = {
  'ruby' => {
    'version' => RUBY_VERSION,
    'env' => ENV.to_h
  }
}

puts info.to_json
