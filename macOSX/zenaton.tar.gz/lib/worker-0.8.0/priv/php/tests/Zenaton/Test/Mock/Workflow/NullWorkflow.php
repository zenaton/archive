<?php

namespace Zenaton\Test\Mock\Workflow;

use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Traits\Zenatonable;

class NullWorkflow implements WorkflowInterface
{
    use Zenatonable;

    public function handle()
    {
    }
}
