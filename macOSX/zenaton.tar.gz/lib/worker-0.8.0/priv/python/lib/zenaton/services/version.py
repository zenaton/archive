import zenaton


class Version:
    @staticmethod
    def sdk_installed_version():
        if hasattr(zenaton, '__version_id__'):
            return zenaton.__version_id__
        else:
            return 303
