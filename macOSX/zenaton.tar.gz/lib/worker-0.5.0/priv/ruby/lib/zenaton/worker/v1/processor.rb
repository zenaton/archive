# frozen_string_literal: true

require 'singleton'

require_relative '../../worker_exceptions'
require_relative './microserver'
require_relative './workflow'
require_relative './job_box'

module Zenaton
  module Worker
    module V1
      class Processor
        include Singleton

        STATUS_MODIFIED = 'modified'
        STATUS_SCHEDULED = 'scheduled'
        STATUS_COMPLETED = 'completed'

        def initialize
          @microserver = Microserver.instance
          @flow = Workflow.instance
        end

        def process(boxes, sync)
          return process_from_task(boxes, sync) if @microserver.working?
          return process_from_workflow(boxes, sync) if @microserver.deciding?
          raise InternalError, 'process: Unknown state'
        end

        private

        # returns array of results
        def process_from_task(boxes, sync)
          client = Client.instance
          # handle sync executions and dispatch async
          boxes.map do |box|
            if box.is_a?(Zenaton::Interfaces::Workflow)
              if sync
                box.handle
              else
                client.start_workflow(box)
                nil
              end
            elsif box.is_a?(Zenaton::Interfaces::Task)
              if sync
                box.handle
              else
                if client.respond_to?(:start_task)
                  client.start_task(box)
                else
                  box.handle
                end
                nil
              end
            else
              raise InternalError, 'processFromTask: Unknown type'
            end
          end
        end

        def process_from_workflow(boxes, sync)
          dboxes = decorate_boxes(boxes, sync)

          # schedule task or get result if already done
          response = @microserver.execute(dboxes)

          # Decider was modified
          raise_modified if STATUS_MODIFIED == response['status']

          # Nothing more to do for synchronous execution
          return Array.new(boxes.length) unless sync
          raise ScheduledBox if STATUS_SCHEDULED == response['status']
          # return output
          return output_with_properties(response) if STATUS_COMPLETED == response['status']
          raise InternalError, "InputBox with Unknown status at position: #{@flow.get_position}"
        end

        # construct array of decorated boxes
        def decorate_boxes(boxes, sync)
          boxes.map do |box|
            increment_position(boxes, sync)
            JobBox.new(box).tap do |job_box|
              job_box.sync = sync
              job_box.position = @flow.get_position
            end
          end
        end

        def increment_position(boxes, sync)
          if !sync
            @flow.next_async
          elsif boxes.length > 1
            @flow.next_parallel
          else
            @flow.next
          end
        end

        def raise_modified
          error = <<~ERROR
            #{@flow.name} has been modified since launch of current instance
            You can't. Seriously.
            See https://zenaton.com/documentation#workflow-versioning-for-running-instances
          ERROR
          raise ModifiedDecider, error
        end

        def output_with_properties(response)
          @flow.write_properties(response['properties'])
          response['outputs']
        end
      end
    end
  end
end
