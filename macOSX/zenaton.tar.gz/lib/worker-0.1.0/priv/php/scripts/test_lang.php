<?php

// Just checking presence and version of PHP
echo "version=".phpversion();
