import json

from .log import Log
# import requests
from .requests import api
from .requests.exceptions import ConnectionError


class SyncHttp:
    """Http Call Header"""
    HEADER = {'Content-type': 'application/json', 'Accept': 'application/json'}

    def __init__(self):
        self.log = Log()

    """Makes a GET request"""
    def get(self, url):
        response = self.request(method='GET', url=url, headers=self.HEADER)
        self.__write_log(url, 'GET', url, response)
        return response

    """Makes a POST request"""
    def post(self, url, body):
        response = self.request(method='POST', url=url, headers=self.HEADER, data=body)
        self.__write_log(url, 'POST', url, response)
        return response

    """Makes a PUT request"""
    def put(self, url, body):
        response = self.request(method='PUT', url=url, headers=self.HEADER, data=body)
        self.__write_log(url, 'PUT', url, response)
        return response

    """Do the actual request"""
    def request(self, method, url, headers, data=None):
        try:
            r = api.request(method=method, url=url, headers=headers, data=json.dumps(data))
            content = r.json()
            if r.status_code >= 400:
                raise Exception(r.content)
        except json.decoder.JSONDecodeError:
            raise Exception
        except ConnectionError:
            raise ConnectionError
        if False:
            print('\n')
            print(method)
            print(headers)
            print(url)
            print(json.dumps(data))
            print(content)
        return content

    """Write request's log"""
    def __write_log(self, url, verb, body, response):
        self.log.info(
            'MICROSERVER ({}) {}'.format(verb, body),
            json.dumps({'response': response, 'body': body}),
            self.log.TYPE_MICROSERVER)
