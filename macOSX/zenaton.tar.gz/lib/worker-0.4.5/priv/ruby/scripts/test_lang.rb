# frozen_string_literal: true

puts "version=#{RUBY_VERSION}"
