<?php

use Zenaton\Loader\Loader;
use Zenaton\Loader\Slave;
use Zenaton\Worker\MicroServer;

// do not display errors on stdout
ini_set('display_errors', 'stderr');

// autoload our classes
require __DIR__.'/../vendor/autoload.php';
// load class
$loader = new Loader($argv);

// load boot file
$loader->boot();

// create Slave instance
$job = $loader->getJobUrl();
$slave = new Slave($job);

// we have all what we need
$loader->success();

// define shutdown to catch non-thrown error
function shutdown()
{
    $last = error_get_last();
    if (is_array($last)) {
        $e = new \Exception($last['message'].' in '.$last['file'].' on line '.$last['line']);
        $ms = MicroServer::getInstance();
        if ($ms->isWorking()) {
            $ms->failWorker($e);
        }
        if ($ms->isDeciding()) {
            $ms->failDecider($e);
        }
    }
}
register_shutdown_function('shutdown');

// we arrive here only if everything went well, including the success() call to url
$slave->process();
