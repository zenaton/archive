<?php

namespace Zenaton\Exceptions;

class EnvironmentNotSetException extends ExternalZenatonException
{
}
