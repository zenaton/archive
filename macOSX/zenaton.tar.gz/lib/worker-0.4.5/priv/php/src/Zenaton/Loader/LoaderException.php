<?php

namespace Zenaton\Loader;

class LoaderException extends \Exception
{
}
