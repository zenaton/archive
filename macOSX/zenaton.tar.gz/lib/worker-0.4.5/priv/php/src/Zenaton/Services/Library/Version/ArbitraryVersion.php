<?php

namespace Zenaton\Services\Library\Version;

use Zenaton\Services\Library\Version;

final class ArbitraryVersion implements Version
{
    /** @var int */
    private $versionId;

    /**
     * @param int $versionId
     */
    public function __construct($versionId)
    {
        $this->versionId = $versionId;
    }

    public function gte($version)
    {
        return $this->versionId >= $version;
    }
}
