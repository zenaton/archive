<?php

namespace Zenaton\Test\Mock\Workflow;

use Zenaton\Workflows\Version;

class VersionnedWorkflow extends Version
{
    public function versions()
    {
        return [
            NullWorkflowWithProperties::class,
        ];
    }
}
