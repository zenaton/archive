package loader

import (
	"strings"

	"net/url"

	"os"

	"encoding/json"

	"../services/synchttp"
	"../services/zenaton"
)

const (
	paramStatusURL = "status"
	paramAppDir    = "app"
	paramClasses   = "classes"
	paramJobURL    = "job"
)

type Loader struct {
	args    map[string]string
	status  string
	classes string
	appDir  string
}

func NewLoader(args []string) (*Loader, error) {

	l := &Loader{
		args: make(map[string]string),
	}

	for _, param := range args {
		tmp := strings.Split(param, "=")
		key := tmp[0]
		var value string
		if len(tmp) == 2 {
			value = tmp[1]
		}
		l.args[key] = value
	}

	status, err := l.getStatusURL(true)
	if err != nil {
		return nil, err
	}
	l.status = status

	l.appDir, err = l.getAppDir(true)
	if err != nil {
		return nil, err
	}

	err = os.Setenv("ZENATON_APP_DIR", l.appDir)
	if err != nil {
		return nil, zenaton.Errors.Wrap(zenaton.Errors.InternalZenatonError, err)
	}

	return l, nil
}

// todo: check this. Should be able to use handl_only or handle_except env variables. Check the documentation
func (l *Loader) CheckClasses() error {
	type ClassStatus struct {
		HandleOnly   *Class `json:"handle_only"`
		HandleExcept *Class `json:"handle_except"`
	}

	checker := NewClassChecker()
	classes, err := l.getClasses(true)
	if err != nil {
		return err
	}

	var handleOnly *Class
	if classes["handle_only"] != "" {
		handleOnly = checker.check(classes["handle_only"])
	}

	var handlExcept *Class
	if classes["handle_except"] != "" {
		handlExcept = checker.check(classes["handle_except"])
	}

	return l.Success(ClassStatus{
		HandleOnly:   handleOnly,
		HandleExcept: handlExcept,
	})
}

func (l *Loader) getStatusURL(mandatory bool) (string, error) {

	url, err := l.arg(paramStatusURL, mandatory)
	if err != nil {
		return "", err
	}

	if mandatory && url == "" {
		return "", zenaton.Errors.New("LoaderError", `Missing '`+paramStatusURL+`' parameter`)
	}

	if !l.checkURL(url) {
		return "", zenaton.Errors.New("LoaderError", "'"+url+"' is an invalid url")
	}

	return url, nil
}

func (l *Loader) GetJobURL(mandatory bool) (string, error) {
	url, err := l.arg(paramJobURL, mandatory)
	if err != nil {
		return "", err
	}

	if (mandatory || "" != url) && !l.checkURL(url) {
		return "", l.failure(`'` + url + `' is an invalid url`)
	}

	return url, nil
}

func (l *Loader) getClasses(mandatory bool) (map[string]string, error) {
	var jsonString, err = l.arg(paramClasses, mandatory)
	if err != nil {
		return nil, err
	}

	var cs map[string]string
	err = json.Unmarshal([]byte(jsonString), &cs)
	if err != nil {
		return nil, l.failure(`Provided '` + paramClasses + `' parameter '` + jsonString + `' is invalid json`)
	}
	return cs, nil
}

func (l *Loader) getAppDir(mandatory bool) (string, error) {
	arg, err := l.arg(paramAppDir, mandatory)
	if err != nil {
		return "", err
	}

	var dir = strings.TrimRight(arg, `/`)
	err = l.checkDir(dir)
	if err != nil {
		return "", err
	}

	return dir, nil
}

func (l *Loader) arg(Type string, mandatory bool) (string, error) {
	var arg = l.args[Type]

	if arg == "" && mandatory {
		return "", l.failure("Missing '" + Type + "' parameter")
	}

	return arg, nil
}

type postBody struct {
	Status string      `json:"status"`
	Data   interface{} `json:"data"`
}

func (l *Loader) Success(data interface{}) error {
	body := postBody{
		Status: "ok",
		Data:   data,
	}
	return l.post(body)
}

func (l *Loader) failure(msg string) error {
	err := l.post(`{"error": "` + msg + `"}`)
	if err != nil {
		return err
	}
	return zenaton.Errors.New("LoaderError", msg)
}

func (l *Loader) post(body interface{}) error {
	var resp interface{}
	err := synchttp.Post(l.status, body, &resp)
	if err != nil {
		return zenaton.Errors.Wrap("LoaderError", err)
	}
	return nil
}

func (l *Loader) checkFile(file string) error {
	_, err := os.Stat(file)
	if err != nil {
		return l.failure("'" + file + "' is not a file, or cannot be read")
	}
	return nil
}

func (l *Loader) checkDir(dir string) error {

	_, err := os.Stat(dir)
	if err != nil {
		return l.failure("'" + dir + "' is not a directory")
	}
	return nil
}

func (l *Loader) checkURL(URL string) bool {
	_, err := url.ParseRequestURI(URL)
	if err != nil {
		return false
	}
	return true
}
