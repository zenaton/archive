import copy
import http.client
import json


from urllib.parse import urlparse

from .log import Log


class SyncHttp:
    """Http Call Header"""
    HEADER = {'Content-type': 'application/json', 'Accept': 'application/json'}

    def __init__(self):
        self.log = Log()

    """Makes a GET request"""
    def get(self, url):
        response = self.request(method='GET', url=url)
        self.__write_log(url, 'GET', url, response)
        return response

    """Makes a POST request"""
    def post(self, url, body):
        response = self.request(method='POST', url=url, data=body)
        self.__write_log(url, 'POST', url, response)
        return response

    """Makes a PUT request"""
    def put(self, url, body):
        response = self.request(method='PUT', url=url, data=body)
        self.__write_log(url, 'PUT', url, response)
        return response

    """Parses host and path from the full URL"""
    def get_host_and_path(self, url):
        o = urlparse(url)
        host = o.netloc
        path = '{}{}{}'.format(o.path, '?' if o.query else '', o.query)
        return host, path

    """Makes the actual HTTP request"""
    def request(self, method, url, data=None):
        host, path = self.get_host_and_path(url)
        conn = http.client.HTTPConnection(host)
        conn.request(method, path, json.dumps(data), self.HEADER)
        r = conn.getresponse()
        content = json.loads(r.read().decode('utf-8'))
        conn.close()
        return content

    """Write request's log"""
    def __write_log(self, url, verb, body, response):
        self.log.info(
            'MICROSERVER ({}) {}'.format(verb, body),
            json.dumps({'response': response, 'body': body}),
            self.log.TYPE_MICROSERVER)
