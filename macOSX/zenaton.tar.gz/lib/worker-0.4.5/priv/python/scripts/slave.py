import sys
from pathlib import Path

if __name__ == '__main__' and __package__ is None:
    file = Path(__file__).resolve()
    parent, top = file.parent, file.parents[2]

    sys.path.append(str(top))
    try:
        sys.path.remove(str(parent))
    except ValueError:  # Already removed
        pass

    import python.lib.zenaton.loader.loader as loader
    import python.lib.zenaton.loader.slave as slave
    import python.lib.zenaton.worker.v1.microserver as microserver

    __package__ = 'python.lib.zenaton.loader.loader'

"""load class"""
load = loader.Loader(*sys.argv)

"""load boot file"""
load.boot()

"""create Slave instance"""
job = load.job_url()
slave = slave.Slave(job=job, boot=load.boot_file_path())

"""we have all we need"""
load.success()

try:
    """we arrive here only if everything went well, including the success call to url"""
    slave.process()
except Exception as err:
    micro = microserver.Microserver()
    if micro.is_working():
        micro.fail_worker(err)
    if micro.is_deciding():
        micro.fail_decider(err)
    raise err
