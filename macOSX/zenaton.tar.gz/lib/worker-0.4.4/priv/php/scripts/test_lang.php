<?php

// Just checking presence and version of PHP
echo sprintf('version=%d.%d.%d', PHP_MAJOR_VERSION, PHP_MINOR_VERSION, PHP_RELEASE_VERSION);
