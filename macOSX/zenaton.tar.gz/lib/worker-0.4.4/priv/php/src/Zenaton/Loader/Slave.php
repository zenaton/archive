<?php

namespace Zenaton\Loader;

use Zenaton\Exceptions\ZenatonException;
use Zenaton\Exceptions\InternalZenatonException;

use Zenaton\Services\SyncHttp;
use Zenaton\Services\Is;
use Zenaton\Services\Log;

use Zenaton\Worker\Decider;
use Zenaton\Worker\Worker;
use Zenaton\Worker\Processor;
use Zenaton\Worker\MicroServer;

// use Zenaton\Worker\v2\Decider as Decider2;
// use Zenaton\Worker\v2\Worker as Worker2;
// use Zenaton\Worker\v2\Processor as Processor2;
// use Zenaton\Worker\v2\MicroServer as MicroServer2;

use Zenaton\Interfaces\TaskInterface as Task;
use Zenaton\Interfaces\WorkflowInterface as Workflow;
use Zenaton\Engine\Engine;

// use Zenaton\v2\Interfaces\TaskInterface as Task2;
// use Zenaton\v2\Interfaces\WorkflowInterface as Workflow2;
// use Zenaton\v2\Engine\Engine as Engine2;

class Slave
{
    use Is;

    protected $job;
    protected $http;
    protected $log;

    public function __construct($job)
    {
        // url to retrieve job
        $this->job = $job;
        // init http service
        $this->http = new SyncHttp();
        // init log service
        $this->log = new Log();
    }

    public function process()
    {
        // get job to do
        $job = $this->getJob();

        // check sources version
        if ($this->is($job->name, Workflow::class) || $this->is($job->name, Task::class) ) {
            return $this->processJob($job);
        }

        // if ($this->is($job->name, Workflow2::class) || $this->is($job->name, Task2::class) ) {
        //     return $this->processJob_v2($job);
        // }

        throw new ZenatonException('Unknown job type for "' . $job->name . '", you should probably update your Zenaton worker');
    }

    protected function processJob($job)
    {
        // set uuid and worker version for calls to microserver
        MicroServer::getInstance()->setUuid($job->uuid)->setWorkerVersion($job->worker_version);

        // inject processor in Zenaton library engine ;-)
        Engine::getInstance()->setProcessor(Processor::getInstance());

        // launch decider or worker
        switch ($job->action) {
            case 'DecisionScheduled':
                (new Decider($job->name))->launch();
                break;
            case 'TaskScheduled':
                (new Worker($job->name, $job->input, $job->hash))->process();
                break;
            default:
                throw new InternalZenatonException('Unknown action: ' . $job->action);
        }
    }

    // protected function processJob_v2($job)
    // {
    //     // set uuid and worker version for calls to microserver
    //     MicroServer2::getInstance()->setUuid($job->uuid)->setWorkerVersion($job->worker_version);
    //
    //     // inject processor in Zenaton library engine ;-)
    //     Engine2::getInstance()->setProcessor(Processor2::getInstance());
    //
    //     //
    //     switch ($job->action) {
    //         case 'DecisionScheduled':
    //             (new Decider2($job->name))->launch();
    //             break;
    //         case 'TaskScheduled':
    //             (new Worker2($job->name, $job->input, $job->hash))->process();
    //             break;
    //         default:
    //             throw new InternalZenatonException('Unknown action: ' . $job->action);
    //     }
    // }

    /*
     * Get job to perform
     */
    protected function getJob()
    {
        $response = $this->http->get($this->job);

        $this->log->info('INFRA - Ask Job - (get) ' . $this->job, ['response' => $response], Log::TYPE_INFRA);

        return $response;
    }
}
