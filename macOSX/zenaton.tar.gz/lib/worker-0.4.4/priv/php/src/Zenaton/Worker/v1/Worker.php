<?php

namespace Zenaton\Worker;

use Exception;

use Zenaton\Exceptions\ZenatonException;
use Zenaton\Interfaces\TaskInterface;
use Zenaton\Services\Serializer;
use Zenaton\Services\Properties;

use Zenaton\Services\Log;

class Worker
{
    protected $log;
    protected $microserver;
    protected $task;

    public function __construct($name, $input, $hash)
    {
        $this->microserver = MicroServer::getInstance()->setHash($hash);
        $input = (new Serializer())->decode($input);
        $this->task = (new Properties())->getObjectFromNameAndProperties(
            $name,
            $input,
            TaskInterface::class
        );
        (new Log())->info('TASK - Input - ' . $name, $input, Log::TYPE_TASK);
    }

    public function process()
    {
        // do task
        try {
            $output = $this->task->handle();
        } catch (ZenatonException $e) {
            $this->microserver->failWorker($e);
            $this->microserver->reset();
            throw $e;
        } catch (Exception $e) {
            // tell microserver we have an exception
            $this->microserver->failWork($e);
            $this->microserver->reset();
            throw $e;
        }

        // tell microserver we have the result
        $this->microserver->completeWork($output);
        $this->microserver->reset();
    }
}
