# frozen_string_literal: true

require_relative '../lib/zenaton/loader/loader'

loader = Zenaton::Loader::Loader.new(*ARGV)
loader.boot
loader.check_classes
