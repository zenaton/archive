package main

import (
	"os"

	"../Worker/v1"
	"../loader"
)

func main() {
	args := os.Args[1:]

	l, err := loader.NewLoader(args)
	checkError(err)

	job, err := l.GetJobURL(true)
	checkError(err)

	slave := loader.NewSlave(job)

	err = l.Success([]struct{}{})
	checkError(err)

	err = slave.Process()
	checkError(err)
}

func checkError(err error) {

	if err != nil {
		name := "unknownName"
		stack := "none"
		message := err.Error()
		ms := v1.NewMicroServer()
		if ms.IsWorking() {
			ms.FailWorker(name, message, stack)
		}
		if ms.IsDeciding() {
			ms.FailDecider(name, message, stack)
		}
		panic(err)
	}
}

//todo: make sure that this thing works whether the user has the client library vendored or not.
