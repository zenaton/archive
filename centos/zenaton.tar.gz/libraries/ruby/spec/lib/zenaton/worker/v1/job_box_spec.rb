# frozen_string_literal: true

require 'zenaton/worker/v1/job_box'
require 'app_dir/my_task'
require 'app_dir/workflow_1'

RSpec.describe Zenaton::Worker::V1::JobBox do
  let(:job_box) { described_class.new(job) }

  context 'when job is a task' do
    let(:job) { MyTask.new }

    it 'reports type to be a task' do
      expect(job_box.type).to eq('task')
    end

    it 'reports wait? to be false' do
      expect(job_box.wait?).to eq(false)
    end

    it 'reports task? to be true' do
      expect(job_box.task?).to eq(true)
    end

    it 'reports workflow? to be false' do
      expect(job_box.workflow?).to eq(false)
    end
  end

  context 'when job is a wait task' do
    let(:job) { Zenaton::Tasks::Wait.new }

    it 'reports type to be a task' do
      expect(job_box.type).to eq('wait')
    end

    it 'reports wait? to be true' do
      expect(job_box.wait?).to eq(true)
    end

    it 'reports task? to be true' do
      expect(job_box.task?).to eq(true)
    end

    it 'reports workflow? to be false' do
      expect(job_box.workflow?).to eq(false)
    end
  end

  context 'when job is a workflow' do
    let(:job) { Workflow1.new }

    it 'raises an error on type' do
      expect { job_box.type }.to raise_error Zenaton::InternalError
    end

    it 'reports wait? to be false' do
      expect(job_box.wait?).to eq(false)
    end

    it 'reports task? to be false' do
      expect(job_box.task?).to eq(false)
    end

    it 'reports workflow? to be true' do
      expect(job_box.workflow?).to eq(true)
    end
  end
end
