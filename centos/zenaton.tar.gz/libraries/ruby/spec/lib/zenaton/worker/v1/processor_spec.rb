# frozen_string_literal: true

require 'zenaton/worker/v1/processor'

RSpec.describe Zenaton::Worker::V1::Processor do
  let(:processor) { described_class.instance }

  describe 'initialization' do
    it 'is not newable' do
      expect { described_class.new }.to raise_error NoMethodError
    end

    it 'is a singleton class' do
      expect(processor).to eq(described_class.instance)
    end
  end
end
