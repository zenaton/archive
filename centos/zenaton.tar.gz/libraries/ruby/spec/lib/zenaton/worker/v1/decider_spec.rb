# frozen_string_literal: true

require 'zenaton/worker/v1/decider'

RSpec.describe Zenaton::Worker::V1::Decider do
  let(:decider) { described_class.new('my-flow') }

  it 'sets the workflow name' do
    expect(decider.instance_variable_get(:@flow).name).to \
      eq('my-flow')
  end
end
