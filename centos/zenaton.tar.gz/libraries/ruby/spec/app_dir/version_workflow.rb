# frozen_string_literal: true

require_relative './workflow_1'
require_relative './workflow_2'

class VersionWorkflow < Zenaton::Workflows::Version
  def versions
    [
      Workflow1,
      Workflow2
    ]
  end
end
