# frozen_string_literal: true

class Workflow2 < Zenaton::Interfaces::Workflow
  include Zenaton::Traits::Zenatonable

  def handle
    'result2'
  end
end
