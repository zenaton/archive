import json
import os
import re
import sys

import zenaton

from .class_checker import ClassChecker
from .loader_error import LoaderError
from ..services.sync_http import SyncHttp


class Loader:
    """Loads workflows on the worker"""

    PARAM_STATUS_URL = 'status'
    PARAM_BOOT_FILE = 'boot'
    PARAM_APP_DIR = 'app'
    PARAM_FRAMEWORK_NAME = 'framework'
    PARAM_CLASSES = 'classes'
    PARAM_JOB_URL = 'job'
    FRAMEWORK_RAILS = 'rails'

    def __init__(self, *params):
        """parse the received params into @args"""
        self.args = self.__parse_params(params)
        """url that will be called to provide status"""
        self.status = self.status_url()
        """user app directory"""
        self.app_dir = self.app_dir()
        """make sure the execution path of python is the app directory"""
        os.chdir(self.app_dir)
        """store this in environment (used by log)"""
        os.environ['ZENATON_APP_DIR'] = self.app_dir
        """init http service"""
        self.http = SyncHttp()
        """get framework, if any"""
        self.framework = self.framework(False)

    def boot(self):
        sys.path.append(os.getcwd())
        message = 'Unable to load zenaton library - please add it to your Gemfile, and run bundle install'
        try:
            return zenaton.__version__
        except NameError:
            raise Exception(message)


    """ Get provided class parameters """
    def check_classes(self):
        checker = ClassChecker()
        provided_classes = self.classes()
        handle_only = provided_classes['handle_only'] and checker.check(provided_classes[['handle_only']])
        handle_except = provided_classes['handle_except'] and checker.check(provided_classes[['handle_except']])
        self.success(data={'handle_only': handle_only, 'handle_except': handle_except})

    """ Path of boot file """
    def boot_file_path(self, mandatory=True):
        path = self.__arg(self.PARAM_BOOT_FILE, mandatory)
        self.__check_file(path)
        return path

    """
        Get status url parameter from args
        This parameter is handled a bit differently than others
        as you can not post error before having a value
    """
    def status_url(self, mandatory=True):
        url = self.__arg(self.PARAM_STATUS_URL, mandatory)
        if mandatory and url is None:
            raise LoaderError('Missing {} parameter'.format(self.PARAM_STATUS_URL))
        if not (url is None or self.__check_url(url)):
            raise LoaderError('Incorrect {} parameter'.format(self.PARAM_STATUS_URL))
        return url

    """Get job retrieval url parameter from argv"""
    def job_url(self, mandatory=True):
        url = self.__arg(self.PARAM_JOB_URL, mandatory)
        if (mandatory or url is not None) and not self.__check_url(url):
            self.failure("Incorrect {} parameter".format(self.PARAM_JOB_URL))
        return url

    """Get framework name, if any"""
    def framework(self, mandatory=True):
        return self.__arg(self.PARAM_FRAMEWORK_NAME, mandatory)

    """Get path of user application directory"""
    def app_dir(self, mandatory=True):
        dir = self.__arg(self.PARAM_APP_DIR, mandatory).strip("/")
        dir = '/' + dir + '/'
        self.__check_dir(dir)
        return dir

    """Get provided classes from argv"""
    def classes(self, mandatory=True):
        json_data = self.__arg(self.PARAM_CLASSES, mandatory)
        try:
            return json.loads(json_data)
        except json.JSONDecodeError:
            self.failure('Provided classes parameter {} is invalid json'.format(json_data))

    """Send success to microserver"""
    def success(self, data={}):
        self.__post({'status': 'ok', 'data': data})

    """Send failure to microserver"""
    def failure(self, message):
        self.__post({'error': message})
        raise LoaderError

    """Get provided parameter"""
    def __arg(self, param_type, mandatory=True):
        try:
            return self.args[param_type]
        except KeyError:
            if mandatory:
                self.failure('Missing {} parameter'.format(param_type))

    """Post response to micro-server"""
    def __post(self, body):
        try:
            self.http.post(self.status, body)
        except:
            raise LoaderError('({}) - post request failed for {}'.format(self.status, json.dumps(body)))

    """Parse the received params string"""
    def __parse_params(self, params_list):
        output = []
        for key_value in params_list:
            if key_value.find('=') > 0:
                output.append(key_value.split('='))
            else:
                output.append([key_value, None])
        return dict(output)

    """Check accessible file"""
    def __check_file(self, path):
        if not os.path.isfile(path):
            self.failure('"{}" is not a file'.format(path))
        try:
            open(path)
        except (IOError, FileNotFoundError):
            self.failure('Can not read "{}" file'.format(path))

    """Check accessible directory"""
    def __check_dir(self, path):
        if not os.path.isdir(path):
            self.failure('"{}" is not a directory'.format(path))
        if not os.access(path, os.R_OK):
            self.failure('Can not read "{}" directory'.format(path))

    """Check url validity"""
    def __check_url(self, url):
        # https://github.com/nescalante/urlregex
        ip = '(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}'
        protocol = '(?:http(s?)\:\/\/)?'
        auth = '(?:\\S+(?::\\S*)?@)?'
        host = '(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)'
        domain = '(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*'
        tld = '(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?'
        port = '(?::\\d{2,5})?'
        path = '(?:[/?#][^\\s"]*)?'
        regex = '(?:' + protocol + '|www\\.)' + auth + '(?:localhost|' + ip + '|' + host + domain + tld + ')' + port + path
        return bool(re.match(regex, url))
