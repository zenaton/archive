/* global process */

const LoaderError = require('./Errors/LoaderError')
const SyncHttp = require('../Services/SyncHttp')
const ClassChecker = require('./ClassChecker')
const fs = require('fs')

const PARAM_STATUS_URL = 'status'
const PARAM_BOOT_FILE = 'boot'
const PARAM_APP_DIR = 'app'
const PARAM_FRAMEWORK_NAME = 'framework'
const PARAM_CLASSES = 'classes'
const PARAM_JOB_URL = 'job'

module.exports = class {

	constructor(args) {
		// parse args into this.args
		this.args = {}
		let tmp, key, value
		args.forEach( param => {
			tmp = param.split('=')
			key = tmp[0]
			value = (tmp.length < 2) ? '' : tmp[1]
			this.args[key] = value
		})
		// init http service
		this.http = new SyncHttp()
		// provided url
		this.status = this.getStatusUrl()
		// get framework, if any
		this.framework = this.getFramework(false)
		// app directory
		this.appDir = this.getAppDir()
		// make sure the execution path of node is the app directory
		process.chdir(this.appDir)
		// store this in environnement (used by Log)
		process.env.ZENATON_APP_DIR = this.appDir
	}

	/*
     * boot autoload file
     */
	boot() {
		let boot = this.getBootFilePath()

		// load autoload file
		require(boot)

		// check if public Zenaton libray is now known
		if (undefined === process.env.ZENATON_LIBRARY_PATH) {
			this.failure('Unable to load Zenaton library - please add it to your package.json, and run npm install')
		}
	}

	/*
     * Get provided classes parameter
     */
	checkClasses() {
		let checker = new ClassChecker()

		let classes = this.getClasses()
		let handleOnly = classes.handle_only  ? checker.check(classes.handle_only) :  null
		let handleExcept = classes.handle_except ? checker.check(classes.handle_except) :  null

		this.success({
			handle_only: handleOnly,
			handle_except: handleExcept
		})
	}

	/*
     * path of boot file
     */
	getBootFilePath(mandatory = true) {
		let boot = this.arg(PARAM_BOOT_FILE, mandatory)

		this.checkFile(boot)

		return boot
	}

	/*
     * Get status url parameter from argv
     * This parameter is handled a bit differently than others
     * as you can not post error before having a velue
     */
	getStatusUrl(mandatory = true) {
		let url = this.arg(PARAM_STATUS_URL, mandatory)

		if (mandatory && undefined === url) {
			throw new LoaderError('Missing \'' + PARAM_STATUS_URL + '\' parameter')
		}

		if (! this.checkUrl(url)) {
			throw new LoaderError('\'' + url + '\' is an invalid url')
		}

		return url
	}

	/*
     * Get job retrieval url parameter from argv
     */
	getJobUrl(mandatory = true) {
		let url = this.arg(PARAM_JOB_URL, mandatory)

		if ((mandatory || undefined !== url) && ! this.checkUrl(url)) {
			this.failure('\'' + url + '\' is an invalid url')
		}

		return url
	}

	/*
     * Get provided envId
     */
	getClasses(mandatory = true) {
		let json = this.arg(PARAM_CLASSES, mandatory)

		try {
			return JSON.parse(json)
		} catch (e) {
			this.failure('Provided \'' + PARAM_CLASSES + '\' parameter \'' + json + '\' is invalid json')
		}
	}

	/*
     * Get framework name, if any
     */
	getFramework(mandatory = true) {
		let framework = this.arg(PARAM_FRAMEWORK_NAME, mandatory)

		// optional parameter
		if (undefined !== framework) {
			this.failure(framework + ' is not a supported framework')
		}

		return framework
	}

	/*
     * Get path of user application directory
     */
	getAppDir(mandatory = true) {
		let dir = this.arg(PARAM_APP_DIR, mandatory).replace(/\/$/, '')

		this.checkDir(dir)

		return dir
	}

	/*
     * Get provided parameter
     */
	arg(type, mandatory = true)
	{
		let arg = this.args[type]

		if (undefined === arg && mandatory) {
			this.failure('Missing \'' + type + '\' parameter')
		}

		return arg
	}

	/*
     * Send success to microserver
     */
	success(data = []) {
		this.post({status: 'ok', data: data})
	}

	/*
     * Send failure to microserver
     */
	failure(msg = '') {
		this.post({error: msg})
		// always stop here
		throw new LoaderError()
	}

	/*
     * Post response to micro-server
     */
	post(body) {
		try {
			this.http.post(this.status, body)
		} catch (e) {
			let error = new LoaderError(e.message)
			error.stack = e.stack
			throw error
		}
	}

	/*
     * Check accessible file
     */
	checkFile(file) {
		try {
			fs.statSync(file).isFile()
		} catch (e) {
			this.failure('\'' + file + '\' is not a file')
		}
		try {
			fs.accessSync(file, fs.constants.R_OK)
		} catch (e) {
			this.failure('Can not read \'' + file + '\' file')
		}
	}

	/*
     * Check accessible directory
     */
	checkDir(dir) {
		try {
			fs.statSync(dir).isDirectory()
		} catch (e) {
			this.failure('\'' + dir + '\' is not a directory')
		}
		try {
			fs.accessSync(dir, fs.constants.R_OK)
		} catch (e) {
			this.failure('Can not read \'' + dir + '\' directory')
		}
	}

	/*
     * Check url validity
     */
	checkUrl(url) {
		// https://github.com/nescalante/urlregex
		let ip = '(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}'
		let protocol = '(?:http(s?)\:\/\/)?'
		let auth = '(?:\\S+(?::\\S*)?@)?'
		let host = '(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)'
		let domain = '(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*'
		let tld = '(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?'
		let port = '(?::\\d{2,5})?'
		let path = '(?:[/?#][^\\s"]*)?'
		let regex = '(?:' + protocol + '|www\\.)' + auth + '(?:localhost|' + ip + '|' + host + domain + tld + ')' + port + path

		return new RegExp('(?:^' + regex + '$)', 'i').test(url)
	}
}
