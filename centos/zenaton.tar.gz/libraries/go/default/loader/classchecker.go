package loader

import (
	"strings"

	"../services/zenaton"
)

//ClassChecker checks that the agent can import the workflows and tasks defined by the user
type ClassChecker struct{}

//NewClassChecker returns a ClassChecker instance
func NewClassChecker() *ClassChecker {
	return &ClassChecker{}
}

type Class struct {
	Tasks     []string `json:"tasks"`
	Workflows []string `json:"workflows"`
	Undefined []string `json:"undefined"`
}

func (cc *ClassChecker) check(classes string) *Class {
	var workflows []string
	var tasks []string
	var unknown []string

	// at this stage, Zenaton should be loaded

	classesSlice := strings.Split(strings.TrimSpace(classes), ",")
	for _, c := range classesSlice {
		if zenaton.TaskManager.GetDefinition(c) != nil {
			tasks = append(tasks, c)
		} else if zenaton.WorkflowManager.GetDefinition(c) != nil {
			workflows = append(workflows, c)
		} else {
			unknown = append(unknown, c)
		}
	}

	return &Class{
		Tasks:     tasks,
		Workflows: workflows,
		Undefined: unknown,
	}
}
