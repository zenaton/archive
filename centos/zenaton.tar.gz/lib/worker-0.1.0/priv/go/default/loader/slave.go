package loader

import (
	"../Worker/v1"
	"../services/log"
	"../services/synchttp"
	"../services/zenaton"
)

const (
	decisionScheduled = "DecisionScheduled"
	taskScheduled     = "TaskScheduled"
)

type Slave struct {
	job string
	//todo: should just use syncHTTP directly?
}

func NewSlave(job string) *Slave {
	return &Slave{
		job: job,
	}
}

func (s *Slave) Process() error {
	// get job to do
	job, err := s.getJob()
	if err != nil {
		return err
	}

	//fmt.Printf("job %+v\n\n", job)

	if s.isWorkflow(job.Name) || s.isTask(job.Name) {
		return s.processJob(job)
	}

	return zenaton.Errors.New(zenaton.Errors.ExternalZenatonError,
		`Unknown "`+job.Name+`", probably missing in your --boot file`)
}

type Job struct {
	UUID                string `json:"uuid"`
	WorkerVersion       string `json:"worker_version"`
	Action              string `json:"action"`
	Name                string `json:"name"`
	InstanceID          int    `json:"instance_id"`
	Input               string `json:"input"`
	Hash                string `json:"hash"`
	ProgrammingLanguage string `json:"programming_language"`
}

func (s *Slave) processJob(j Job) error {
	// set uuid and worker version for calls to microserver
	v1.NewMicroServer().SetUUID(j.UUID).SetWorkerVersion(j.WorkerVersion)

	zenaton.Engine.SetProcessor(v1.NewProcessor())

	// launch decider or worker
	switch j.Action {
	case decisionScheduled:

		err := v1.NewDecider(j.Name).Launch()
		if err != nil {
			return err
		}

	case taskScheduled:

		err := v1.NewWorker(j.Name, j.Input, j.Hash).Process()
		if err != nil {
			return err
		}

	default:
		return zenaton.Errors.New(zenaton.Errors.InternalZenatonError, "Error - unknown action: "+j.Action)
	}
	return nil
}

func (s *Slave) getJob() (Job, error) {
	var j Job

	err := synchttp.Get(s.job, &j)

	if err != nil {
		return Job{}, err
	}

	log.Info("INFRA - Ask Job - (get) "+s.job+" response: ", j, log.TypeInfra)

	return j, nil
}

func (s *Slave) isWorkflow(name string) bool {
	return zenaton.WorkflowManager.GetDefinition(name) != nil
}

func (s *Slave) isTask(name string) bool {
	return zenaton.TaskManager.GetDefinition(name) != nil
}
