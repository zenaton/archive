# frozen_string_literal: true

require 'singleton'
require_relative './position'

module Zenaton
  module Worker
    module V1
      class Workflow
        include Singleton

        attr_accessor :name

        def init(branch, properties)
          @flow = build_workflow(properties)
          @branch = branch
          @position.init
        end

        def run_branch
          case @branch['type']
          when 'handle'
            @flow.handle
          when 'onEvent'
            if @flow.respond_to?(:on_event)
              event = @properties.object_from(
                @branch['data']['event_name'],
                @serializer.decode(@branch['data']['event_input']),
                Zenaton::Interfaces::Event
              )
              @flow.on_event(event)
            end
          when 'onStart'
            if @flow.respond_to?(:on_start)
              task = @properties.object_from(
                @branch['data']['task_name'],
                @serializer.decode(@branch['data']['task_input']),
                Zenaton::Interfaces::Task
              )
              @flow.on_start(task)
            end
          when 'onSuccess'
            if @flow.respond_to?(:on_success)
              task = @properties.object_from(
                @branch['data']['task_name'],
                @serializer.decode(@branch['data']['task_input']),
                Zenaton::Interfaces::Task
              )
              output = @serializer.decode(@branch['data']['task_output']) unless task.is_a? Zenaton::Tasks::Wait
              @flow.on_success(task, output)
            end
          when 'onFailure'
            if @flow.respond_to?(:on_failure)
              task = @properties.object_from(
                @branch['data']['task_name'],
                @serializer.decode(@branch['data']['task_input']),
                Zenaton::Interfaces::Task
              )
              error = @properties.object_from(
                @branch['data']['error_name'],
                @serializer.decode(@branch['data']['error_input']),
                StandardError
              )
              @flow.on_failure(task, error)
            end
          when 'onTimeout'
            if @flow.respond_to?(:on_timeout)
              task = @properties.object_from(
                @branch['data']['task_name'],
                @serializer.decode(@branch['data']['task_input']),
                Zenaton::Interfaces::Task
              )
              @flow.on_timeout(task)
            end
          end
        end

        def get_position
          @position.get
        end

        def next
          @position.next
        end

        def next_async
          @position.next_async
        end

        def next_parallel
          @position.next_parallel
        end

        def read_properties
          @properties.from(@flow)
        end

        def write_properties(properties)
          @properties.set(@flow, properties)
        end

        private

        def initialize
          @serializer = Services::Serializer.new
          @properties = Services::Properties.new
          @position = Position.new
        end

        def build_workflow(properties)
          version = @properties.blank_instance(@name)
          @name = version.initial.to_s if version.is_a?(Zenaton::Workflows::Version)
          @properties.object_from(
            @name,
            @serializer.decode(properties),
            Zenaton::Interfaces::Workflow
          )
        end
      end
    end
  end
end
