<?php

$output = [
    'php' => [
        'version' => PHP_VERSION,
        'env' => $_ENV,
    ],
];

echo json_encode($output);
