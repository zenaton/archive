<?php

namespace Zenaton\Loader;

use Zenaton\Services\Is;

use Zenaton\Interfaces\TaskInterface as Task;
use Zenaton\Interfaces\WorkflowInterface as Workflow;
use Zenaton\v2\Interfaces\TaskInterface as Task2;
use Zenaton\v2\Interfaces\WorkflowInterface as Workflow2;


class ClassChecker
{
    use Is;

    public function check($classes)
    {
        $tasks = [];
        $workflows = [];
        $undefined = [];
        $classes = array_map('trim', explode(',', $classes));

        foreach ($classes as $class) {
            if ($this->is($class, Workflow::class) || $this->is($class, Workflow2::class)) {
                $workflows[] = $class;
            } elseif ($this->is($class, Task::class) || $this->is($class, Task2::class)) {
                $tasks[] = $class;
            } else {
                $undefined[] = $class;
            }
        }

        return [
            'tasks' => $tasks,
            'workflows' => $workflows,
            'undefined' => $undefined
        ];
    }
}
