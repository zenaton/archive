<?php

namespace Zenaton\Services\Library;

/**
 * Represents a version of the Zenaton library.
 */
interface Version
{
    /**
     * Returns whether this version object is greater than or equal to the given version or not.
     *
     * @param int $version A version id to check (e.g. 00200)
     *
     * @return bool
     */
    public function gte($version);
}
