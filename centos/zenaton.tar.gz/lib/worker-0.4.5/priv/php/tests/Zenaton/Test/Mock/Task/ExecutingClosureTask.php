<?php

namespace Zenaton\Test\Mock\Task;

use Zenaton\Interfaces\TaskInterface;

class ExecutingClosureTask implements TaskInterface
{
    private $closure;

    public function __construct(\Closure $closure)
    {
        $this->closure = $closure;
    }

    public function handle()
    {
        $closure = $this->closure;

        return $closure();
    }
}
