<?php

namespace Zenaton\Test\Mock\Workflow;

use Zenaton\Interfaces\WorkflowInterface;

class NullWorkflow implements WorkflowInterface
{
    public function handle()
    {
    }
}
