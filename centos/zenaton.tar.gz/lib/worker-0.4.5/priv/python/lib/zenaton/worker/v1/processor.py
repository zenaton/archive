from zenaton.abstracts.task import Task
from zenaton.abstracts.workflow import Workflow
from zenaton.client import Client
from zenaton.singleton import Singleton

from .job_box import JobBox
from .microserver import Microserver
from .workflow import Workflow
from ...worker_exceptions import ScheduledBox, ModifiedDecider


class Processor(metaclass=Singleton):
    STATUS_MODIFIED = 'modified'
    STATUS_SCHEDULED = 'scheduled'
    STATUS_COMPLETED = 'completed'

    def __init__(self):
        self.microserver = Microserver()
        self.flow = Workflow()

    def process(self, boxes, sync):
        if self.microserver.is_working():
            return self.__process_from_task(boxes, sync)
        if self.microserver.is_deciding():
            return self.__process_from_workflow(boxes, sync)
        raise Exception('process: Unknown state')

    """Returns array of results"""
    def __process_from_task(self, boxes, sync):
        client = Client()
        """handle sync executions and dispatch async"""
        for box in boxes:
            if issubclass(type(box), Workflow):
                if sync:
                    return box.handle()
                else:
                    client.start_workflow(box)
                    return None
            elif issubclass(type(box), Task):
                if sync:
                    return box.handle()
                else:
                    box.handle()
                    return None
            else:
                if sync:
                    return box.handle()
                else:
                    client.start_workflow(box)
                    return None
                # TO DO
                # raise Exception('processFromTask: Unknown type')


    def __process_from_workflow(self, boxes, sync):

        dboxes = self.__decorate_boxes(boxes, sync)

        """Schedule task or get result if already done"""
        response = self.microserver.execute(dboxes)
        status = response['status']

        """Decider was modified"""
        if status == self.STATUS_MODIFIED:
            self.__raise_modified()

        """Nothing more to do for synchronous execution"""
        if not sync:
            return [None] * len(boxes)
        if status == self.STATUS_SCHEDULED:
            raise ScheduledBox
        if status == self.STATUS_COMPLETED:
            return self.__output_with_properties(response)
        raise Exception('InputBox with Unknown status at position: {}'.format(self.flow.get_position()))

    """Construct array of decorated boxes"""
    def __decorate_boxes(self, boxes, sync):
        dboxes = []
        for box in boxes:
            self.__increment_postion(boxes, sync)
            job_box = JobBox(box)
            job_box.sync = sync
            job_box.position = self.flow.get_position()
            dboxes.append(job_box)
        return dboxes

    def __increment_postion(self, boxes, sync):
        if not sync:
            self.flow.next_async()
        elif len(boxes) > 1:
            self.flow.next_parallel()
        else:
            self.flow.next()

    def __raise_modified(self):
        error = "{} has been modified since launch of current instance" \
                "You can't. Seriously." \
                "See https://zenaton.com/documentation#workflow-versioning-for-running-instances".format(self.flow.name)
        raise ModifiedDecider(error)

    def __output_with_properties(self, response):
        self.flow.write_properties(response['properties'])
        return response['outputs']
