import zenaton

from .microserver import Microserver
from ...services.importer import Importer
from ...services.log import Log


class Worker:

    def __init__(self, name, boot, input, custom_hash):
        self.microserver = Microserver()
        self.microserver.custom_hash = custom_hash
        # input = zenaton.services.serializer.Serializer().decode(input)
        # task_input = json.loads(input)['s'][0]['a']
        task_input = zenaton.services.serializer.Serializer().decode(input)
        self.task = Importer(boot).import_task(name)(**task_input)
        Log().info(
            'TASK - Input - {}'.format(name),
            input,
            Log().TYPE_TASK
        )

    def process(self):
        try:
            output = self.task.handle()
        except zenaton.exceptions.Error as err:
            self.microserver.fail_worker(err)
            self.microserver.reset()
            raise err
        except Exception as err:
            self.microserver.fail_work(err)
            self.microserver.reset()
            raise err
        self.microserver.complete_work(output)
        self.microserver.reset()
