class LoaderError(Exception):
    pass
