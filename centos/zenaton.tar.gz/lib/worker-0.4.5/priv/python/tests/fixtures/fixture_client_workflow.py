import pytest

from zenaton.abstracts.workflow import Workflow
from zenaton.traits.zenatonable import Zenatonable


class WorkflowWithCallbacks(Workflow, Zenatonable):

    def handle(self):
        pass

    def on_start(self, task):
        pass

    def on_event(self, event):
        pass


class WorkflowWithWrongCallbacks(Workflow, Zenatonable):

    def handle(self):
        pass

    def on_stat(self, task):
        pass


class WorkflowWithoutCallbacks(Workflow, Zenatonable):

    def handle(self):
        pass


@pytest.fixture
def workflow_with_callbacks():
    return WorkflowWithCallbacks()

@pytest.fixture
def workflow_with_wrong_callbacks():
    return WorkflowWithWrongCallbacks()

@pytest.fixture
def workflow_without_callbacks():
    return WorkflowWithoutCallbacks()
