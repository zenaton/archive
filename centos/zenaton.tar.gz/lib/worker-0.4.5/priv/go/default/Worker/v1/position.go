package v1

import (
	"strconv"
	"strings"
)

const (
	SEPARATOR_ASYNC    = "a"
	SEPARATOR_PARALLEL = "p"
)

type Position struct {
	main     int
	counter  int
	position string
}

func NewPosition() *Position {
	return &Position{
		position: "0",
	}
}

func (p *Position) init() {
	p.main = 0
	p.counter = 0
	p.position = "0"
}

func (p *Position) get() string {
	return p.position
}

func (p *Position) next() {
	p.main++
	p.position = strconv.Itoa(p.main)
}

func (p *Position) nextParallel() {
	if p.isInParallel() {
		p.counter++
	} else {
		p.main++
		p.counter = 0
	}
	p.position = strconv.Itoa(p.main) + SEPARATOR_PARALLEL + strconv.Itoa(p.counter)
}

func (p *Position) nextAsync() {
	p.main++
	p.position = strconv.Itoa(p.main) + SEPARATOR_ASYNC
}

func (p *Position) isInParallel() bool {
	return strings.Contains(p.position, SEPARATOR_PARALLEL)
}
