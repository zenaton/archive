package v1

import (
	"fmt"

	"../../services/zenaton"
)

const (
	STATUS_MODIFIED  = "modified"
	STATUS_SCHEDULED = "scheduled"
	STATUS_COMPLETED = "completed"
)

type Processor struct {
	microserver *MicroServer
	flow        *Workflow
}

func NewProcessor() zenaton.Processor {
	return &Processor{
		microserver: NewMicroServer(),
		flow:        NewWorkflow(),
	}
}

func (p *Processor) Process(boxes []zenaton.Job, isSync bool) ([]interface{}, []string, []error) {

	if p.microserver.IsWorking() {
		outputs, errs := p.processFromTask(boxes, isSync)
		return outputs, nil, errs
	}

	if p.microserver.IsDeciding() {
		serializedCombinedOutputs := p.processFromWorkflow(boxes, isSync)
		return nil, serializedCombinedOutputs, nil
	}

	// here we panic, as we want to stop the execution of the workflow
	panic(zenaton.Errors.New("InternalZenatonError", "process: Unknown state"))
}

func (p *Processor) processFromTask(boxes []zenaton.Job, isSync bool) ([]interface{}, []error) {

	var outputs []interface{}
	var errs []error

	client := zenaton.Client

	for _, box := range boxes {

		var out interface{}
		var err error

		switch job := box.(type) {
		case *zenaton.Workflow:
			if isSync {
				out, err = job.Handle()
			} else {
				client.StartWorkflow(job.GetName(), job.GetCanonical(), job.GetCustomID(), job.GetData())
			}
		case *zenaton.Task:

			out, err = job.Handle()

		default:
			//throw new InternalZenatonError("processFromTask: Unknown type")
			panic(fmt.Sprintf("processFromTask: Unknown type: %+v", job))
		}

		errs = append(errs, err)
		outputs = append(outputs, out)
	}

	return outputs, errs
}

func (p *Processor) processFromWorkflow(boxes []zenaton.Job, isSync bool) []string {
	// construct array of decorated boxes
	var dboxes []*JobBox
	for _, box := range boxes {
		// Go to the next position
		if !isSync {
			p.flow.nextAsync()
		} else if len(boxes) > 1 {
			p.flow.nextParallel()
		} else {
			p.flow.next()
		}

		dboxes = append(dboxes, NewJobBox(box).setSync(isSync).setPosition(p.flow.getPosition()))
	}

	// schedule task or get result if already done
	response := p.microserver.execute(dboxes)

	// Decider was modified
	if response.Status == STATUS_MODIFIED {
		panic(fmt.Sprint(`"`, p.flow.name, `" has been modified since launch of current instance.`, "\nYou can't. Seriously.\nSee https://zenaton.com/documentation#workflow-versioning-for-running-instances"))
		//throw new ModifiedDeciderError(`"` + p.flow.name + `" has been modified since launch of current instance.` + `\nYou can't. Seriously.\nSee https://zenaton.com/documentation#workflow-versioning-for-running-instances`)
	}

	// Nothing more to do for asynchronous execution
	if !isSync {
		// return an array full of undefined
		return nil
	}

	if response.Status == STATUS_SCHEDULED {
		panic(zenaton.Errors.ScheduledBoxError)
		//return nil, zenaton.Errors.New(zenaton.Errors.ScheduledBoxError, "")
	}

	if response.Status == STATUS_COMPLETED {
		err := p.flow.setProperties(response.Properties)
		if err != nil {
			panic(err)
		}
		return response.Outputs
	}

	//throw new InternalZenatonError("processFromWorkflow: InputBox with Unknown status at position ".p.flow.getPosition())
	panic("processFromWorkflow: InputBox with Unknown status at position " + p.flow.getPosition())
}
