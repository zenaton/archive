<?php

namespace Zenaton\Test\Mock\Task;

use Zenaton\Interfaces\TaskInterface;

class WrongAutomaticRetryTask implements TaskInterface
{
    public function handle()
    {
        throw new \RuntimeException("I'm always failing!");
    }

    public function onErrorRetryDelay()
    {
        return "I cannot be retried";
    }
}
