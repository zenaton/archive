# frozen_string_literal: true

require_relative './microserver'
require_relative '../../services/log'
require_relative '../../worker_exceptions'

module Zenaton
  module Worker
    module V1
      class Worker
        def initialize(job)
          @serializer = Services::Serializer.new
          @properties = Services::Properties.new
          @extra = {}

          id, name, custom_hash, retry_index = \
            job.values_at('intent_id', 'name', 'hash', 'retry_index')
          input = @serializer.decode(job['input'])

          @microserver = setup_microserver(custom_hash)
          @task = setup_task(name, input, id, retry_index)

          log_input(name, input)
        end

        def process
          output = @task.handle
          @microserver.complete_work(output)
        rescue Zenaton::Error => e
          @microserver.fail_worker(e, @extra)
          raise e
        rescue StandardError => e
          begin
            setup_retry_delay(e)
          rescue StandardError => error_from_on_error_retry_delay
            e = error_from_on_error_retry_delay
          end
          @microserver.fail_work(e, @extra)
          raise e
        ensure
          @microserver.reset
        end

        private

        def setup_microserver(custom_hash)
          Microserver.instance.tap do |microserver|
            microserver.custom_hash = custom_hash
          end
        end

        def setup_task(name, input, id, retry_index)
          @properties.object_from(name, input, Zenaton::Interfaces::Task).tap do |task|
            task.add_context(id: id, retry_index: retry_index) if task.respond_to?(:add_context)
          end
        end

        def log_input(name, input)
          Zenaton::Services::Log.new.info(
            "TASK - Input - #{name}",
            input,
            Zenaton::Services::Log::TYPE_TASK
          )
        end

        def setup_retry_delay(error)
          delay = @task.try { on_error_retry_delay(error) }
          # Falsy values are treated as non repeatable
          return unless delay

          # Positive (including 0) numerics are treated as the delay for the retry
          return @extra[:retry] = { delay: delay } if delay.try(:zero?) || delay.try(:positive?)

          # In all other cases inform the user of an incorrect return type
          message = <<~ERROR
            Unexpected return value of the `on_error_retry_delay' method.
            The method is expected to return a numeric type greater than or
            equal to `0`, representing the seconds to wait before automatically
            retrying the task. If the task must not be automatically retried,
            the method is expected to return a falsy value.
          ERROR
          raise TypeError, message
        end
      end
    end
  end
end
