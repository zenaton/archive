<?php

namespace Zenaton\Exceptions;

class ScheduledBoxException extends InternalZenatonException
{
}
