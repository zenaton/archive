<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Ramsey\Uuid\Uuid;
use Ramsey\Uuid\UuidFactoryInterface;
use Zenaton\Exceptions\InternalZenatonException;
use Zenaton\Tasks\Wait;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\Mock\Workflow\NullWorkflow;

class JobBoxTest extends TestCase
{
    public function tearDown()
    {
        JobBox::resetUuidFactory();
    }

    public function testGetJobWithUserDefinedTaskWithSyncAndPositionSetBeforeLib0_4()
    {
        $uuidFactory = $this->createMock(UuidFactoryInterface::class);
        $uuidFactory
            ->method('uuid4')
            ->willReturnCallback(function () {
                return Uuid::fromString('b7b0ff6d-02c1-4932-b01f-d300c84c7649');
            })
        ;
        JobBox::setUuidFactory($uuidFactory);

        $jobBox = new JobBox(new SimpleReturnValueTask(42), true, '1');
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '1',
            'sync' => true,
            'name' => SimpleReturnValueTask::class,
            'input' => '{"a":{"value":42},"s":[]}',
            'type' => 'task',
            'maxProcessingTime' => null,
            'intent_id' => 'b7b0ff6d-02c1-4932-b01f-d300c84c7649',
        ], $job);
    }

    public function testGetJobWithUserDefinedTaskWithSyncAndPositionSetAfterLib0_4()
    {
        $uuidFactory = $this->createMock(UuidFactoryInterface::class);
        $uuidFactory
            ->method('uuid4')
            ->willReturnCallback(function () {
                return Uuid::fromString('78221e40-e278-4b8e-9dad-5539b7731715');
            })
        ;
        JobBox::setUuidFactory($uuidFactory);

        $jobBox = new JobBox(new SimpleReturnValueTask(42), true, '1');
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '1',
            'sync' => true,
            'name' => SimpleReturnValueTask::class,
            'input' => '{"a":{"value":42},"s":[]}',
            'type' => 'task',
            'maxProcessingTime' => null,
            'intent_id' => '78221e40-e278-4b8e-9dad-5539b7731715',
        ], $job);
    }

    public function testGetJobWithAWorkflow()
    {
        $this->expectException(InternalZenatonException::class);

        $jobBox = new JobBox(new NullWorkflow(), true, '1');
        $jobBox->getJob();
    }

    public function testGetJobWithUnconfiguredWaitTask()
    {
        $uuidFactory = $this->createMock(UuidFactoryInterface::class);
        $uuidFactory
            ->method('uuid4')
            ->willReturnCallback(function () {
                return Uuid::fromString('25545e91-2cd0-4d5f-8f69-4b83f716d860');
            })
        ;
        JobBox::setUuidFactory($uuidFactory);

        $jobBox = new JobBox(new Wait(), true, '1');
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '1',
            'sync' => true,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":null},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => null,
            'duration' => null,
            'intent_id' => '25545e91-2cd0-4d5f-8f69-4b83f716d860',
        ], $job);
    }

    public function testGetJobWithWaitTaskWaitingForATimestamp()
    {
        $uuidFactory = $this->createMock(UuidFactoryInterface::class);
        $uuidFactory
            ->method('uuid4')
            ->willReturnCallback(function () {
                return Uuid::fromString('af0db96b-9365-4276-af5e-967d43432caf');
            })
        ;
        JobBox::setUuidFactory($uuidFactory);

        $timestamp = time() + 3600;
        $jobBox = new JobBox((new Wait())->timestamp($timestamp), true, '2');
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '2',
            'sync' => true,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":[["timestamp",'.$timestamp.']]},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => $timestamp,
            'duration' => null,
            'intent_id' => 'af0db96b-9365-4276-af5e-967d43432caf',
        ], $job);
    }

    public function testGetJobWithWaitTaskWaitingForADuration()
    {
        $uuidFactory = $this->createMock(UuidFactoryInterface::class);
        $uuidFactory
            ->method('uuid4')
            ->willReturnCallback(function () {
                return Uuid::fromString('fa3fa846-25a9-48be-9116-923d6aa7293f');
            })
        ;
        JobBox::setUuidFactory($uuidFactory);

        $jobBox = new JobBox((new Wait())->hours(1), true, '2');
        $job = $jobBox->getJob();

        static::assertEquals([
            'position' => '2',
            'sync' => true,
            'name' => Wait::class,
            'input' => '{"a":{"event":null,"_buffer":[["hours",1]]},"s":[]}',
            'type' => 'wait',
            'maxProcessingTime' => null,
            'event' => null,
            'timestamp' => null,
            'duration' => 3600,
            'intent_id' => 'fa3fa846-25a9-48be-9116-923d6aa7293f',
        ], $job);
    }
}
