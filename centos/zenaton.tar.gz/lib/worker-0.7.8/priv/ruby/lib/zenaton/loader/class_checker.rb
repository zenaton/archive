# frozen_string_literal: true

module Zenaton
  module Loader
    # Checks if given classes are workflows or tasks
    class ClassChecker
      # @param classes [String] comma separated list of class names
      def check(classes)
        tasks = []
        workflows = []
        undefined = []
        classes.split(',').each do |class_name|
          klass = Object.const_get(class_name.strip)
          load_class(klass, tasks, workflows, undefined)
        end
        { tasks: tasks, workflows: workflows, undefined: undefined }
      end

      private

      def load_class(klass, tasks, workflows, undefined)
        if klass < Zenaton::Interfaces::Workflow
          workflows << klass
        elsif klass < Zenaton::Interfaces::Task
          tasks << klass
        else
          undefined << klass
        end
      end
    end
  end
end
