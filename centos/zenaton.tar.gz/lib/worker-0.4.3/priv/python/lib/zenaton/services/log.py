import os

class Log:
    """Module for appending messages to the zenaton.log file"""

    TYPE_NONE = ''
    TYPE_ALL = '*'
    TYPE_DECISION = 'decision'
    TYPE_TASK = 'task'
    TYPE_WAIT = 'wait'
    TYPE_MICROSERVER = 'microserver'
    TYPE_INFRA = 'infra'

    LEVEL_NONE = 0
    LEVEL_INFO = 1
    LEVEL_WARNING = 2
    LEVEL_ERROR = 3

    """Init the Logger with parameters"""
    def __init__(self):
        self.log_type = os.environ.get('ZENATON_LOG_TYPE') or self.TYPE_ALL
        self.log_level = int(os.environ.get('ZENATON_LOG_LEVEL') or self.LEVEL_NONE)
        self.log_file = '{}zenaton.log'.format(os.environ.get('ZENATON_APP_DIR'))

    """Always-level log"""
    def always(self, title, msg='', message_type=TYPE_NONE):
        self.__log(title, msg, self.LEVEL_NONE, message_type)

    """Info-level log"""
    def info(self, title, msg='', message_type=TYPE_NONE):
        self.__log(title, msg, self.LEVEL_INFO, message_type)

    """Warning-level log"""
    def warning(self, title, msg='', message_type=TYPE_NONE):
        self.__log(title, msg, self.LEVEL_WARNING, message_type)

    """Error-level log"""
    def error(self, title, msg='', message_type=TYPE_NONE):
        self.__log(title, msg, self.LEVEL_ERROR, message_type)

    """Tests if the message has to be ignored or not and acts accordingly"""
    def __log(self, title, msg, level, message_type):
        if not self.__filter_log(level, message_type):
            self.__append_log(title, msg)

    """Checks if the message has to be ignored or not"""
    def __filter_log(self, level, message_type):
        return self.log_level > level or (self.log_type != self.TYPE_ALL and self.log_type != message_type)

    """Actually writes the title and messagea to file"""
    def __append_log(self, title, msg):
        title_string = '==== {} ===='.format(title)
        logFile = open(self.log_file, 'a')
        logFile.writelines([str(title_string), '\n', str(msg), '\n'])
        logFile.close()

