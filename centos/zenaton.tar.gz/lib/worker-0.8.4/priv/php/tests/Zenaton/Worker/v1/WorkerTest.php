<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;
use Zenaton\Exceptions\ZenatonException;
use Zenaton\Services\Serializer;
use Zenaton\Test\Mock\Task\AutomaticRetryTask;
use Zenaton\Test\Mock\Task\ExecutingClosureTask;
use Zenaton\Test\Mock\Task\NoAutomaticRetryTask;
use Zenaton\Test\Mock\Task\SimpleReturnValueTask;
use Zenaton\Test\Mock\Task\WrongAutomaticRetryTask;
use Zenaton\Test\SingletonTesting;

class WorkerTest extends TestCase
{
    use SingletonTesting;

    public function testProcessExecutesATask()
    {
        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->once())
            ->method('completeWork')
            ->with('Hello from task')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = SimpleReturnValueTask::class;
        $job->input = '{"a":{"value":"Hello from task"},"s":[]}';
        $job->hash = 'abcde';

        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessATaskThrowingAZenatonException()
    {
        $this->expectException(ZenatonException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWorker')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = ExecutingClosureTask::class;
        $job->input = $serializer->encode([
            'closure' => function () {
                throw new ZenatonException();
            },
        ]);
        $job->hash = 'abcde';

        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessATaskThrowingANonZenatonException()
    {
        $this->expectException(\RuntimeException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = ExecutingClosureTask::class;
        $job->input = $serializer->encode([
            'closure' => function () {
                throw new \RuntimeException();
            },
        ]);
        $job->hash = 'abcde';
        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessAFailingTaskWithAutomaticRetry()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('I\'m always failing!');

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
            ->with($this->isInstanceOf(\Exception::class), new \PHPUnit_Framework_Constraint_ArraySubset(['retry' => ['delay' => 60]]))
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = AutomaticRetryTask::class;
        $job->input = $serializer->encode([]);
        $job->hash = 'abcde';
        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessAFailingTaskWithoutAutomaticRetry()
    {
        $this->expectException(\RuntimeException::class);
        $this->expectExceptionMessage('I\'m always failing!');

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
            ->with($this->isInstanceOf(\Exception::class), static::logicalNot(new \PHPUnit_Framework_Constraint_ArraySubset(['retry' => ['delay' => 60]])))
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = NoAutomaticRetryTask::class;
        $job->input = $serializer->encode([]);
        $job->hash = 'abcde';
        $worker = new Worker(new Job($job));

        $worker->process();
    }

    public function testProcessAFailingTaskWithWrongAutomaticRetry()
    {
        $this->expectException(\UnexpectedValueException::class);

        $serializer = new Serializer();

        $microserver = $this->replaceSingletonWithMock(MicroServer::class);

        $microserver
            ->expects($this->once())
            ->method('setHash')
            ->willReturnSelf()
        ;
        $microserver
            ->expects($this->never())
            ->method('completeWork')
        ;
        $microserver
            ->expects($this->once())
            ->method('failWork')
            ->with($this->isInstanceOf(\Exception::class), static::logicalNot(new \PHPUnit_Framework_Constraint_ArraySubset(['retry' => ['delay' => 60]])))
        ;
        $microserver
            ->expects($this->once())
            ->method('reset')
        ;

        $job = new \stdClass();
        $job->name = WrongAutomaticRetryTask::class;
        $job->input = $serializer->encode([]);
        $job->hash = 'abcde';
        $worker = new Worker(new Job($job));

        $worker->process();
    }
}
