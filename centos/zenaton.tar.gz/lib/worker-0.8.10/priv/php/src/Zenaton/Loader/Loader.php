<?php

namespace Zenaton\Loader;

use Zenaton\Client as Zenaton;
use Zenaton\Loader\Symfony\Loader as Symfony;
use Zenaton\Services\SyncHttp;

class Loader
{
    protected $args;
    protected $status;
    protected $http;
    protected $framework;
    protected $appDir;

    const PARAM_STATUS_URL = 'status';
    const PARAM_BOOT_FILE = 'boot';
    const PARAM_APP_DIR = 'app';
    const PARAM_FRAMEWORK_NAME = 'framework';
    const PARAM_CLASSES = 'classes';
    const PARAM_JOB_URL = 'job';
    const PARAM_COMMAND_ID = 'command_id';
    const FRAMEWORK_LARAVEL = 'laravel';
    const FRAMEWORK_SYMFONY = 'symfony';

    public function __construct($args)
    {
        // parse $args into $this->args
        parse_str(implode('&', array_slice($args, 1)), $this->args);
        // init http service
        $this->http = new SyncHttp();
        // url that will be called to provide status
        $this->status = $this->getStatusUrl();
        // get framework, if any
        $this->framework = $this->getFramework(false);
        // user app directory
        $this->appDir = $this->getAppDir();
        // store this in environnement (used by Log)
        putenv('ZENATON_APP_DIR='.$this->appDir);
    }

    /*
     * boot autoload file
     */
    public function boot()
    {
        if (self::FRAMEWORK_SYMFONY === $this->framework) {
            $symfony = new Symfony();
            // autoload
            $version = $symfony->autoload();
            if (is_null($version)) {
                $this->failure('Symfony not found: please run "composer install" and check your Symfony version is supported (>=2)');
            }
            // check if public Zenaton libray is now known
            if (!class_exists(Zenaton::class)) {
                $this->failure('Unable to load Zenaton library - please run "composer require zenaton/zenaton-php"');
            }

            // boot
            $symfony->boot();

            return;
        }

        // get boot file
        if (self::FRAMEWORK_LARAVEL === $this->framework) {
            $boot = $this->getLaravelBootFilePath();
        } else {
            $boot = $this->getBootFilePath();
        }

        // load autoload file
        require $boot;

        // check if public Zenaton libray is now known
        if (!class_exists(Zenaton::class)) {
            $this->failure('Unable to load Zenaton library - please add it to your composer.json, and run composer install');
        }

        // boot frameworks
        if (self::FRAMEWORK_LARAVEL === $this->framework) {
            $this->bootLaravelFramework();
        }
    }

    /*
     * Get provided classes parameter
     */
    public function checkClasses()
    {
        $checker = new ClassChecker();

        $classes = $this->getClasses();
        $handleOnly = isset($classes->handle_only) && $classes->handle_only ? ($checker->check($classes->handle_only)) : null;
        $handleExcept = isset($classes->handle_except) && $classes->handle_except ? ($checker->check($classes->handle_except)) : null;

        $this->success([
            'handle_only' => $handleOnly,
            'handle_except' => $handleExcept,
        ]);
    }

    /*
     * path of boot file
     */
    public function getBootFilePath($mandatory = true)
    {
        $boot = $this->arg(self::PARAM_BOOT_FILE, $mandatory);

        if (!is_file($boot)) {
            $this->failure("'".$boot."' is not a file");
        }

        return $boot;
    }

    /*
     * Get status url parameter from argv
     * This parameter is handled a bit differently than others
     * as you can not post error before having a velue
     */
    public function getStatusUrl($mandatory = true)
    {
        $url = $this->arg(self::PARAM_STATUS_URL, false);

        if ($mandatory && is_null($url)) {
            throw new LoaderException("Missing '".self::PARAM_STATUS_URL."' parameter");
        }

        if (!is_null($url) && !$this->checkUrl($url)) {
            throw new LoaderException("Incorrect '".self::PARAM_STATUS_URL."' parameter");
        }

        return $url;
    }

    /*
     * Get job retrieval url parameter from argv
     */
    public function getJobUrl($mandatory = true)
    {
        $url = $this->arg(self::PARAM_JOB_URL, $mandatory);

        if (($mandatory || !is_null($url)) && !$this->checkUrl($url)) {
            $this->failure("Incorrect '".self::PARAM_JOB_URL."' parameter");
        }

        return $url;
    }

    /*
     * Get provided classes from argv
     */
    public function getClasses($mandatory = true)
    {
        $json = $this->arg(self::PARAM_CLASSES, $mandatory);

        $classes = @json_decode($json);
        if (JSON_ERROR_NONE !== json_last_error()) {
            $this->failure("Provided classes parameter '".$json."' is invalid json");
        }

        return $classes;
    }

    /*
     * Get framework name, if any
     */
    public function getFramework($mandatory = true)
    {
        $framework = $this->arg(self::PARAM_FRAMEWORK_NAME, $mandatory);

        // optional parameter
        if ($framework && self::FRAMEWORK_LARAVEL !== $framework && self::FRAMEWORK_SYMFONY !== $framework) {
            $this->failure("'".$framework."' is not a supported framework");
        }

        return $framework;
    }

    /*
     * Get path of user application directory
     */
    public function getAppDir($mandatory = true)
    {
        $dir = rtrim($this->arg(self::PARAM_APP_DIR, $mandatory), '/');

        $this->checkDir($dir);

        return $dir;
    }

    /*
     * Get provided parameter
     */
    protected function arg($type, $mandatory = true)
    {
        if (isset($this->args[$type])) {
            return $this->args[$type];
        }

        if ($mandatory) {
            $this->failure("Missing '".$type."' parameter");
        }
    }

    /*
     * Send success to microserver
     */
    public function success($data = [])
    {
        $this->post(['status' => 'ok', 'data' => $data]);
    }

    /*
     * Send failure to microserver
     */
    public function failure($msg = '')
    {
        $this->post(['error' => $msg]);
        // always stop here
        throw new LoaderException();
    }

    /*
     * Post response to micro-server
     */
    protected function post($body)
    {
        try {
            $body[self::PARAM_COMMAND_ID] = isset($this->args[self::PARAM_COMMAND_ID]) ? $this->args[self::PARAM_COMMAND_ID] : null;
            $this->http->post($this->status, $body);
        } catch (\Exception $e) {
            $msg = ' ('.$this->status.') - post request failed for '.json_encode($body);
            throw new LoaderException($msg, 0, $e);
        }
    }

    /*
     * Get autoload for Laravel Framework
     */
    protected function getLaravelBootFilePath()
    {
        $boot = $this->appDir.'/bootstrap/autoload.php';
        if (!file_exists($boot)) {
            $boot = $this->appDir.'/vendor/autoload.php';
        }
        if (!file_exists($boot)) {
            $this->failure('Unable to find the autoload file of your Laravel app ('.$this->appDir.'/bootstrap/autoload.php)');
        }

        return $boot;
    }

    /*
     * Boot Laravel Framework
     */
    protected function bootLaravelFramework()
    {
        // laravel 5.*
        $bootstrap = $this->appDir.'/bootstrap/app.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
            $kernel->bootstrap();

            return true;
        }

        // laravel 4.*
        $bootstrap = $this->appDir.'/bootstrap/start.php';
        if (file_exists($bootstrap)) {
            $app = require_once $bootstrap;
            $app->boot();

            return true;
        }

        $this->failure('Unable to find the boostrap file of your Laravel app ('.$this->appDir.'/bootstrap/app.php)');
    }

    /*
     * Check accessible file
     */
    protected function checkFile($file)
    {
        if (!is_file($file)) {
            $this->failure("'".$file."' is not a file");
        }
        if (!is_readable($file)) {
            $this->failure("Can not read '".$file."' file");
        }
    }

    /*
     * Check accessible directory
     */
    protected function checkDir($dir)
    {
        if (!is_dir($dir)) {
            $this->failure("'".$dir."' is not a directory");
        }
        if (!is_readable($dir)) {
            $this->failure("Can not read '".$dir."' directory");
        }
    }

    /*
     * Check url validity
     */
    protected function checkUrl($url)
    {
        return false !== filter_var($url, FILTER_VALIDATE_URL);
    }
}
