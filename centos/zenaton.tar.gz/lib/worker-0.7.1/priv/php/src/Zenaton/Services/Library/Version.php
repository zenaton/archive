<?php

namespace Zenaton\Services\Library;

/**
 * Represents a version of the Zenaton library.
 */
interface Version
{
    /**
     * Returns whether the version is greater than the given version id or not.
     *
     * @param int $version A version id to check (e.g. 00200)
     *
     * @return bool
     */
    public function gt($version);

    /**
     * Returns whether the version is greater than or equal to the given version id or not.
     *
     * @param int $version A version id to check (e.g. 00200)
     *
     * @return bool
     */
    public function gte($version);

    /**
     * Returns whether the version is lesser than the given version id or not.
     *
     * @param int $version A version id to check (e.g. 00200)
     *
     * @return bool
     */
    public function lt($version);

    /**
     * Returns whether the version is lesser than or equal to the given version id or not.
     *
     * @param int $version A version id to check (e.g. 00200)
     *
     * @return bool
     */
    public function lte($version);
}
