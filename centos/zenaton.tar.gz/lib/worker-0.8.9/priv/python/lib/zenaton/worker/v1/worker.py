import zenaton

from .microserver import Microserver
from ...services.importer import Importer
from ...services.log import Log


class Worker:

    def __init__(self, job, boot):
        self.job = job
        self.microserver = Microserver()
        self.microserver.custom_hash = job.get('hash')
        # input = zenaton.services.serializer.Serializer().decode(input)
        # task_input = json.loads(input)['s'][0]['a']
        task_input = zenaton.services.serializer.Serializer(boot, job['name']).decode(job['input'])
        self.task = Importer(boot).import_class(job['name'])(**task_input)

        if hasattr(self.task, 'set_context'):
            self.task.set_context(zenaton.contexts.task_context.TaskContext(id=self.job.get('intent_id'), retry_index=self.job.get('retry_index')))

        Log().info(
            'TASK - Input - {}'.format(job['name']),
            job['input'],
            Log().TYPE_TASK
        )

    def process(self):
        extra = {}

        if hasattr(self.task, '_context') and hasattr(self.task, 'on_error_retry_delay') and self.job.get('retry_index'):
            try:
                delay = self.task.on_error_retry_delay(self.job['retry_index'])
                extra['retry'] = {'delay': delay}
                Log().info(
                    'TASK - Retry Delay - {} - Attempt #{}'.format(self.job['name'], self.job['retry_index']),
                    self.job['retry_index'],
                    Log().TYPE_TASK
                )
            except Exception as err:
                self.microserver.fail_work(err, extra)
                self.microserver.reset()
                raise err

        try:
            output = self.task.handle()
        except zenaton.exceptions.Error as err:
            self.microserver.fail_worker(err, extra)
            self.microserver.reset()
            raise err
        except Exception as err:
            retry_delay = self.retrieve_retry_delay(err)
            if (False != retry_delay):
                extra['retry'] = {'delay': retry_delay}

            self.microserver.fail_work(err, extra)
            self.microserver.reset()
            raise err
        self.microserver.complete_work(output)
        self.microserver.reset()


    def retrieve_retry_delay(self, error):
        if hasattr(self.task, 'on_error_retry_delay'):
            try:
                delay = self.task.on_error_retry_delay(error)

                # null and false means the user does not want the task to be retried
                if (None == delay or False == delay):
                    return False

                if (isinstance(delay, int) and delay > 0):
                    Log().info(
                        'TASK - Retry Delay - {} - Attempt #{}'.format(self.job['name'], self.job['retry_index']),
                        self.job['retry_index'],
                        Log().TYPE_TASK
                    )

                    return delay

                raise Exception("""
                    Unexpected return value of the `on_error_retry_delay' method.
                    The method is expected to return a positive numeric type representing
                    the seconds to wait before automatically retrying the task. If the
                    task must not be automatically retried, the method is expected to
                    return a falsy value. """)
            except Exception as err:
                self.microserver.fail_work(err)
                self.microserver.reset()
                raise err