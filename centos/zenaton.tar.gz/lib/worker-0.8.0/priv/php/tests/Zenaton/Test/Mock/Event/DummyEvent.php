<?php

namespace Zenaton\Test\Mock\Event;

use Zenaton\Interfaces\EventInterface;

class DummyEvent implements EventInterface
{
}
