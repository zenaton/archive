import sys
from pathlib import Path

if __name__ == '__main__' and __package__ is None:
    file = Path(__file__).resolve()
    parent, top = file.parent, file.parents[2]

    sys.path.append(str(top))
    try:
        sys.path.remove(str(parent))
    except ValueError:  # Already removed
        pass

    import python.lib.zenaton.loader.loader as loader

    __package__ = 'python.lib.zenaton.loader.loader'


def check_loader():
    load = loader.Loader(*sys.argv)
    load.boot()
    load.check_classes()


check_loader()
