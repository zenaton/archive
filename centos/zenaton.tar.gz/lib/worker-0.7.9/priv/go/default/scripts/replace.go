package main

import (
	"fmt"
	"os"

	_ "github.com/zenaton/integration/go/boot/versionboot.go"
)

func main() {
	fmt.Println(os.Getenv("ZENATON_LIBRARY_PATH"))
}
