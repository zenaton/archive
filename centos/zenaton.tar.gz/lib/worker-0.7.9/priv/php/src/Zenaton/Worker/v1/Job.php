<?php

namespace Zenaton\Worker;

/**
 * @internal
 */
final class Job
{
    /** @var \stdClass */
    private $attributes;

    /**
     * @param \stdClass $attributes An stdClass instance containing the properties of the job
     */
    public function __construct(\stdClass $attributes)
    {
        $this->attributes = $attributes;
    }

    /**
     * Get a property or return a default value if it does not exist.
     *
     * @param string $name    Name of the property
     * @param mixed  $default The default value to return if the property does not exist
     */
    public function get($name, $default = null)
    {
        return $this->has($name) ? $this->attributes->$name : $default;
    }

    /**
     * Returns whether a property exists or not.
     *
     * @param string $name Name of the property
     *
     * @return bool
     */
    public function has($name)
    {
        return isset($this->attributes->$name);
    }
}
