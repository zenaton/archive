<?php

namespace Zenaton\Worker;

use PHPUnit\Framework\TestCase;

class PositionTest extends TestCase
{
    protected $position;

    public function setUp()
    {
        $this->position = new Position();
    }

    public function testNextIncrementsThePosition()
    {
        for ($i = 1; $i <= 10; ++$i) {
            $this->position->next();
            static::assertSame((string) $i, $this->position->get());
        }
    }

    public function testNextAsyncIncrementsThePositionWithTheAsyncSeparator()
    {
        for ($i = 1; $i <= 10; ++$i) {
            $this->position->nextAsync();
            static::assertSame($i.'a', $this->position->get());
        }
    }

    public function testNextParallelIncrementsTheParallelCounter()
    {
        for ($i = 1; $i <= 10; ++$i) {
            $this->position->nextParallel();
            static::assertSame('1p'.($i - 1), $this->position->get());
        }
    }

    public function testNextParallelAfterNextAsyncKeepsTheMainCounter()
    {
        for ($i = 1; $i <= 10; ++$i) {
            $this->position->nextAsync();
        }
        $this->position->nextParallel();
        $this->position->nextParallel();
        static::assertSame('11p1', $this->position->get());
    }

    public function testNextAsyncAfterNextParallelRemovesTheCounter()
    {
        for ($i = 1; $i <= 10; ++$i) {
            $this->position->nextAsync();
        }
        $this->position->nextParallel();
        $this->position->nextParallel();
        $this->position->nextAsync();
        static::assertSame('12a', $this->position->get());
    }
}
