# frozen_string_literal: true

require 'singleton'

require_relative '../../services/log'
require_relative '../../services/sync_http'
require_relative './workflow'

module Zenaton
  module Worker
    module V1
      # Microserver
      class Microserver
        include Singleton

        attr_accessor :uuid
        attr_writer :custom_hash, :worker_version

        def initialize
          @serializer = Zenaton::Services::Serializer.new
          @properties = Zenaton::Services::Properties.new
          @log = Zenaton::Services::Log.new
          @http = Zenaton::Services::SyncHttp.new
          @flow = Zenaton::Worker::V1::Workflow.instance
        end

        def reset
          @uuid = nil
          @custom_hash = nil
          @worker_version = nil
        end

        def deciding?
          @custom_hash.nil? && !@uuid.nil?
        end

        def working?
          !@custom_hash.nil? && !@uuid.nil?
        end

        def ask_job(type)
          url = worker_url("uuid/#{@uuid}/type/#{type}/job", 'worker_version' => @worker_version)

          @http.get(url).tap do |response|
            @log.info(
              "INFRA - Ask Job - (get) #{url}",
              { response: response },
              Zenaton::Services::Log::TYPE_INFRA
            )
          end
        end

        def branch_to_execute
          url = decision_url('branch')

          @http.get(url).tap do |response|
            @log.info(
              "DECISION - Branch - (get) #{url}",
              { response: response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def execute(boxes)
          url = decision_url('execute')
          body = { 'works' => boxes.map(&:job) }
          @http.post(url, body).tap do |response|
            parse_completed(response) if response['status'] == 'completed'
            @log.info(
              "DECISION - Execute - (post) #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def complete_decision
          url = decision_url('branch')
          body = decision_body
          @http.post(url, body).tap do |response|
            @log.info(
              "DECISION - Complete - (post) #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def complete_decision_branch(output = nil)
          url = decision_url('branch')
          body = decision_body
          body['output'] = output.to_json if output
          @http.post(url, body).tap do |response|
            @log.info(
              "DECISION - Complete Branch - (post) #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def fail_decider(error, extra={})
          url = decision_url
          body = error_body(error, extra).merge('status' => 'zenatonFailed')
          @http.put(url, body).tap do |response|
            @log.info(
              "DECISION - Decider Failure - (put) - #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def fail_decision(error, extra={})
          url = decision_url
          body = error_body(error, extra).merge('status' => 'failed')
          @http.put(url, body).tap do |response|
            @log.info(
              "DECISION - Decision Failure - (put) - #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_DECISION
            )
          end
        end

        def decision_url(endpoint = '')
          worker_url("decisions/#{@uuid}/#{endpoint}", 'worker_version' => @worker_version)
        end

        def complete_work(output)
          send_work(
            'status' => 'completed',
            'output' => @serializer.encode(output)
          )
        end

        def fail_worker(error, extra={})
          send_work(
            error_body(error, extra).merge(
              'status' => 'zenatonFailed',
              'error_input' => @serializer.encode(@properties.from(error))
            )
          )
        end

        def fail_work(error, extra={})
          send_work(
            error_body(error, extra).merge(
              'status' => 'failed',
              'error_input' => @serializer.encode(@properties.from(error))
            )
          )
        end

        def send_work(body)
          url = worker_url("tasks/#{@uuid}", 'worker_version' => @worker_version)
          body['hash'] = @custom_hash
          @http.post(url, body).tap do |response|
            @log.info(
              "Task - Send - (post) #{url}",
              { 'body' => body, 'response' => response },
              Zenaton::Services::Log::TYPE_TASK
            )
          end
        end

        private

        def parse_completed(response)
          response['properties'] = @serializer.decode(response['properties'])
          response['outputs'] = response['outputs'].map(&method(:parse_output))
        end

        def parse_output(output)
          return nil unless output
          return @serializer.decode(output['event_data']) if output['event_data']
          return decode_event(output) if output['event_name'] && output['event_input']
          @serializer.decode(output)
        end

        def decode_event(output)
          @properties.object_from(
            output['event_name'],
            @serializer.decode(output['event_input']),
            Zenaton::Interfaces::Event
          )
        end

        def worker_url(resource, params = {})
          params = params_to_string(params) if Gem::Version.new(Zenaton::VERSION) < Gem::Version.new('0.4')
          Zenaton::Client.instance.worker_url(resource, params)
        end

        def params_to_string(params)
          params.map do |key, value|
            "#{key}=#{value}"
          end.join('&')
        end

        def error_body(error, extra={})
          body = {
            'error_name' => error.class.name,
            'error_code' => 0,
            'error_message' => error.message,
            'error_stacktrace' => stacktrace_for(error),
            'failed_at' => Time.now.to_i
          }

          if extra['retry']
            body['retry'] = extra['retry']
          end

          body
        end

        def stacktrace_for(error)
          return error.full_message if error.respond_to?(:full_message)
          (error.backtrace || []).join("\n")
        end

        def decision_body
          {
            'properties' => @serializer.encode(@flow.read_properties),
            'callbacks' => @flow.implemented_callbacks
          }
        end
      end
    end
  end
end
