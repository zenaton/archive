# frozen_string_literal: true

require 'logger'

require_relative '../../worker_exceptions'
require_relative './microserver'
require_relative './workflow'

module Zenaton
  module Worker
    module V1
      class Decider
        def initialize(job)
          @logger = Logger.new(STDOUT)
          @microserver = Microserver.instance
          @flow = Workflow.instance
          @flow.name = job['name']
          @job = job
        end

        def launch
          # execute every branch
          while next_branch
            begin
              output = @flow.run_branch
            rescue ScheduledBox
              # nothing more to do for this branch, continue to next one
              @microserver.complete_decision
              next
            rescue InternalError => error
              # something bad happened in our code, stop current decision
              @microserver.fail_decider(error)
              @logger.error(error.message)
              break
            rescue ModifiedDecider => error
              # user did modify its decider, sad!
              @microserver.fail_decider(error)
              @logger.error(error.message)
              break
            rescue StandardError => error
              # something bad happened in user code, stop current decision
              @microserver.fail_decider(error)
              @logger.error(error)
              break
            end
            # cool, we complete this branch
            @microserver.complete_decision_branch(output)
          end
          # this decision is done, clean up microserver
          @microserver.reset
        end

        private

        def next_branch
          branch = @microserver.branch_to_execute
          if branch && !branch.blank?
            @flow.init(branch['branch'], branch['properties'])
            return true
          end
          false
        end
      end
    end
  end
end
