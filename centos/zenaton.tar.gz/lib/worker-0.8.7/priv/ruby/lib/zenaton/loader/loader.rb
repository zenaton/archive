# frozen_string_literal: true

require_relative '../services/sync_http'
require_relative 'loader_error'
require_relative 'class_checker'

module Zenaton
  module Loader
    # Loading up workflows on the worker
    class Loader
      PARAM_STATUS_URL = 'status'
      PARAM_BOOT_FILE = 'boot'
      PARAM_APP_DIR = 'app'
      PARAM_FRAMEWORK_NAME = 'framework'
      PARAM_CLASSES = 'classes'
      PARAM_JOB_URL = 'job'
      FRAMEWORK_RAILS = 'rails'

      def initialize(*params)
        # parse the received params into @args
        @args = parse_params(params)
        # user app directory
        @app_dir = app_dir
        # make sure the execution path of ruby is the app directory
        Dir.chdir(@app_dir)
        # store this in environment (used by log)
        ENV['ZENATON_APP_DIR'] = @app_dir
        # init http service
        @http = Services::SyncHttp.new
        # url that will be called to provide status
        @status = status_url
        # get framework, if any
        @framework = framework(false)
      end

      def boot
        boot_file = boot_file_path
        require boot_file
        message = 'Unable to load Zenaton library - please add it to your Gemfile, and run bundle install'
        failure(message) unless defined? Zenaton::VERSION
      end

      # Get provided class parameters
      def check_classes
        checker = ClassChecker.new

        provided_classes = classes
        handle_only = provided_classes['handle_only'] && checker.check(provided_classes['handle_only'])
        handle_except = provided_classes['handle_except'] && checker.check(provided_classes['handle_except'])

        success('handle_only' => handle_only, 'handle_except' => handle_except)
      end

      # Path of boot file
      def boot_file_path(mandatory = true)
        return './config/environment.rb' if @framework == FRAMEWORK_RAILS
        arg(PARAM_BOOT_FILE, mandatory).tap(&method(:check_file))
      end

      # Get status url parameter from args
      # This parameter is handled a bit differently than others
      # as you can not post error before having a value
      def status_url(mandatory = true)
        arg(PARAM_STATUS_URL, false).tap do |url|
          raise LoaderError, "Missing #{PARAM_STATUS_URL} parameter" if mandatory && url.nil?
          raise LoaderError, "Incorrect #{PARAM_STATUS_URL} parameter" unless url.nil? || check_url(url)
        end
      end

      # Get job retrieval url parameter from argv
      def job_url(mandatory = true)
        arg(PARAM_JOB_URL, mandatory).tap do |url|
          failure("Incorrect '#{PARAM_JOB_URL}' parameter") if (mandatory || !url.nil?) && !check_url(url)
        end
      end

      # Get framework name, if any
      def framework(mandatory = true)
        arg(PARAM_FRAMEWORK_NAME, mandatory).tap do |framework|
          failure("'#{framework}' is not a supported framework") if framework && framework != FRAMEWORK_RAILS
        end
      end

      # Get path of user application directory
      def app_dir(mandatory = true)
        arg(PARAM_APP_DIR, mandatory).gsub(%r{\/$}, '').tap { |dir| check_dir(dir) }
      end

      # Get provided classes from argv
      def classes(mandatory = true)
        json = arg(PARAM_CLASSES, mandatory)
        JSON.parse(json)
      rescue JSON::JSONError
        failure("Provided classes parameter #{json} is invalid json")
      end

      # Send success to microserver
      def success(data = {})
        post('status' => 'ok', 'data' => data, 'command_id' => @args['command_id'])
      end

      # Send failure to microserver
      def failure(message)
        post('error' => message, 'command_id' => @args['command_id'])
        raise LoaderError
      end

      private

      # Get provided parameter
      def arg(type, mandatory = true)
        return @args[type] if @args[type]
        failure("Missing #{type} parameter") if mandatory
      end

      # Post response to micro-server
      def post(body)
        @http.post(@status, body)
      rescue StandardError
        raise LoaderError, "(#{@status}) - post request failed for #{body.to_json}"
      end

      # parse the received params string
      def parse_params(params_list)
        params_list.map do |keyvalue|
          keyvalue =~ /=$/ ? [keyvalue, nil] : keyvalue.split('=')
        end.to_h
      end

      # Check accessible file
      def check_file(path)
        failure("'#{path}' is not a file") unless File.file?(path)
        failure("Can not read '#{path}' file") unless File.readable?(path)
      end

      # Check accessible directory
      def check_dir(path)
        failure("'#{path}' is not a directory") unless File.directory?(path)
        failure("Can not read '#{path}' directory") unless File.readable?(path)
      end

      # rubocop:disable Metrics/LineLength, Metrics/AbcSize
      # Check url validity
      def check_url(url)
        # https://github.com/nescalante/urlregex
        ip = '(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])(?:\\.(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])){3}'
        protocol = '(?:http(s?)\:\/\/)?'
        auth = '(?:\\S+(?::\\S*)?@)?'
        host = '(?:(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)'
        domain = '(?:\\.(?:[a-z\\u00a1-\\uffff0-9]-*)*[a-z\\u00a1-\\uffff0-9]+)*'
        tld = '(?:\\.(?:[a-z\\u00a1-\\uffff]{2,}))\\.?'
        port = '(?::\\d{2,5})?'
        path = '(?:[/?#][^\\s"]*)?'
        regex = '(?:' + protocol + '|www\\.)' + auth + '(?:localhost|' + ip + '|' + host + domain + tld + ')' + port + path
        url.match(Regexp.new('(?:^' + regex + '$)', 'i'))
      end
      # rubocop:enable Metrics/LineLength, Metrics/AbcSize
    end
  end
end
