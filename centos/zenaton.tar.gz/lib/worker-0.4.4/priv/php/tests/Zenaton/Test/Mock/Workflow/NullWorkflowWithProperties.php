<?php

namespace Zenaton\Test\Mock\Workflow;

use Zenaton\Interfaces\WorkflowInterface;

class NullWorkflowWithProperties implements WorkflowInterface
{
    private $a;

    public function __construct($a)
    {
        $this->a = $a;
    }

    public function handle()
    {
    }
}
