<?php

namespace Zenaton\Test\Mock\Workflow;

use Zenaton\Interfaces\WorkflowInterface;
use Zenaton\Traits\Zenatonable;

class NullWorkflowWithProperties implements WorkflowInterface
{
    use Zenatonable;

    private $a;

    public function __construct($a)
    {
        $this->a = $a;
    }

    public function handle()
    {
    }
}
